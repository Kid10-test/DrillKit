import{u as Ma,r as d,j as a,M as Pa,q as G,B as y,F as g,l as b}from"./index-BK1rijHg.js";import{y as oa,Y as R,o as $a,s as Ba,m as wa,P as Da,M as Q}from"./bukaBerkas-DFj9e2er.js";import{p as La,c as Y,U as Ca,s as Ka,d as da,h as Aa,L as Ja,e as Ta}from"./FieldMarkers-BMIUx4ZN.js";import{p as Ra,d as za}from"./print-DIYZna4t.js";import"./countSheet-CgkFv3Ao.js";import"./analitik-BQdqB6VX.js";import"./gerak-BKaWXUpL.js";import"./tempoTimeline-C4caWYQh.js";import"./segmenDrill-D1anFPod.js";function j(t){return String(t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Ia(t){var I,J;const k=oa(t.field),A=(t.field.widthYd*R).toFixed(1).replace(".",","),E=(t.field.lengthYd*R).toFixed(0),B=new Map(t.members.map(r=>[r.id,r])),w=new Map;let n=1;for(const r of Object.keys(t.points)){const s=La(t.points,r,t.field);if(!s)continue;const l=B.get(r),M=(I=w.get(s.nomorSaf))!=null?I:[];M.push({banjar:s.nomorBanjar,id:r,kode:(l==null?void 0:l.code)||r.slice(0,4).toUpperCase(),nama:(l==null?void 0:l.name)||"Anggota",seksi:(l==null?void 0:l.role)==="drumMajor"?"Gitapati":(J=l==null?void 0:l.section)!=null?J:"-"}),s.nomorBanjar>n&&(n=s.nomorBanjar),w.set(s.nomorSaf,M)}const u=[...w.keys()].sort((r,s)=>r-s),x=t.rute.statusKetahanan==="nyaman"?{bg:"#dcfce7",border:"#16a34a",text:"#14532d",label:"NYAMAN"}:t.rute.statusKetahanan==="padat"?{bg:"#fef3c7",border:"#d97706",text:"#78350f",label:"PADAT"}:{bg:"#fee2e2",border:"#dc2626",text:"#7f1d1d",label:"RAWAN LELAH"},o=Array.from({length:n},(r,s)=>`<th>Banjar ${s+1}</th>`).join(""),z=u.length===0?`<tr><td colspan="${n+1}" style="text-align:center;color:#64748b;padding:12px;">Belum ada titik pemain di set ini.</td></tr>`:u.map(r=>{var M;const s=((M=w.get(r))!=null?M:[]).sort((v,P)=>v.banjar-P.banjar),l=Array.from({length:n},(v,P)=>{const S=P+1;if(s.length===1&&n>1){const f=Math.ceil(n/2);if(S!==f)return'<td class="kosong">—</td>';const O=s[0];return`<td><strong>${j(O.kode)}</strong><div class="sub">${j(O.nama)}</div></td>`}const $=s.find(f=>f.banjar===S);return $?`<td><strong>${j($.kode)}</strong><div class="sub">${j($.nama)}</div></td>`:'<td class="kosong">—</td>'}).join("");return`<tr><td class="saf">Saf ${r}</td>${l}</tr>`}).join("");return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Lembar Komando Kirab — ${j(t.judulDrill)}</title>
<style>
  @page { size: A4 portrait; margin: 11mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #0f172a;
    background: #ffffff;
    font-size: 11px;
    line-height: 1.4;
  }
  .kop {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-bottom: 2px solid #0f172a;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }
  .kop h1 { margin: 0; font-size: 16px; color: #0f172a; }
  .kop .meta { font-size: 10.5px; color: #475569; margin-top: 2px; }
  .lencana {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 700;
    background: ${x.bg};
    border: 1px solid ${x.border};
    color: ${x.text};
  }
  .grid4 {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    margin-bottom: 10px;
  }
  .kotak {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 6px 8px;
    background: #f8fafc;
  }
  .kotak .lbl { font-size: 9.5px; color: #475569; text-transform: uppercase; letter-spacing: 0.04em; }
  .kotak .val { font-size: 13.5px; font-weight: 700; color: #0f172a; margin-top: 2px; }
  .kotak .ket { font-size: 9.5px; color: #64748b; }
  .kotak-vip {
    border: 1px solid #f59e0b;
    background: #fffbeb;
    border-radius: 6px;
    padding: 7px 10px;
    margin-bottom: 10px;
    color: #78350f;
  }
  h2 {
    margin: 10px 0 6px;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #1e293b;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
  }
  th, td {
    border: 1px solid #cbd5e1;
    padding: 4px 6px;
    text-align: center;
    vertical-align: top;
  }
  th {
    background: #1e293b;
    color: #ffffff;
    font-weight: 700;
  }
  td.saf {
    background: #f1f5f9;
    font-weight: 700;
    color: #0f172a;
    white-space: nowrap;
    width: 58px;
  }
  td.kosong { color: #94a3b8; background: #f8fafc; }
  td .sub { font-size: 9px; color: #475569; margin-top: 1px; }
  .catatan {
    margin-top: 10px;
    padding: 7px 10px;
    border-radius: 6px;
    border: 1px solid ${x.border};
    background: ${x.bg};
    color: ${x.text};
    font-size: 10.5px;
  }
</style>
</head>
<body>
  <div class="kop">
    <div>
      <h1>LEMBAR KOMANDO KIRAB / STREET PARADE</h1>
      <div class="meta">${j(t.namaTim)} · Drill: <strong>${j(t.judulDrill)}</strong> (${j(t.namaSet)})${t.namaLagu?` · Lagu: ${j(t.namaLagu)}`:""}</div>
    </div>
    <div class="lencana">KETAHANAN: ${x.label}</div>
  </div>

  <div class="grid4">
    <div class="kotak">
      <div class="lbl">Koridor Jalan</div>
      <div class="val">Lebar ${A} m</div>
      <div class="ket">Segmen ${E} m · Bahu ${String(k.bahuJalanM).replace(".",",")} m</div>
    </div>
    <div class="kotak">
      <div class="lbl">Rute & Waktu Tempuh</div>
      <div class="val">${String(t.rute.panjangRuteKm).replace(".",",")} km · ${String(t.rute.totalWaktuTempuhMenit).replace(".",",")} mnt</div>
      <div class="ket">${t.rute.totalLangkah.toLocaleString("id-ID")} langkah (${String(t.rute.kecepatanKmPerJam).replace(".",",")} km/jam)</div>
    </div>
    <div class="kotak">
      <div class="lbl">Tempo & Langkah</div>
      <div class="val">${t.rute.bpm} BPM · ${String(t.rute.panjangLangkahCm).replace(".",",")} cm</div>
      <div class="ket">${String(t.rute.kecepatanMPerMenit).replace(".",",")} meter / menit</div>
    </div>
    <div class="kotak">
      <div class="lbl">Siklus Lagu & Napas</div>
      <div class="val">${t.rute.jumlahPengulanganLagu}× putaran</div>
      <div class="ket">Lagu ${Math.round(t.rute.jarakLaguM)} m + Street beat ${Math.round(t.rute.jarakStreetBeatM)} m</div>
    </div>
  </div>

  ${k.panggungAktif===1?`<div class="kotak-vip">
          <strong>${j(k.labelPanggung)}:</strong> bentang <strong>${k.panjangPanggungM} m</strong> di sisi <strong>${k.sisiPanggung==="belakang"?"Tepi Belakang (Atas)":"Tepi Depan (Penonton)"}</strong> · Arah defile: <strong>${k.arahDefile==="kanan-ke-kiri"?"Kanan → Kiri":"Kiri → Kanan"}</strong>.
        </div>`:""}

  <h2>Peta Susunan Barisan Defile (Kepala Saf 1 → Ekor Saf ${u.length})</h2>
  <table>
    <thead>
      <tr>
        <th>Saf</th>
        ${o}
      </tr>
    </thead>
    <tbody>
      ${z}
    </tbody>
  </table>

  <div class="catatan">
    <strong>Evaluasi Cadangan Napas (${String(t.rute.rasioCadanganNapasPersen).replace(".",",")}%):</strong>
    ${j(t.rute.rekomendasiNapas)}
  </div>
</body>
</html>`}function Oa(t){const k=Ia(t);if(Ra(k))return"cetak";const A=t.judulDrill.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"parade";return za(`komando-kirab-${A}.html`,k),"unduh"}function qa({open:t,onClose:k,namaTim:A,judulDrill:E,namaSetAktif:B,tempoDrill:w,field:n,pointsAktif:u,members:x,laguTertaut:o,onUbahField:z,onTerapkanPointsSetAktif:I,onTambahRangkaianSet:J}){const r=Ma(),s=oa(n),l=$a(n),M=Math.round(Ba(n)*R*1e3)/10,[v,P]=d.useState("banjar-saf"),[S,$]=d.useState(()=>Y(n,2)),[f,O]=d.useState(2),[V,pa]=d.useState(2),[_,ma]=d.useState(4),[U,ua]=d.useState(0),[D,ca]=d.useState(()=>[...Ca]),[L,ga]=d.useState(""),[X,ba]=d.useState(!0),[aa,xa]=d.useState(16),[N,ea]=d.useState(()=>s.panjangRuteM||1500),[H,ha]=d.useState(()=>w||(o==null?void 0:o.bpm)||116),[F,ka]=d.useState(()=>M||60),[W,ja]=d.useState(()=>{var e;if((e=o==null?void 0:o.tempoMap)!=null&&e.length){const i=o.tempoMap.reduce((h,p)=>h+Math.max(1,p.measure)*Math.max(1,p.beats||o.beats||4)*60/Math.max(30,p.bpm||o.bpm||116),0);if(i>=15)return Math.round(i)}return 150}),[Z,fa]=d.useState(32),[q,va]=d.useState(0),m=d.useMemo(()=>Ka(x,n,{jumlahBanjar:S,jarakAntarBanjarLangkah:f,jarakAntarSafLangkah:V,jarakAntarSeksiLangkah:_,jumlahSpanduk:U,urutanBlok:D}),[x,n,S,f,V,_,U,D]),T=d.useMemo(()=>{const e=L.trim()===""?void 0:Math.max(4,Number(L)||8),i=Object.keys(u).length>0?u:m.points;return da(i,n,"kanan",{hitunganPutar:e})},[u,m.points,n,L]),c=d.useMemo(()=>Aa({panjangRuteM:N,bpm:H,panjangLangkahCm:F,durasiLaguDetik:W,ketukanStreetBeat:Z,durasiDisplayVipMenit:q}),[N,H,F,W,Z,q]);async function ta(e){const i=e===6?50:e===8?60:75,h=e===6?.4:e===8?.5:.75,p=e===6?12:e===8?16:20,K={...n,widthYd:e*Q,lengthYd:i*Q,endZoneYd:0,gridYd:5*Q,hash:"none",showLabels:0,satuan:"m",warna:"aspal",patok:{...wa(n),aktif:0},parade:{...Da,...s,aktif:1,bahuJalanM:h,panjangPanggungM:p,panjangRuteM:N}};await z(K);const la=Y(K,f);$(la),r.push(`Kanvas Jalan Parade ${e} m diaktifkan (saran otomatis: ${la} banjar).`,"ok")}function na(e,i){const h=e+i;if(h<0||h>=D.length)return;const p=[...D],K=p[e];p[e]=p[h],p[h]=K,ca(p)}async function ya(){if(m.jumlahPemain===0){r.push("Belum ada anggota aktif untuk disusun ke dalam barisan.","err");return}l||await ta(8),await I(m.points,`Barisan kirab ${S} banjar × ${m.jumlahSaf} saf (${m.jumlahPemain} anggota)`),r.push(`Susunan ${S} banjar × ${m.jumlahSaf} saf diterapkan ke ${B}.`,"ok")}async function sa(e){const i=Object.keys(u).length>0?u:m.points;if(Object.keys(i).length===0){r.push("Susun barisan terlebih dahulu sebelum membuat simulasi tikungan.","err");return}const h=L.trim()===""?void 0:Math.max(4,Number(L)||8),p=da(i,n,e,{hitunganPutar:h}),K=X&&p.lebarSimpangDisarankanYd>n.widthYd?{...n,widthYd:p.lebarSimpangDisarankanYd}:void 0;await J(p.sets,K),r.push(`2 set tikungan 90° ke ${e==="kanan"?"Kanan":"Kiri"} ditambahkan (${p.analisis.hitunganDipakaiPerSaf} hitungan/saf).`,"ok")}async function ra(e){const i=Object.keys(u).length>0?u:m.points;if(Object.keys(i).length===0){r.push("Susun barisan terlebih dahulu sebelum membuat formasi Panggung VIP.","err");return}const h=Ta(i,n,e,x,{hitunganDisplay:aa});await J(h),r.push(e==="hormat_jalan"?"Set Defile Hormat Jalan di Zona Panggung VIP berhasil ditambahkan.":"3 set Display Panggung VIP → Kembali Defile berhasil ditambahkan tanpa mengacak saf!","ok")}async function Sa(){await z({...n,parade:{...s,aktif:l?1:s.aktif,panjangRuteM:Math.round(N)}}),r.push(`Panjang rute ${(N/1e3).toFixed(2).replace(".",",")} km disimpan ke drill ini.`,"ok")}function Na(){const e=Object.keys(u).length>0?u:m.points;Oa({namaTim:A,judulDrill:E,namaSet:B,field:l?n:{...n,parade:{...s,aktif:1,panjangRuteM:N}},points:e,members:x,rute:c,namaLagu:o==null?void 0:o.title})==="unduh"&&r.push("Popup cetak diblokir browser — Lembar Komando Kirab diunduh sebagai HTML siap cetak.","ok")}const ia=(n.widthYd*R).toFixed(1).replace(".",","),C=m.kesesuaianJalan;return a.jsx(Pa,{open:t,onClose:k,title:"Mode Kirab / Street Parade & Display Jalan Raya",wide:!0,children:a.jsxs("div",{"data-testid":"modal-parade",className:"space-y-4",children:[a.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-500/35 bg-slate-900/80 p-3",children:[a.jsx("div",{className:"space-y-0.5 text-xs",children:l?a.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[a.jsx(G,{className:"border-amber-500/40 bg-amber-500/15 text-amber-200",children:"Kanvas Jalan Parade Aktif"}),a.jsxs("span",{className:"text-slate-200",children:["Lebar jalan ",a.jsxs("b",{children:[ia," m"]})," · Arah"," ",a.jsx("b",{children:s.arahDefile==="kanan-ke-kiri"?"Kanan → Kiri":"Kiri → Kanan"}),s.panggungAktif===1?` · VIP ${s.panjangPanggungM} m`:""]})]}):a.jsxs("div",{className:"text-amber-200",children:["Drill ini masih memakai kanvas lapangan biasa (",ia," m). Pilih lebar jalan raya untuk menyalakan kanvas aspal & Panggung Kehormatan:"]})}),a.jsx("div",{className:"flex flex-wrap items-center gap-1.5",children:[6,8,12].map(e=>a.jsxs(y,{size:"sm",variant:l&&Math.abs(n.widthYd*R-e)<.25?"primary":"soft","data-testid":`parade-pilih-jalan-${e}m`,onClick:()=>void ta(e),children:["Jalan ",e," m"]},e))})]}),a.jsxs("div",{className:"grid grid-cols-3 gap-1.5 rounded-xl bg-slate-950/80 p-1",children:[a.jsx("button",{type:"button","data-testid":"tab-parade-banjar",onClick:()=>P("banjar-saf"),className:`rounded-lg px-2.5 py-2 text-xs font-semibold transition ${v==="banjar-saf"?"bg-sky-500/20 text-sky-200 ring-1 ring-sky-500/50":"text-slate-400 hover:text-slate-200"}`,children:"1. Banjar × Saf"}),a.jsx("button",{type:"button","data-testid":"tab-parade-tikungan",onClick:()=>P("tikungan-vip"),className:`rounded-lg px-2.5 py-2 text-xs font-semibold transition ${v==="tikungan-vip"?"bg-amber-500/20 text-amber-200 ring-1 ring-amber-500/50":"text-slate-400 hover:text-slate-200"}`,children:"2. Tikungan 90° & VIP"}),a.jsx("button",{type:"button","data-testid":"tab-parade-kalkulator",onClick:()=>P("kalkulator-rute"),className:`rounded-lg px-2.5 py-2 text-xs font-semibold transition ${v==="kalkulator-rute"?"bg-emerald-500/20 text-emerald-200 ring-1 ring-emerald-500/50":"text-slate-400 hover:text-slate-200"}`,children:"3. Kalkulator Rute & Cetak"})]}),v==="banjar-saf"&&a.jsxs("div",{className:"space-y-3",children:[a.jsxs("div",{className:"grid gap-3 sm:grid-cols-3",children:[a.jsx(g,{label:"Jumlah Banjar (kolom)",hint:`Saran jalan ini: ${Y(n,f)} banjar`,children:a.jsxs("div",{className:"flex gap-1.5",children:[a.jsx(b,{"data-testid":"parade-input-banjar",type:"number",min:1,max:16,value:S,onChange:e=>$(Math.max(1,Math.min(16,Number(e.target.value)||1)))}),a.jsx(y,{size:"sm",variant:"soft",onClick:()=>$(Y(n,f)),title:"Sesuaikan otomatis dengan lebar jalan",children:"Auto"})]})}),a.jsx(g,{label:"Jarak antar-banjar (langkah)",hint:"lebar kiri–kanan",children:a.jsx(b,{"data-testid":"parade-input-spasi-banjar",type:"number",step:"0.5",min:1,max:6,value:f,onChange:e=>O(Math.max(.5,Number(e.target.value)||2))})}),a.jsx(g,{label:"Jarak antar-saf (langkah)",hint:"depan–belakang",children:a.jsx(b,{"data-testid":"parade-input-spasi-saf",type:"number",step:"0.5",min:1,max:8,value:V,onChange:e=>pa(Math.max(1,Number(e.target.value)||2))})}),a.jsx(g,{label:"Jeda antar-seksi (langkah)",hint:"pemisah Guard–Brass–Battery",children:a.jsx(b,{"data-testid":"parade-input-spasi-seksi",type:"number",step:"1",min:1,max:12,value:_,onChange:e=>ma(Math.max(1,Number(e.target.value)||4))})}),a.jsx(g,{label:"Personel Spanduk/Pataka",hint:"0 = tanpa baris spanduk khusus",children:a.jsx(b,{"data-testid":"parade-input-spanduk",type:"number",min:0,max:12,value:U,onChange:e=>ua(Math.max(0,Math.round(Number(e.target.value)||0)))})}),a.jsx("div",{className:"flex flex-col justify-end",children:a.jsxs("div",{className:"rounded-lg border border-slate-800 bg-slate-900/70 px-3 py-2 text-[11px] text-slate-300",children:[a.jsxs("div",{children:["Total: ",a.jsx("b",{children:m.jumlahPemain})," anggota →"," ",a.jsxs("b",{children:[m.jumlahSaf," saf"]})]}),a.jsxs("div",{className:"text-slate-400",children:["Panjang barisan: ",a.jsxs("b",{children:[String(m.panjangBarisanM).replace(".",",")," m"]})]})]})})]}),a.jsxs("div",{"data-testid":"parade-status-jalan",className:`rounded-xl border p-3 text-xs ${C.status==="aman"?"border-emerald-500/40 bg-emerald-500/10 text-emerald-200":C.status==="mepet"?"border-amber-500/40 bg-amber-500/10 text-amber-200":"border-rose-500/50 bg-rose-500/15 text-rose-200"}`,children:[a.jsxs("div",{className:"font-semibold",children:["Lebar barisan ",String(C.lebarBarisanM).replace(".",",")," m di dalam jalan efektif"," ",String(C.lebarEfektifM).replace(".",",")," m (total aspal ",String(C.lebarJalanM).replace(".",",")," m)"]}),a.jsx("div",{className:"mt-0.5 opacity-90",children:C.pesan})]}),a.jsxs("div",{className:"rounded-xl border border-slate-800 bg-slate-950/60 p-3",children:[a.jsx("div",{className:"mb-2 text-xs font-medium text-slate-300",children:"Urutan blok dari kepala barisan (depan) ke ekor barisan:"}),a.jsx("div",{className:"flex flex-wrap gap-1.5",children:D.map((e,i)=>a.jsxs("div",{className:"flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-slate-200",children:[a.jsxs("span",{className:"font-mono text-[10px] text-sky-400",children:[i+1,"."]}),a.jsx("span",{children:Ja[e]}),a.jsx("button",{type:"button",onClick:()=>na(i,-1),disabled:i===0,className:"ml-1 rounded px-1 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30",title:"Maju ke depan",children:"←"}),a.jsx("button",{type:"button",onClick:()=>na(i,1),disabled:i===D.length-1,className:"rounded px-1 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30",title:"Mundur ke belakang",children:"→"})]},e))})]}),a.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2 pt-1",children:[a.jsxs("span",{className:"text-[11px] text-slate-400",children:["Menyusun titik pada ",a.jsx("b",{children:B})," (bisa dibatalkan kapan saja dengan Undo / Ctrl+Z)."]}),a.jsxs(y,{variant:"primary","data-testid":"parade-terapkan-banjar-saf",onClick:()=>void ya(),children:["Terapkan Banjar × Saf ke ",B]})]})]}),v==="tikungan-vip"&&a.jsxs("div",{className:"grid gap-3 sm:grid-cols-2",children:[a.jsxs("div",{className:"flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-950/60 p-3.5",children:[a.jsxs("div",{className:"space-y-2.5",children:[a.jsxs("div",{className:"flex items-center justify-between gap-2",children:[a.jsx("h3",{className:"text-sm font-semibold text-slate-100",children:"Simulasi Tikungan 90° (Wheel Turn)"}),a.jsxs(G,{className:T.analisis.amanLangkahLuar?"border-emerald-500/40 bg-emerald-500/15 text-emerald-200":"border-rose-500/40 bg-rose-500/15 text-rose-200",children:[T.analisis.hitunganDipakaiPerSaf," hitungan/saf"]})]}),a.jsxs("p",{className:"text-xs leading-relaxed text-slate-400",children:["Membuat 2 set berurutan (",a.jsx("b",{children:"Poros Tikungan"})," → ",a.jsx("b",{children:"Selesai Belok 90°"}),") memakai gerak sapuan poros banjar dalam tanpa mengacak urutan saf."]}),a.jsx(g,{label:"Hitungan putar per saf",hint:`Saran busur luar: ${T.analisis.hitunganSaranPerSaf} ketukan`,children:a.jsx(b,{"data-testid":"parade-input-hitungan-putar",type:"number",min:4,step:4,placeholder:`Otomatis (${T.analisis.hitunganSaranPerSaf})`,value:L,onChange:e=>ga(e.target.value)})}),a.jsxs("label",{className:"flex items-center gap-2 text-xs text-slate-300",children:[a.jsx("input",{type:"checkbox",checked:X,onChange:e=>ba(e.target.checked),className:"rounded border-slate-600 bg-slate-900"}),"Perluas ruang simpang kanvas otomatis bila ekor barisan panjang"]}),a.jsx("div",{className:"rounded-lg border border-slate-800 bg-slate-900/80 p-2.5 text-[11px] text-slate-300",children:T.analisis.catatanTeknis})]}),a.jsxs("div",{className:"mt-3 flex flex-wrap gap-2",children:[a.jsx(y,{size:"sm",variant:"primary","data-testid":"parade-buat-belok-kanan",onClick:()=>void sa("kanan"),children:"+ Belok Kanan 90°"}),a.jsx(y,{size:"sm",variant:"soft","data-testid":"parade-buat-belok-kiri",onClick:()=>void sa("kiri"),children:"+ Belok Kiri 90°"})]})]}),a.jsxs("div",{className:"flex flex-col justify-between rounded-xl border border-amber-500/30 bg-slate-950/60 p-3.5",children:[a.jsxs("div",{className:"space-y-2.5",children:[a.jsxs("div",{className:"flex items-center justify-between gap-2",children:[a.jsx("h3",{className:"text-sm font-semibold text-amber-200",children:"Penghormatan & Display VIP"}),a.jsxs(G,{className:"border-amber-500/40 bg-amber-500/15 text-amber-200",children:["VIP ",s.panjangPanggungM," m"]})]}),a.jsxs("p",{className:"text-xs leading-relaxed text-slate-400",children:["Susun penghormatan sambil berjalan (",a.jsx("i",{children:"eyes right/left"}),") atau buka formasi ",a.jsx("i",{children:"company front"})," singkat menghadap ",a.jsx("b",{children:s.labelPanggung})," lalu kembali ke susunan Banjar × Saf semula!"]}),a.jsx(g,{label:"Durasi set Display VIP (hitungan)",children:a.jsx(b,{"data-testid":"parade-input-hitungan-display",type:"number",min:8,step:4,value:aa,onChange:e=>xa(Math.max(8,Number(e.target.value)||16))})}),a.jsxs("div",{className:"rounded-lg border border-amber-500/20 bg-amber-500/5 p-2.5 text-[11px] text-amber-100/90",children:["Posisi panggung: ",a.jsx("b",{children:s.sisiPanggung==="belakang"?"Tepi Belakang (Atas)":"Tepi Depan (Penonton)"})," · Titik tengah ",a.jsxs("b",{children:[s.posisiPanggungM," m"]}),". Urutan banjar & saf dijamin pulih 100% seusai display."]})]}),a.jsxs("div",{className:"mt-3 flex flex-col gap-2",children:[a.jsx(y,{size:"sm",variant:"soft","data-testid":"parade-buat-hormat-jalan",onClick:()=>void ra("hormat_jalan"),children:"+ Set Defile Hormat Jalan (Tanpa Berhenti)"}),a.jsx(y,{size:"sm",variant:"primary","data-testid":"parade-buat-display-vip",onClick:()=>void ra("display_buka_tutup"),children:"+ 3 Set Display Panggung VIP → Kembali Defile"})]})]})]}),v==="kalkulator-rute"&&a.jsxs("div",{className:"space-y-3",children:[a.jsxs("div",{className:"flex flex-wrap items-center gap-1.5 text-xs",children:[a.jsx("span",{className:"text-slate-400",children:"Preset jarak rute:"}),[500,1e3,1500,2500,4e3].map(e=>a.jsx("button",{type:"button","data-testid":`parade-rute-cepat-${e}`,onClick:()=>ea(e),className:`rounded-lg border px-2.5 py-1 font-medium transition ${N===e?"border-emerald-500/60 bg-emerald-500/20 text-emerald-200":"border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500"}`,children:e>=1e3?`${String(e/1e3).replace(".",",")} km`:`${e} m`},e))]}),a.jsxs("div",{className:"grid gap-3 sm:grid-cols-3",children:[a.jsx(g,{label:"Panjang rute kirab (meter)",children:a.jsx(b,{"data-testid":"parade-input-rute-m",type:"number",min:50,step:100,value:N,onChange:e=>ea(Math.max(50,Number(e.target.value)||500))})}),a.jsx(g,{label:"Tempo langkah (BPM)",children:a.jsx(b,{"data-testid":"parade-input-bpm",type:"number",min:60,max:220,value:H,onChange:e=>ha(Math.max(60,Math.min(220,Number(e.target.value)||116)))})}),a.jsx(g,{label:"Panjang langkah (cm)",hint:"8-to-5 = 57,2 cm · PDBI = 60–65 cm",children:a.jsx(b,{"data-testid":"parade-input-langkah-cm",type:"number",step:"0.5",min:30,max:100,value:F,onChange:e=>ka(Math.max(30,Math.min(100,Number(e.target.value)||60)))})}),a.jsx(g,{label:"Durasi 1 putaran lagu (detik)",hint:o?`Lagu: ${o.title}`:"durasi medli / repertoar",children:a.jsx(b,{"data-testid":"parade-input-durasi-lagu",type:"number",min:20,step:10,value:W,onChange:e=>ja(Math.max(20,Number(e.target.value)||120))})}),a.jsx(g,{label:"Jeda street beat perkusi (ketukan)",hint:"cadangan napas Brass antar-lagu",children:a.jsx(b,{"data-testid":"parade-input-street-beat",type:"number",min:0,step:8,value:Z,onChange:e=>fa(Math.max(0,Math.round(Number(e.target.value)||0)))})}),a.jsx(g,{label:"Tambahan waktu display VIP (menit)",children:a.jsx(b,{"data-testid":"parade-input-display-menit",type:"number",min:0,step:"0.5",value:q,onChange:e=>va(Math.max(0,Number(e.target.value)||0))})})]}),a.jsxs("div",{"data-testid":"parade-hasil-rute",className:"grid gap-2.5 sm:grid-cols-4",children:[a.jsxs("div",{className:"rounded-xl border border-slate-800 bg-slate-900/80 p-3",children:[a.jsx("div",{className:"text-[11px] text-slate-400",children:"Total Waktu Tempuh"}),a.jsxs("div",{"data-testid":"parade-waktu-tempuh",className:"mt-0.5 text-lg font-bold text-white",children:[String(c.totalWaktuTempuhMenit).replace(".",",")," mnt"]}),a.jsxs("div",{className:"text-[11px] text-slate-500",children:["Jalan murni ",String(c.waktuJalanMenit).replace(".",",")," mnt"]})]}),a.jsxs("div",{className:"rounded-xl border border-slate-800 bg-slate-900/80 p-3",children:[a.jsx("div",{className:"text-[11px] text-slate-400",children:"Kecepatan & Langkah"}),a.jsxs("div",{className:"mt-0.5 text-lg font-bold text-sky-300",children:[String(c.kecepatanKmPerJam).replace(".",",")," km/jam"]}),a.jsxs("div",{className:"text-[11px] text-slate-500",children:[c.totalLangkah.toLocaleString("id-ID")," langkah (",String(c.kecepatanMPerMenit).replace(".",",")," m/mnt)"]})]}),a.jsxs("div",{className:"rounded-xl border border-slate-800 bg-slate-900/80 p-3",children:[a.jsx("div",{className:"text-[11px] text-slate-400",children:"Pengulangan Lagu"}),a.jsxs("div",{"data-testid":"parade-ulang-lagu",className:"mt-0.5 text-lg font-bold text-amber-300",children:[c.jumlahPengulanganLagu,"× siklus"]}),a.jsxs("div",{className:"text-[11px] text-slate-500",children:["Tiap siklus menempuh ",Math.round(c.jarakSatuSiklusM)," m"]})]}),a.jsxs("div",{className:"rounded-xl border border-slate-800 bg-slate-900/80 p-3",children:[a.jsx("div",{className:"text-[11px] text-slate-400",children:"Cadangan Napas Tiup"}),a.jsxs("div",{className:"mt-0.5 text-lg font-bold text-emerald-300",children:[String(c.rasioCadanganNapasPersen).replace(".",","),"%"]}),a.jsxs("div",{className:"text-[11px] text-slate-500",children:["Istirahat ",Math.round(c.jarakStreetBeatM)," m per siklus"]})]})]}),a.jsx("div",{"data-testid":"parade-status-napas",className:`rounded-xl border p-3 text-xs ${c.statusKetahanan==="nyaman"?"border-emerald-500/40 bg-emerald-500/10 text-emerald-200":c.statusKetahanan==="padat"?"border-amber-500/40 bg-amber-500/10 text-amber-200":"border-rose-500/50 bg-rose-500/15 text-rose-200"}`,children:c.rekomendasiNapas}),a.jsxs("div",{className:"flex flex-wrap items-center justify-end gap-2 pt-1",children:[a.jsx(y,{variant:"soft","data-testid":"parade-simpan-rute",onClick:()=>void Sa(),children:"Simpan Rute ke Drill"}),a.jsx(y,{variant:"primary","data-testid":"parade-cetak-komando",onClick:Na,children:"Cetak / Unduh Lembar Komando A4"})]})]})]})})}export{qa as default};
