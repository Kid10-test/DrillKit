import{u as B,r as b,j as i,C as I,B as m,Q as x,I as P,U as A,M as U,V as S,c as p,v as z,a6 as Q,x as k}from"./index-B6hICtPp.js";import{Q as F}from"./browser-D336jNTx.js";import{a as C,e as o,d as v}from"./print-DaFPw0oz.js";import{f as M}from"./laporan-n_UkZuYX.js";import{D as J}from"./shortcut-CgKN3uSp.js";import{D as E}from"./tuner-CPm15e5L.js";const D=2;function oa(a,t){var e,r,s;const n=[...a].sort((u,d)=>u.order-d.order),l=[];for(let u=0;u+1<n.length;u++){const d=n[u],g=n[u+1],y=(e=d.points)==null?void 0:e[t],j=(r=g.points)==null?void 0:r[t];!y||!j||l.push({dariSetId:d.id,keSetId:g.id,dariNama:d.name,keNama:g.name,counts:(s=d.counts)!=null?s:0,dari:{x:y.x,y:y.y},kunci:{x:j.x,y:j.y}})}return l}function da(a,t,n,l=D){const e=Math.hypot(a.x-t.x,a.y-t.y)/n;return{jarakLangkah:Math.round(e*100)/100,benar:e<=l+1e-9}}function ma(a,t){if(!t)return[...a];let n=t>>>0;const l=()=>{n|=0,n=n+1831565813|0;let r=Math.imul(n^n>>>15,1|n);return r=r+Math.imul(r^r>>>7,61|r)^r,((r^r>>>14)>>>0)/4294967296},e=[...a];for(let r=e.length-1;r>0;r--){const s=Math.floor(l()*(r+1));[e[r],e[s]]=[e[s],e[r]]}return e}const O=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function K(a){const t=new Date,n=`${t.getDate()} ${O[t.getMonth()]} ${t.getFullYear()}`;return a?`${a}, ${n}`:n}function h(a,t){return`<tr><td>${a}</td><td>${t}</td></tr>`}const q=[["Susun formasi &amp; impor Pyware","Menu <b>Drill &amp; Formasi</b>: tambah set (atau tombol <b>Pyware</b> untuk impor CSV koordinat Pyware 3D), geser titik (Panah = 1 langkah, Shift + Panah = 4), cocokkan garis waktu segmen lagu × set, lalu <b>Putar</b>. Tombol <b>F</b> membuka presenter layar penuh."],["Bawa ke lapangan","Di editor: <b>Dot sheet &amp; buku saku</b> → <b>Pratinjau</b> → <b>Cetak</b> di kertas A4. Potong mengikuti garis tepi dan lipat garis putus-putusnya menjadi kartu saku 9,5 × 13,5 cm."],["Partitur, frasa, &amp; penala","Menu <b>Musik &amp; Metronom</b>: pasang partitur (<i>.musicxml</i>/<i>.mxl</i>/<i>.pdf</i>) → <b>Buka partitur</b> (filter part/seksi, <b>Pilih frasa di partitur</b> + tempo latihan, cetak buku saku Lyre A5) &amp; selaraskan MP3. Kartu <b>Penala &amp; nada dengung</b>: pilih <b>Instrumen</b> (trumpet Bb, mellophone F, sax Eb), tombol <b>Bb konser</b> → <b>Putar dengung</b> → <b>Dengarkan</b>."],["Jadwal, absensi, &amp; lomba","<b>Jadwal</b>: kalender/agenda &amp; ekspor .ics. <b>Absensi</b>: isi manual atau scan QR · tab <b>Rekap</b> untuk laporan &amp; kartu kehadiran. <b>Run sheet hari lomba</b> untuk jadwal hari H."],["Terbitkan ke anggota","<b>Berbagi</b>: terbitkan materi satu tombol (grup atau terkunci QR per anak) lalu kirim lewat WhatsApp. Anggota memilih namanya sekali untuk melihat jadwal, formasi, partitur, &amp; kehadirannya. Sertakan <b>Panduan anggota</b>."],["Buka berkas &amp; kolaborasi pelatih","Seret berkas apa pun ke layar atau klik <b>Buka berkas DrillKit</b> (di Dashboard / <b>Impor &amp; ekspor data</b>) untuk pratinjau otomatis. Untuk bagi tugas set antar pelatih: tombol ⚙ di drill → <b>Ekspor show</b> / <b>Impor show</b>."]],_=[["Dashboard","Ringkasan kehadiran, jadwal terdekat, komposisi tim, &amp; pintu <b>Buka berkas DrillKit</b>"],["Anggota","Nama resmi &amp; panggilan, impor CSV, gabung duplikat, cetak kartu QR absensi"],["Absensi &amp; Evaluasi","Scan QR / manual, tab <b>Rekap</b> laporan, serta <b>Evaluasi &amp; kemajuan</b> set"],["Jadwal &amp; Lomba","Kalender/agenda latihan, seri berulang, .ics, &amp; <b>Run sheet hari lomba</b>"],["Drill &amp; Formasi","Editor formasi, penggaris musik × drill, impor CSV <b>Pyware</b>, presenter, buku saku"],["Musik &amp; Metronom","Metronom &amp; tempo map, tempo latihan, rekaman MP3, partitur &amp; cetak Lyre, penala"],["Berbagi","Terbitkan paket grup / terkunci QR per anggota, mode anggota, &amp; panduan anggota"],["Impor &amp; ekspor data","Pusat <b>Buka berkas DrillKit</b> (JSON/CSV/ZIP/Pyware/partitur) &amp; ekspor pilihan"],["Pengaturan","Profil tim, lapangan (yard/meter &amp; patok), PIN pelatih/kios, backup &amp; pulihkan"]];function G(a,t){return[["Tombol <b>Cetak</b> tidak memunculkan apa-apa","Browser memblokir jendela baru. Pakai <b>Pratinjau</b> (tampil di dalam aplikasi), atau <b>Unduh HTML</b> lalu buka berkasnya dan tekan Ctrl + P."],["Mikrofon penala tidak mau menyala","Klik ikon gembok di kiri alamat → izinkan <b>Mikrofon</b>. Buka aplikasi di tab browser biasa, bukan di dalam pratinjau."],["Muncul <i>“Penyimpanan browser belum bisa dipakai”</i>",t?"Berkas DrillKit.html dibuka di dalam pratinjau/iframe atau mode penyamaran. Buka berkasnya lewat browser (Files → Chrome), bukan dari dalam pratinjau.":"Halaman dibuka di dalam iframe/pratinjau atau mode penyamaran. Buka aplikasi di tab browser biasa supaya data bisa tersimpan."],["Takut data hilang / mau pindah perangkat",`<b>Pengaturan → Kelola data → Ekspor backup (JSON)</b> atau <b>Backup + rekaman (ZIP)</b> (agar MP3 &amp; partitur ikut), lalu <b>Pulihkan backup</b> di perangkat baru.${a>0?` Pengingat menyala tiap <b>${a} hari</b>.`:""}`]]}function V(a){const t=a.logo?`<img src="${o(a.logo)}" alt="logo" />`:"",n=[];n.push(`<h2>Mulai dari sini</h2>
    <ol>
      ${q.map(([e,r])=>`<li><b>${e}.</b> ${r}</li>`).join(`
      `)}
    </ol>`),n.push(`<h2>Isi tiap menu</h2>
    <table>
      <thead><tr><th style="width:28%">Menu</th><th>Untuk apa</th></tr></thead>
      <tbody>${_.map(([e,r])=>h(`<b>${e}</b>`,r)).join("")}</tbody>
    </table>`),n.push(`<h2>Shortcut di editor formasi <span style="font-weight:400;color:#666">(tekan ? untuk daftar lengkap di layar)</span></h2>
    ${J.map(e=>`<table>
      <thead><tr><th style="width:30%">${o(e.kelompok)}</th><th>Keterangan</th></tr></thead>
      <tbody>${e.baris.map(([r,s])=>h(`<b>${o(r)}</b>`,o(s))).join("")}</tbody>
    </table>`).join(`
    `)}`),n.push(`<h2>Kalau macet</h2>
    <table>
      <thead><tr><th style="width:38%">Gejala</th><th>Cara mengatasi</th></tr></thead>
      <tbody>${G(a.hariBackup,a.portabel).map(([e,r])=>h(e,r)).join("")}</tbody>
    </table>`);const l=a.section.length?a.section.map(e=>o(e.label)).join(", "):"belum diatur";return n.push(`<h2>Yang perlu diingat</h2>
    <div class="kotak">
      <ul>
        <li>Data tersimpan <b>hanya di perangkat ini</b> — bukan di server. Backup berkala (JSON/ZIP) itu wajib.</li>
        <li>Bekerja <b>offline</b>: sekali dibuka, formasi, metronom, rekaman, &amp; partitur tetap jalan tanpa sinyal.</li>
        <li>Section tim ini: <b>${l}</b>. Standar lapangan (yard/meter &amp; patok) dan PIN diatur di <b>Pengaturan</b>.</li>
        <li>Tidak sengaja mengubah formasi? <b>Ctrl + Z</b> berulang kali; <b>Ctrl + Shift + Z</b> untuk mengulang.</li>
      </ul>
    </div>`),`
    <div class="kop">
      ${t}
      <div>
        <div class="nama">${o(a.namaTim||"Marching Band")}</div>
        <div class="sub">Panduan Singkat DrillKit · dicetak ${o(K(a.kota))} · ${a.anggotaAktif} anggota aktif · ${a.sesi} sesi · ${a.drill} drill · ${a.lagu} lagu</div>
      </div>
    </div>
    <div class="isi">
      ${n.join(`
      `)}
      <p class="catatan">
        Lembar ini dibuat otomatis oleh DrillKit dari pengaturan tim ini, jadi isinya mengikuti data &amp;
        kebiasaan tim saat ini${a.pelatih?` — pelatih: ${o(a.pelatih)}`:""}.
        Bagikan ke pelatih lain atau anggota yang baru mulai.
      </p>
    </div>`}const N=`
    @page { size: A4 portrait; margin: 8.5mm 8mm; }
    body { font-size: 8.1pt; line-height: 1.27; color:#000; }
    .kop { display:flex; align-items:center; gap:8px; border-bottom:2px solid #111; padding-bottom:4px; margin-bottom:5px; }
    .kop img { height:30px; width:auto; }
    .kop .nama { font-size:11.5pt; font-weight:700; line-height:1.15; }
    .kop .sub { font-size:7.2pt; color:#555; }
    .isi { column-count:2; column-gap:5.5mm; }
    h2 { font-size:8.4pt; margin:5px 0 2.5px; padding-left:4px; border-left:3px solid #111; break-after:avoid; }
    ol, ul { margin:2px 0 3.5px; padding-left:12px; }
    li { margin-bottom:2px; break-inside:avoid; }
    table { width:100%; border-collapse:collapse; margin:2px 0 4px; }
    th, td { border:1px solid #aaa; padding:1.4px 3px; text-align:left; vertical-align:top; }
    th { background:#eef2f7; font-size:7.2pt; text-transform:uppercase; }
    .kotak { border:1px solid #bbb; background:#fafafa; padding:3.5px 5.5px; margin:2.5px 0 3.5px; break-inside:avoid; }
    .catatan { font-size:7pt; color:#444; margin-top:5px; border-top:1px solid #ccc; padding-top:3.5px; }
    .qr { display:flex; gap:6px; align-items:center; border:1px solid #bbb; padding:3.5px; margin:2.5px 0 3.5px; break-inside:avoid; }
    .qr img { width:22mm; height:22mm; }
    .qr .alamat { font-family:monospace; font-size:7.2pt; word-break:break-all; }
`;function R(a){return C(`Panduan DrillKit — ${a.namaTim}`,V(a),N)}function Z(){return[["Jadwal","Kalender <b>Bulan</b> dan <b>Agenda</b> berisi jadwal pelatih dan materi tiap sesi. Pilih tanggal untuk melihat detail; kalender anggota hanya baca. Status kehadiran pribadimu muncul dari catatan terkunci setelah paket diperbarui dengan QR kunci."],["Formasi","Posisimu (titik <b>emas</b>) di tiap set. Tombol <b>‹ ›</b> pindah set; tertulis koordinat, jumlah langkah, dari mana kamu datang dan ke mana pindah. <b>Putar perpindahan</b> menunjukkan gerakannya."],["Kuis",`Latihan hafalan: ketuk di peta tempat kamu berdiri di set berikutnya, lalu <b>Kunci jawaban</b>. Dihitung <b>tepat</b> bila meleset paling jauh ${D} langkah.`],["Absensi","Rekap kehadiranmu menurut catatan pelatih. <b>Belum dicatat</b> artinya pelatih belum mengisi sesi itu — <b>bukan</b> berarti kamu tidak hadir."],["Catatan","Catatan evaluasi dari pelatih, khusus untukmu."],["Musik","Metronom, lagu, set list (beserta tautan set drill ↔ birama), penala, rekaman MP3 (<b>Tambahkan rekaman dari pelatih</b>), dan partitur per instrumen (<b>Buka partitur</b>, cetak buku saku Lyre)."]]}function W(a){const t=[];return a&&t.push(["Halaman “link rusak” / <i>Aplikasi gagal dimuat</i>","HP-mu masih menyimpan versi lama. Tekan <b>Bersihkan &amp; muat ulang</b> di layar itu. Data di dalam aplikasi tidak ikut terhapus."]),t.push(["Berkas <i>.json</i> dari WhatsApp tidak mau terbuka","Jangan diketuk dari chat. Unduh/simpan dulu, lalu di DrillKit tekan <b>Buka paket tim</b> (atau <b>Ganti paket</b>) dan pilih berkasnya dari folder Unduhan."],["Muncul <i>“Penyimpanan browser belum bisa dipakai”</i>","Buka DrillKit di tab browser biasa — bukan mode penyamaran dan bukan dari pratinjau di dalam aplikasi chat."],["Mikrofon penala tidak menyala","Izinkan <b>Mikrofon</b> untuk halaman ini (ikon gembok/pengaturan di sebelah alamat), lalu tekan <b>Dengarkan</b> lagi."],["Terlanjur memilih <i>Saya pelatih</i>","Buka menu <b>Berbagi</b> → <b>Lihat mode anggota</b>. Kalau HP ini diminta PIN untuk keluar dari mode anggota, itu memang disengaja pelatih."],["Rekaman audio / partitur di iPhone terhapus sendiri","Di iPhone/iPad (Safari), pasang DrillKit ke Layar Utama (<b>Add to Home Screen</b>) agar browser tidak membersihkan rekaman &amp; partitur setelah 7 hari tidak dibuka."]),t}function Y(a){const t=a.logo?`<img src="${o(a.logo)}" alt="logo" />`:"",n=!!a.alamat,l=[],e=n?`<div class="qr">
        ${a.qr?`<img src="${o(a.qr)}" alt="Kode QR alamat DrillKit" />`:""}
        <div>Pindai kode ini dengan kamera HP, atau ketik alamatnya:<br/><span class="alamat">${o(a.alamat)}</span></div>
      </div>
      <ol>
        <li>Pertama kali dibuka, pilih <b>Saya anggota</b>.</li>
        <li>Supaya bisa dibuka tanpa sinyal, pasang ke layar utama — Android (Chrome): menu <b>⋮</b> → <b>Install aplikasi</b> / <b>Tambahkan ke layar utama</b>. iPhone (Safari): tombol <b>Bagikan</b> → <b>Add to Home Screen</b>.</li>
      </ol>`:`<ol>
        <li>Pelatih mengirim berkas <b>DrillKit.html</b>. Simpan/unduh dulu, lalu buka dengan browser (Chrome atau Safari) — jangan dari pratinjau di dalam aplikasi chat.</li>
        <li>Pertama kali dibuka, pilih <b>Saya anggota</b>.</li>
      </ol>`;l.push(`<h2>1. Buka DrillKit</h2>${e}`),l.push(`<h2>2. Masukkan materi tim</h2>
    <ol>
      ${n?"<li>Tekan <b>Ambil materi dari situs</b>. Atau, bila pelatih mengirim berkas <i>.json</i>: unduh berkasnya, tekan <b>Buka paket tim</b>, lalu pilih berkas itu.</li>":"<li>Pelatih juga mengirim berkas <i>.json</i>. Unduh berkasnya, tekan <b>Buka paket tim</b>, lalu pilih berkas itu dari folder Unduhan.</li>"}
      <li>Berkas <b>atas namamu</b> (mis. <i>DrillKit-Nama-Kode.json</i>) langsung mengenali namamu. Berkas <b>grup</b>: ketik nama atau kodemu di <b>Pilih namamu dulu</b> — cukup sekali. Salah nama? Tekan <b>Ganti nama</b>.</li>
      <li><b>Absensi</b> dan <b>Catatan</b> hanya terisi dari berkas atas namamu (atau setelah memindai QR kunci pribadimu); berkas grup tidak memuat data pribadi siapa pun.</li>
    </ol>`),l.push(`<h2>3. Isi tiap tab</h2>
    <table>
      <thead><tr><th style="width:18%">Tab</th><th>Untuk apa</th></tr></thead>
      <tbody>${Z().map(([s,u])=>h(`<b>${s}</b>`,u)).join("")}</tbody>
    </table>`),l.push(`<h2>4. Menala sesuai instrumenmu</h2>
    <p style="margin:2px 0 3px">Tab <b>Musik</b> → kartu <b>Penala &amp; nada dengung</b>. Pilih <b>Instrumen</b> sekali (diingat di HP ini), supaya nada yang tampil sama dengan partiturmu:</p>
    <table>
      <thead><tr><th style="width:26%">Pilih</th><th>Untuk</th></tr></thead>
      <tbody>${E.map(s=>h(`<b>${o(s.label)}</b>`,o(s.contoh))).join("")}</tbody>
    </table>
    <p style="margin:2px 0 3px">Tekan <b>Putar dengung</b> (tombol cepat <b>Bb konser</b>), lalu <b>Dengarkan</b> dan mainkan nadanya. Jarum hijau di tengah (±5 sen) = tepat. Angka <b>minus</b> = terlalu rendah (dorong slide/mouthpiece masuk); <b>plus</b> = terlalu tinggi (tarik keluar).</p>`),l.push(`<h2>5. Rekaman audio &amp; partitur latihan</h2>
    <p style="margin:2px 0 3px">Di tab <b>Musik</b>, buka lagu: tekan <b>Tambahkan rekaman dari pelatih</b> untuk memasang MP3 (sidik rekaman dicocokkan ✔) dan <b>Tambahkan dari pelatih</b> untuk berkas partitur (<i>.musicxml</i>/<i>.mxl</i>/<i>.pdf</i>). Tekan <b>Buka partitur</b> — notasi tersaring otomatis ke instrumenmu (tombol <b>Ke part saya</b>), birama aktif disorot mengikuti musik, dan <b>Pilih frasa di partitur</b> mengulang bagian sulit dengan tempo latihan. Berkas disimpan offline di HP dan <b>tidak terhapus</b> saat kamu memperbarui materi paket.</p>`),l.push(`<h2>6. Kalau materi berubah</h2>
    <ul>
      ${n?"<li>Kalau muncul tulisan <b>Ada materi baru dari pelatih</b>, tekan <b>Perbarui</b>. Absensi, catatan, dan setelan latihan yang kamu ubah sendiri <b>tidak</b> ikut tertimpa.</li>":""}
      <li>Pelatih mengirim berkas baru? Tekan <b>Ganti paket</b> dan pilih berkas terbarunya.</li>
      <li>Yang kamu ubah di HP-mu <b>tidak</b> terkirim ke pelatih. Absensi selalu diisi pelatih.</li>
    </ul>`),l.push(`<h2>7. Kalau macet</h2>
    <table>
      <thead><tr><th style="width:38%">Gejala</th><th>Cara mengatasi</th></tr></thead>
      <tbody>${W(n).map(([s,u])=>h(s,u)).join("")}</tbody>
    </table>`),l.push(`<h2>Yang perlu diingat</h2>
    <div class="kotak">
      <ul>
        <li>Tidak perlu akun. Materi tersimpan <b>hanya di HP-mu</b> dan tetap bisa dibuka tanpa sinyal.</li>
        <li>Berkas <b>atas namamu</b> / QR kunci pribadimu berisi absensi &amp; catatanmu — jangan diteruskan ke orang lain.</li>
      </ul>
    </div>`);const r=[a.sesiMendatang?`${a.sesiMendatang} jadwal mendatang`:"",a.drill?`${a.drill} drill`:"",a.lagu?`${a.lagu} lagu`:""].filter(Boolean);return`
    <div class="kop">
      ${t}
      <div>
        <div class="nama">${o(a.namaTim||"Marching Band")}</div>
        <div class="sub">Panduan Anggota DrillKit · dicetak ${o(K(a.kota))}${r.length?" · "+r.join(" · "):""}</div>
      </div>
    </div>
    <div class="isi">
      ${l.join(`
      `)}
      <p class="catatan">
        Lembar ini dibuat otomatis oleh DrillKit untuk anggota ${o(a.namaTim||"tim")}${a.pelatih?` — pelatih: ${o(a.pelatih)}`:""}.
        Ada yang belum jelas? Tanyakan ke pelatih.
      </p>
    </div>`}function L(a){return C(`Panduan Anggota DrillKit — ${a.namaTim}`,Y(a),N)}const f={pelatih:"panduan-drillkit.html",anggota:"panduan-anggota-drillkit.html"};function X(){return typeof location=="undefined"||!/^https?:$/.test(location.protocol)?"":`${location.origin}${location.pathname}`}function $(){const a=S(),t=p(()=>k.members.toArray(),[],[]),n=p(()=>k.sessions.toArray(),[],[]),l=p(()=>k.drills.toArray(),[],[]),e=p(()=>k.songs.toArray(),[],[]);return b.useMemo(()=>{var r;return{namaTim:a.teamName,kota:a.city,pelatih:a.coachName,logo:a.logo,section:z(),anggotaAktif:t.filter(s=>s.active).length,sesi:n.length,drill:l.length,lagu:e.length,hariBackup:(r=a.backupIntervalDays)!=null?r:7,portabel:typeof location!="undefined"&&location.protocol==="file:"}},[a,t,n,l,e])}function w(a){try{const t=new URL(a).hostname;return t==="localhost"||t.endsWith(".local")||/^127\./.test(t)||/^10\./.test(t)||/^192\.168\./.test(t)||/^172\.(1[6-9]|2\d|3[01])\./.test(t)||/^169\.254\./.test(t)}catch{return!1}}function T(){const a=S(),t=p(()=>k.sessions.toArray(),[],[]),n=p(()=>k.drills.toArray(),[],[]),l=p(()=>k.songs.toArray(),[],[]),e=X(),[r,s]=b.useState(void 0);return b.useEffect(()=>{if(!e)return;let u=!1;return F.toDataURL(e,{width:320,margin:1,errorCorrectionLevel:"M"}).then(d=>{u||s(d)}).catch(()=>{}),()=>{u=!0}},[e]),b.useMemo(()=>({namaTim:a.teamName,kota:a.city,pelatih:a.coachName,logo:a.logo,alamat:e||void 0,qr:e?r:void 0,sesiMendatang:t.filter(u=>Q(u.date)>=0).length,drill:n.length,lagu:l.length}),[a,e,r,t,n,l])}function c({open:a,onClose:t,data:n,jenis:l="pelatih",dataAnggota:e}){const r=B(),s=b.useMemo(()=>a?l==="anggota"?e?L(e):"":n?R(n):"":"",[a,l,n,e]),u=f[l];return i.jsx(U,{open:a,onClose:t,title:l==="anggota"?"Pratinjau panduan anggota (1 halaman)":"Pratinjau panduan 1 halaman",wide:!0,footer:i.jsxs(i.Fragment,{children:[i.jsx(m,{variant:"ghost",onClick:t,children:"Tutup"}),i.jsxs(m,{"data-testid":"tombol-unduh-panduan",onClick:()=>{v(s,u),r.push("Panduan diunduh sebagai HTML — buka lalu Ctrl+P")},children:[i.jsx(P,{size:14})," Unduh HTML"]}),i.jsxs(m,{"data-testid":"tombol-cetak-panduan",variant:"primary",onClick:()=>{M(s,u)?r.push("Panduan dibuka di jendela cetak"):r.push("Jendela cetak diblokir — berkas HTML diunduh. Buka lalu Ctrl+P.","info")},children:[i.jsx(A,{size:14})," Cetak"]})]}),children:s&&i.jsx("iframe",{"data-testid":"bingkai-panduan",title:"Pratinjau panduan","data-jenis":l,srcDoc:s,className:"h-[65vh] w-full rounded-lg border border-slate-800 bg-white"})})}function H({onClose:a}){const t=$();return i.jsx(c,{open:!0,onClose:a,data:t})}function aa({label:a="Panduan"}){const[t,n]=b.useState(!1);return i.jsxs(i.Fragment,{children:[i.jsxs(m,{"data-testid":"tombol-panduan-dasbor",onClick:()=>n(!0),title:"Panduan pemakaian 1 halaman",children:[i.jsx(x,{size:16})," ",a]}),t&&i.jsx(H,{onClose:()=>n(!1)})]})}function ta({label:a="Panduan anggota"}){const t=T(),[n,l]=b.useState(!1);return i.jsxs(i.Fragment,{children:[i.jsxs(m,{"data-testid":"tombol-panduan-anggota-berbagi",onClick:()=>l(!0),title:"Panduan 1 halaman untuk HP anggota",children:[i.jsx(x,{size:16})," ",a]}),t.alamat&&w(t.alamat)&&i.jsxs("p",{className:"mt-2 text-[11px] leading-relaxed text-amber-300","data-testid":"peringatan-alamat-lokal-berbagi",children:["Alamat ",t.alamat," hanya bisa dibuka dari perangkat/jaringan ini — kode QR di lembarnya tidak akan terbuka di HP anggota. Cetak dari situs yang sudah diunggah."]}),i.jsx(c,{open:n,onClose:()=>l(!1),jenis:"anggota",dataAnggota:t})]})}function ia(){const a=$(),t=T(),n=B(),[l,e]=b.useState(!1),[r,s]=b.useState(!1),u=b.useMemo(()=>R(a),[a]),d=b.useMemo(()=>L(t),[t]),g=f.pelatih;return i.jsxs(I,{"data-testid":"kartu-panduan",className:"lg:col-span-2",children:[i.jsxs("div",{className:"mb-1 flex flex-wrap items-center justify-between gap-2",children:[i.jsx("h2",{className:"text-sm font-semibold text-slate-200",children:"Panduan 1 halaman"}),i.jsx("span",{className:"text-[11px] text-slate-500",children:"satu lembar A4, siap ditempel di tas"})]}),i.jsxs("p",{className:"mb-3 text-[11px] leading-relaxed text-slate-500",children:["Lembar panduan ini ",i.jsx("b",{className:"text-slate-300",children:"dibuat otomatis dari data tim Anda"}),": nama & logo tim, jumlah anggota, sesi, drill, daftar section, dan pengingat backup ikut tercetak. Isinya: urutan pakai yang paling sering, isi tiap menu, shortcut editor formasi, dan cara mengatasi empat macet yang paling sering terjadi. Cocok diberikan ke pelatih kedua; untuk anggota ada versinya sendiri di bawah."]}),i.jsxs("div",{className:"flex flex-wrap gap-2",children:[i.jsxs(m,{"data-testid":"tombol-pratinjau-panduan",onClick:()=>e(!0),children:[i.jsx(x,{size:16})," Pratinjau"]}),i.jsxs(m,{onClick:()=>{v(u,g),n.push("Panduan diunduh sebagai HTML — buka lalu Ctrl+P")},children:[i.jsx(P,{size:16})," Unduh HTML"]}),i.jsxs(m,{variant:"primary",onClick:()=>{M(u,g)?n.push("Panduan dibuka di jendela cetak"):n.push("Jendela cetak diblokir — berkas HTML diunduh. Buka lalu Ctrl+P.","info")},children:[i.jsx(A,{size:16})," Cetak"]})]}),i.jsx(c,{open:l,onClose:()=>e(!1),data:a}),i.jsxs("div",{className:"mt-4 border-t border-slate-800 pt-3","data-testid":"bagian-panduan-anggota",children:[i.jsx("h3",{className:"mb-1 text-xs font-semibold text-slate-200",children:"Versi anggota"}),i.jsxs("p",{className:"mb-3 text-[11px] leading-relaxed text-slate-500",children:["Lembar terpisah untuk ",i.jsx("b",{className:"text-slate-300",children:"HP anggota"}),": cara membuka DrillKit",t.alamat?" (dengan kode QR alamat situs ini)":"",", memasukkan berkas dari pelatih, isi keenam tab, menala sesuai instrumen (Bb/Eb/F), dan kalau macet. Tidak memuat menu pelatih sama sekali.",t.alamat&&w(t.alamat)&&i.jsxs(i.Fragment,{children:[" ",i.jsxs("b",{className:"text-amber-300","data-testid":"peringatan-alamat-lokal",children:["Alamat ",t.alamat," hanya bisa dibuka dari perangkat/jaringan ini"]})," ","— kode QR-nya tidak akan terbuka di HP anggota. Cetak dari situs yang sudah diunggah."]}),!t.alamat&&i.jsxs(i.Fragment,{children:[" ",i.jsx("b",{className:"text-amber-300",children:"Dibuka dari berkas:"})," lembarnya memakai petunjuk versi berkas (tanpa alamat & QR). Cetak dari situs yang sudah diunggah untuk mendapatkan kode QR-nya."]})]}),i.jsxs("div",{className:"flex flex-wrap gap-2",children:[i.jsxs(m,{"data-testid":"tombol-pratinjau-panduan-anggota",onClick:()=>s(!0),children:[i.jsx(x,{size:16})," Pratinjau"]}),i.jsxs(m,{"data-testid":"tombol-unduh-panduan-anggota",onClick:()=>{v(d,f.anggota),n.push("Panduan anggota diunduh sebagai HTML — bisa dikirim lewat WhatsApp")},children:[i.jsx(P,{size:16})," Unduh HTML"]}),i.jsxs(m,{variant:"primary",onClick:()=>{M(d,f.anggota)?n.push("Panduan anggota dibuka di jendela cetak"):n.push("Jendela cetak diblokir — berkas HTML diunduh. Buka lalu Ctrl+P.","info")},children:[i.jsx(A,{size:16})," Cetak"]})]})]}),i.jsx(c,{open:r,onClose:()=>s(!1),jenis:"anggota",dataAnggota:t})]})}const ba=Object.freeze(Object.defineProperty({__proto__:null,DialogPanduanDasbor:H,PratinjauPanduan:c,TombolPanduan:aa,TombolPanduanAnggota:ta,alamatLokal:w,default:ia,pakaiDataPanduan:$,pakaiDataPanduanAnggota:T},Symbol.toStringTag,{value:"Module"}));export{ia as K,ba as P,ta as T,ma as a,oa as b,D as c,da as n};
