import{u as Ne,e as ea,r as l,y as M,j as a,E as we,S as X,B as S,i as fa,V as va,C as ta,a2 as sa,I as Ya,w as Ce,F as I,l as B,ay as Za,ad as $e,M as Te,x as J,aq as ae}from"./index-BsJ-AR0G.js";import{h as ya,u as Sa,L as na,f as pa,a as ma,p as ua,b as Me,W as ee,d as Ie,c as ca}from"./penilaianJuri-ONkuRXUF.js";import{p as Be,d as te}from"./print-dO7JsCGC.js";function k(d){return String(d).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function N(d){return d.toFixed(2).replace(".",",")}function Re(d){const{penilaian:o}=d,b=ya(o),p=Sa(o.catatanWaktu),w=b.predikatBox==="Box 5"?{bg:"#dcfce7",border:"#16a34a",text:"#14532d"}:b.predikatBox==="Box 4"?{bg:"#e0f2fe",border:"#0284c7",text:"#0c4a6e"}:b.predikatBox==="Box 3"?{bg:"#fef3c7",border:"#d97706",text:"#78350f"}:{bg:"#fee2e2",border:"#dc2626",text:"#7f1d1d"},j=b.perKelompok.map(i=>`<div class="kotak">
        <div class="lbl">${k(i.label)}</div>
        <div class="val">${N(i.terbobot)} <span class="ket">/ ${N(i.maksTerbobot)}</span></div>
        <div class="ket">${N(i.persen)}% capaian</div>
      </div>`).join(""),E=b.baris.map(i=>`<tr>
        <td>
          <strong>${k(i.label)}</strong>
          ${i.namaJuri?`<div class="sub">Juri: ${k(i.namaJuri)}</div>`:""}
          ${i.catatan?`<div class="sub">${k(i.catatan)}</div>`:""}
        </td>
        <td style="text-align:center;">${k(na[i.kelompok])}</td>
        <td class="angka">${N(i.komposisi)} / ${N(i.maksKomposisi)}</td>
        <td class="angka">${N(i.eksekusi)} / ${N(i.maksEksekusi)}</td>
        <td class="angka">${i.pengaliBobot===1?"1,0×":`${String(i.pengaliBobot).replace(".",",")}×`}</td>
        <td class="angka"><strong>${N(i.terbobot)}</strong> <span class="sub">/ ${N(i.maksTerbobot)}</span></td>
      </tr>`).join(""),f=o.penalti.length===0?"":`<div class="kotak-penalti">
          <strong>Pengurangan Penalti (−${N(b.totalPenalti)} poin):</strong>
          <ul>
            ${o.penalti.map(i=>`<li>${k(i.alasan)} — <strong>−${N(i.poin)}</strong></li>`).join("")}
          </ul>
        </div>`,D=p.length===0?'<p class="kosong">Tidak ada catatan berpenanda waktu pada evaluasi ini.</p>':`<table>
          <thead>
            <tr>
              <th style="width:68px;">Waktu</th>
              <th style="width:135px;">Set &amp; Birama</th>
              <th style="width:92px;">Fokus</th>
              <th>Komentar Juri / Evaluasi Staf</th>
            </tr>
          </thead>
          <tbody>
            ${p.map(i=>{const K=[i.labelSet?`${i.labelSet}${i.hitunganSet?` (Cnt ${i.hitunganSet})`:""}`:"",i.birama?`Birama ${i.birama}`:""].filter(Boolean).join(" · "),C=i.fokus==="umum"?"Umum":na[i.fokus];return`<tr>
                  <td class="angka"><strong>${pa(i.detik)}</strong></td>
                  <td>${K?k(K):'<span class="sub">—</span>'}</td>
                  <td style="text-align:center;">${k(C)}</td>
                  <td>${i.tingkat==="penting"?"<strong>[PRIORITAS]</strong> ":i.tingkat==="pujian"?"<strong>[APRESIASI]</strong> ":""}${k(i.teks)}</td>
                </tr>`}).join("")}
          </tbody>
        </table>`;return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Caption Recap Sheet — ${k(o.judul)}</title>
<style>
  @page { size: A4 portrait; margin: 11mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #0f172a;
    background: #ffffff;
    font-size: 11px;
    line-height: 1.42;
  }
  .kop {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-bottom: 2px solid #0f172a;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }
  .kop h1 { margin: 0; font-size: 16px; color: #0f172a; }
  .kop .meta { font-size: 10.5px; color: #475569; margin-top: 2px; }
  .skor-utama {
    text-align: right;
  }
  .skor-utama .nilai {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.1;
  }
  .lencana-box {
    display: inline-block;
    margin-top: 3px;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 700;
    background: ${w.bg};
    border: 1px solid ${w.border};
    color: ${w.text};
  }
  .grid-klp {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    margin-bottom: 10px;
  }
  .kotak {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 6px 8px;
    background: #f8fafc;
  }
  .kotak .lbl { font-size: 9.5px; color: #475569; text-transform: uppercase; letter-spacing: 0.04em; }
  .kotak .val { font-size: 13.5px; font-weight: 700; color: #0f172a; margin-top: 2px; }
  .kotak .ket { font-size: 9.5px; color: #64748b; font-weight: 400; }
  h2 {
    margin: 11px 0 6px;
    font-size: 11.5px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #1e293b;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10.3px;
  }
  th, td {
    border: 1px solid #cbd5e1;
    padding: 5px 7px;
    vertical-align: top;
  }
  th {
    background: #1e293b;
    color: #ffffff;
    font-weight: 700;
    text-align: left;
  }
  td.angka, th.angka {
    text-align: right;
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
  }
  tfoot td {
    background: #f1f5f9;
    font-weight: 700;
  }
  .sub { font-size: 9.2px; color: #475569; margin-top: 1px; }
  .kotak-penalti {
    margin-top: 8px;
    padding: 7px 10px;
    border-radius: 6px;
    border: 1px solid #dc2626;
    background: #fef2f2;
    color: #7f1d1d;
    font-size: 10.5px;
  }
  .kotak-penalti ul { margin: 4px 0 0 18px; padding: 0; }
  .catatan-umum {
    margin-top: 10px;
    padding: 7px 10px;
    border-radius: 6px;
    border: 1px solid #94a3b8;
    background: #f8fafc;
    color: #1e293b;
  }
  .kosong { color: #64748b; font-style: italic; margin: 4px 0; }
  .kaki-rahasia {
    margin-top: 12px;
    border-top: 1px solid #cbd5e1;
    padding-top: 5px;
    font-size: 9px;
    color: #64748b;
  }
</style>
</head>
<body>
  <div class="kop">
    <div>
      <h1>CAPTION RECAP SHEET &amp; EVALUASI JURI</h1>
      <div class="meta">
        <strong>${k(d.namaTim)}</strong> · ${k(o.judul)} · Tanggal: <strong>${k(o.tanggal)}</strong>
      </div>
      <div class="meta">
        Skema: ${k(ma[o.skema])}
        ${o.juriUtama?` · Koordinator/Juri: <strong>${k(o.juriUtama)}</strong>`:""}
        ${d.namaDrill?` · Drill: ${k(d.namaDrill)}`:""}
        ${d.namaLagu?` · Lagu: ${k(d.namaLagu)}`:""}
      </div>
    </div>
    <div class="skor-utama">
      <div class="nilai">${N(b.skorAkhir)}</div>
      <div class="lencana-box">${k(b.predikatBox)} (${N(b.persenAkhir)}%)</div>
    </div>
  </div>

  <div class="grid-klp">
    ${j}
  </div>

  <h2>Rincian Nilai Sub-Caption</h2>
  <table>
    <thead>
      <tr>
        <th>Sub-Caption &amp; Juri</th>
        <th style="text-align:center;">Kelompok</th>
        <th class="angka">Komposisi / Rep</th>
        <th class="angka">Eksekusi / Achv</th>
        <th class="angka">Bobot</th>
        <th class="angka">Nilai Terbobot</th>
      </tr>
    </thead>
    <tbody>
      ${E}
    </tbody>
    <tfoot>
      <tr>
        <td colspan="5">Subtotal Sebelum Penalti</td>
        <td class="angka">${N(b.subtotal)} / ${N(b.maksSubtotal)}</td>
      </tr>
      <tr>
        <td colspan="5">Pengurangan Penalti</td>
        <td class="angka">−${N(b.totalPenalti)}</td>
      </tr>
      <tr>
        <td colspan="5">SKOR AKHIR BERSIH (${k(b.predikatBox)})</td>
        <td class="angka">${N(b.skorAkhir)}</td>
      </tr>
    </tfoot>
  </table>

  ${f}

  ${o.catatanUmum?`<div class="catatan-umum"><strong>Catatan Umum Evaluasi:</strong> ${k(o.catatanUmum)}</div>`:""}

  <h2>Transkrip Komentar Judge Tape Tertaut Set &amp; Birama (${p.length} catatan)</h2>
  ${D}

  <div class="kaki-rahasia">
    Dokumen internal staf pelatih &amp; juri — tidak disertakan ke dalam paket anggota DrillKit.
  </div>
</body>
</html>`}const se=["field_show","street_parade","indoor_winds","indoor_perc","indoor_guard","kustom"];function v(d){return d.toFixed(2).replace(".",",")}async function ne(d){let o=2166136261;const b=Math.max(1,Math.floor(d.length/4096));for(let p=0;p<d.length;p+=b)o^=d[p],o=Math.imul(o,16777619);return(o>>>0).toString(16).padStart(8,"0")}function Ue({tanggalAktif:d,sesiAktif:o,namaTim:b}){var Fa,Oa,Ga,Va,qa,Qa,Xa;const p=Ne(),w=ea(()=>M.penilaianLomba.toArray(),[],[]),j=ea(()=>M.drills.toArray(),[],[]),E=ea(()=>M.sets.toArray(),[],[]),f=ea(()=>M.songs.toArray(),[],[]),D=l.useMemo(()=>[...w!=null?w:[]].sort((e,t)=>t.tanggal!==e.tanggal?t.tanggal.localeCompare(e.tanggal):(t.updatedAt||0)-(e.updatedAt||0)),[w]),[i,K]=l.useState(""),C=l.useMemo(()=>{var e;return D.length?(e=D.find(t=>t.id===i))!=null?e:D[0]:null},[D,i]);l.useEffect(()=>{C&&C.id!==i&&K(C.id)},[C,i]);const[n,_]=l.useState(null),u=l.useRef(null),H=l.useRef(0);l.useEffect(()=>{var e;H.current>0&&((e=u.current)==null?void 0:e.id)===(C==null?void 0:C.id)||(u.current=C,_(C))},[C]);const U=ea(()=>n!=null&&n.id?M.judgeTapeAudio.get(n.id):void 0,[n==null?void 0:n.id],void 0),[c,z]=l.useState(null),P=l.useRef(null);l.useEffect(()=>{if(!(U!=null&&U.blob)){z(null);return}const e=URL.createObjectURL(U.blob);return z(e),()=>URL.revokeObjectURL(e)},[U]);const[F,W]=l.useState(0),[ia,ra]=l.useState(!1),[ie,Na]=l.useState(!1),la=l.useRef(null),xa=l.useRef([]),wa=l.useRef(0);l.useEffect(()=>{if(!ia)return;const e=performance.now()-F*1e3,t=window.setInterval(()=>{const s=Math.round((performance.now()-e)/1e3*10)/10;W(s)},200);return()=>window.clearInterval(t)},[ia]);const[ha,re]=l.useState("field_show"),[Ca,$a]=l.useState(""),[Ta,le]=l.useState("0.5"),[ga,Ma]=l.useState(""),[Ia,oe]=l.useState("ge"),[Ba,de]=l.useState("biasa"),[Ra,Pa]=l.useState(""),[aa,La]=l.useState("semua"),[Ea,Ka]=l.useState(""),[Ua,ue]=l.useState("ge"),[Aa,ce]=l.useState("10"),[pe,ba]=l.useState(!1);async function y(e){var s,r;const t={...e,updatedAt:Math.max(Date.now(),((r=(s=u.current)==null?void 0:s.updatedAt)!=null?r:0)+1)};u.current=t,_(t),H.current+=1;try{await M.penilaianLomba.put(t)}finally{H.current=Math.max(0,H.current-1)}}const T=l.useMemo(()=>{var e;return(e=(j!=null?j:[]).find(t=>t.id===(n==null?void 0:n.drillId)))!=null?e:null},[j,n==null?void 0:n.drillId]),Y=l.useMemo(()=>n!=null&&n.drillId?(E!=null?E:[]).filter(e=>e.drillId===n.drillId).sort((e,t)=>e.order-t.order):[],[E,n==null?void 0:n.drillId]),O=l.useMemo(()=>{var e;return(e=(f!=null?f:[]).find(t=>t.id===((n==null?void 0:n.songId)||(T==null?void 0:T.songId))))!=null?e:null},[f,n==null?void 0:n.songId,T==null?void 0:T.songId]),ka=ga.trim()!==""?Math.max(0,Number(ga)||0):F,G=l.useMemo(()=>ua(ka,{sets:Y,drill:T,song:O}),[ka,Y,T,O]),h=l.useMemo(()=>n?ya(n):null,[n]),V=l.useMemo(()=>Me(w!=null?w:[]),[w]);async function Ja(e=ha){var m,A;const t=Date.now(),s=(j!=null?j:[])[0],r=((m=w==null?void 0:w.length)!=null?m:0)+1,g={id:J("juri_"),judul:o!=null&&o.title?`Simulasi #${r} — ${o.title}`:`Simulasi Run-Through #${r}`,tanggal:d,skema:e,sessionId:o==null?void 0:o.id,drillId:s==null?void 0:s.id,songId:(s==null?void 0:s.songId)||((A=(f!=null?f:[])[0])==null?void 0:A.id),captions:ca(e),penalti:[],catatanWaktu:[],createdAt:t,updatedAt:t};u.current=g,_(g),K(g.id),await M.penilaianLomba.put(g),p.push("Lembar simulasi penilaian juri siap diisi")}async function me(){var Z;const e=Date.now(),t=(j!=null?j:[])[0],s=(Z=(f!=null?f:[]).find(x=>x.id===(t==null?void 0:t.songId)))!=null?Z:(f!=null?f:[])[0],r=t?(E!=null?E:[]).filter(x=>x.drillId===t.id).sort((x,Q)=>x.order-Q.order):[],g=(()=>{const x=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d),Q=x?new Date(Number(x[1]),Number(x[2])-1,Number(x[3])):new Date;return Q.setDate(Q.getDate()-14),`${Q.getFullYear()}-${String(Q.getMonth()+1).padStart(2,"0")}-${String(Q.getDate()).padStart(2,"0")}`})(),m=ca("field_show").map(x=>({...x,nilaiKomposisi:Math.round(x.maksKomposisi*.72*10)/10,nilaiEksekusi:Math.round(x.maksEksekusi*.68*10)/10})),A=ca("field_show").map(x=>({...x,nilaiKomposisi:Math.round(x.maksKomposisi*.85*10)/10,nilaiEksekusi:Math.round(x.maksEksekusi*.83*10)/10})),$=ua(12,{sets:r,drill:t,song:s}),R=ua(28,{sets:r,drill:t,song:s}),q={id:J("juri_"),judul:"Simulasi Evaluasi #1 (H-14)",tanggal:g,skema:"field_show",drillId:t==null?void 0:t.id,songId:s==null?void 0:s.id,juriUtama:"Tim Pelatih Tamu",captions:m,penalti:[{id:J("pen_"),alasan:"Overtime penutup 4 detik",poin:.5}],catatanWaktu:[{id:J("jt_"),detik:12,fokus:"visual",teks:"Jarak antar saf sayap kanan melebar 1 langkah saat transisi pembuka.",setId:$.setId,labelSet:$.labelSet,hitunganSet:$.hitunganSet,birama:$.birama,tingkat:"penting"}],catatanUmum:"Kerangka repertoar kuat; fokuskan kebersihan artikulasi tiup dan transisi awal.",createdAt:e-2e3,updatedAt:e-2e3},L={id:J("juri_"),judul:"Simulasi Gladi Bersih #2 (H-1)",tanggal:d,skema:"field_show",sessionId:o==null?void 0:o.id,drillId:t==null?void 0:t.id,songId:s==null?void 0:s.id,juriUtama:"Panel Juri Simulasi Kejuaraan",captions:A,penalti:[],catatanWaktu:[{id:J("jt_"),detik:12,fokus:"visual",teks:"Saf pembuka jauh lebih rapi dan terkunci tepat di hitungan akhir!",setId:$.setId,labelSet:$.labelSet,hitunganSet:$.hitunganSet,birama:$.birama,tingkat:"pujian"},{id:J("jt_"),detik:28,fokus:"musik",teks:"Jaga keseimbangan dinamika low brass saat masuk klimaks reff.",setId:R.setId,labelSet:R.labelSet,hitunganSet:R.hitunganSet,birama:R.birama,tingkat:"penting"}],catatanUmum:"Peningkatan signifikan menuju Box 4; pertahankan stamina hingga koda penutup.",createdAt:e-1e3,updatedAt:e-1e3};await M.penilaianLomba.bulkPut([q,L]),u.current=L,_(L),K(L.id),p.push("2 simulasi contoh (H-14 & H-1) berhasil dimuat")}function oa(e,t){const s=u.current;if(!s)return;const r=s.captions.map(g=>g.id===e?{...g,...t}:g);y({...s,captions:r})}function xe(e){const t=u.current;t&&(y({...t,skema:e,captions:ca(e)}),p.push(`Template diganti ke ${ma[e]}`))}function he(){const e=u.current;if(!e)return;const t=Ea.trim();if(!t){p.push("Isi nama sub-caption terlebih dahulu","err");return}const s=Math.max(1,Number(Aa)||10),r={id:J("sub_"),kelompok:Ua,label:t,maksKomposisi:s,nilaiKomposisi:Math.round(s*.75*10)/10,maksEksekusi:s,nilaiEksekusi:Math.round(s*.75*10)/10,pengaliBobot:1};y({...e,captions:[...e.captions,r]}),Ka("")}function ge(e){const t=u.current;!t||t.captions.length<=1||y({...t,captions:t.captions.filter(s=>s.id!==e)})}function da(e,t){const s=u.current;if(!s)return;const r=(e!=null?e:Ca).trim(),g=t!=null?t:Math.max(.05,Number(Ta)||0);if(!r){p.push("Tulis alasan pengurangan penalti","err");return}const m={id:J("pen_"),alasan:r,poin:Math.round(g*100)/100};y({...s,penalti:[...s.penalti,m]}),e||$a("")}function be(e){const t=u.current;t&&y({...t,penalti:t.penalti.filter(s=>s.id!==e)})}function za(){const e=u.current;if(!e)return;const t=Ra.trim();if(!t){p.push("Tulis isi komentar juri terlebih dahulu","err");return}const s=ua(ka,{sets:Y,drill:T,song:O}),r={id:J("jt_"),detik:s.detik,fokus:Ia,teks:t,setId:s.setId,labelSet:s.labelSet,hitunganSet:s.hitunganSet,birama:s.birama,tingkat:Ba};y({...e,catatanWaktu:Sa([...e.catatanWaktu,r])}),Pa(""),Ma("")}function ke(e){const t=u.current;t&&y({...t,catatanWaktu:t.catatanWaktu.filter(s=>s.id!==e)})}function Da(e){W(e);const t=P.current;if(t)try{t.currentTime=Math.max(0,e),t.play().catch(()=>{})}catch{}}async function je(e){const t=u.current;if(!t)return;const s=await e.arrayBuffer(),r=new Uint8Array(s),g=await ne(r),m=e.type||(e.name.endsWith(".webm")?"audio/webm":"audio/mpeg"),A=new Blob([r],{type:m}),$=await new Promise(R=>{const q=URL.createObjectURL(A),L=new Audio,Z=x=>{URL.revokeObjectURL(q),R(Number.isFinite(x)&&x>0?Math.round(x*10)/10:0)};L.onloadedmetadata=()=>Z(L.duration),L.onerror=()=>Z(0),setTimeout(()=>Z(0),1200),L.src=q});await M.judgeTapeAudio.put({id:t.id,penilaianId:t.id,blob:A,namaFile:e.name,tipe:m,ukuran:r.byteLength,durasiDetik:$,hash:g,updatedAt:Date.now()}),await y({...t,rekamanJudgeTape:{namaFile:e.name,tipe:m,ukuran:r.byteLength,durasiDetik:$,hash:g}}),p.push(`Rekaman Judge Tape "${e.name}" tersimpan`)}async function fe(){var e;if(!((e=navigator.mediaDevices)!=null&&e.getUserMedia)||typeof MediaRecorder=="undefined"){p.push("Peramban ini tidak mendukung perekaman mikrofon langsung — gunakan Unggah Audio","err");return}try{const t=await navigator.mediaDevices.getUserMedia({audio:!0}),s=new MediaRecorder(t);xa.current=[],wa.current=Date.now(),s.ondataavailable=r=>{r.data.size>0&&xa.current.push(r.data)},s.onstop=async()=>{t.getTracks().forEach(L=>L.stop());const r=s.mimeType||"audio/webm",g=new Blob(xa.current,{type:r}),m=new Uint8Array(await g.arrayBuffer()),A=await ne(m),$=Math.max(1,Math.round((Date.now()-wa.current)/100)/10),R=u.current;if(!R)return;const q=`judgetape-${R.tanggal}.webm`;await M.judgeTapeAudio.put({id:R.id,penilaianId:R.id,blob:g,namaFile:q,tipe:r,ukuran:m.byteLength,durasiDetik:$,hash:A,updatedAt:Date.now()}),await y({...R,rekamanJudgeTape:{namaFile:q,tipe:r,ukuran:m.byteLength,durasiDetik:$,hash:A}}),p.push("Rekaman suara Judge Tape berhasil disimpan")},la.current=s,s.start(),W(0),ra(!0),Na(!0)}catch{p.push("Izin mikrofon ditolak atau perangkat tidak tersedia","err")}}function ve(){la.current&&la.current.state!=="inactive"&&la.current.stop(),Na(!1),ra(!1)}async function ye(){const e=u.current;e&&(await M.judgeTapeAudio.delete(e.id),await y({...e,rekamanJudgeTape:void 0}),p.push("Rekaman audio Judge Tape dihapus","info"))}function ja(){return n?Re({namaTim:b,penilaian:n,namaDrill:T==null?void 0:T.name,namaLagu:O==null?void 0:O.title,namaSesi:o==null?void 0:o.title}):""}function Ha(){const e=ja();e&&(Be(e)||(te(e,`caption-recap-${ae((n==null?void 0:n.judul)||"simulasi")}.html`),p.push("Pop-up diblokir — berkas HTML A4 diunduh")))}function Wa(){const e=ja();e&&(te(e,`caption-recap-${ae((n==null?void 0:n.judul)||"simulasi")}.html`),p.push("Lembar Caption Recap A4 diunduh"))}const _a=l.useMemo(()=>{var t;const e=Sa((t=n==null?void 0:n.catatanWaktu)!=null?t:[]);return aa==="semua"?e:e.filter(s=>s.setId===aa)},[n==null?void 0:n.catatanWaktu,aa]);if(!n||!h)return a.jsx("div",{"data-testid":"panel-penilaian-juri-kosong",children:a.jsx(we,{icon:a.jsx(va,{size:30}),title:"Belum ada simulasi penilaian juri",desc:"Gunakan lembar Caption Recap standar kejuaraan (Field Show GPMB/IDCA/DCI, Street Parade, Indoor Winds/Percussion/Guard) beserta Judge Tape tertaut Set & Birama.",action:a.jsxs("div",{className:"flex flex-col items-center gap-2.5",children:[a.jsxs("div",{className:"flex flex-wrap items-center justify-center gap-2",children:[a.jsx(X,{"aria-label":"Pilih skema mata lomba","data-testid":"pilih-skema-awal-juri",value:ha,onChange:e=>re(e.target.value),children:se.map(e=>a.jsx("option",{value:e,children:ma[e]},e))}),a.jsxs(S,{variant:"primary","data-testid":"buat-simulasi-juri",onClick:()=>void Ja(ha),children:[a.jsx(fa,{size:15})," Buat Simulasi Penilaian"]})]}),a.jsx(S,{variant:"soft","data-testid":"muat-contoh-simulasi",onClick:()=>void me(),children:"Muat 2 Simulasi Contoh (Tren H-14 → H-1)"})]})})});const Se=h.predikatBox==="Box 5"?"border-emerald-500/50 bg-emerald-500/15 text-emerald-300":h.predikatBox==="Box 4"?"border-sky-500/50 bg-sky-500/15 text-sky-300":h.predikatBox==="Box 3"?"border-amber-500/50 bg-amber-500/15 text-amber-300":"border-rose-500/50 bg-rose-500/15 text-rose-300";return a.jsxs("div",{className:"space-y-4","data-testid":"panel-penilaian-juri",children:[a.jsx(ta,{className:"p-3.5",children:a.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2",children:[a.jsx("div",{className:"flex flex-wrap items-center gap-1.5","data-testid":"daftar-simulasi-juri",children:D.map(e=>{const t=ya(e),s=e.id===n.id;return a.jsxs("button",{type:"button","data-testid":`pilih-simulasi-${e.id}`,onClick:()=>K(e.id),className:sa("rounded-lg border px-2.5 py-1.5 text-left text-xs transition",s?"border-emerald-500/60 bg-emerald-500/15 text-emerald-200":"border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700"),children:[a.jsx("div",{className:"font-semibold",children:e.judul}),a.jsxs("div",{className:"text-[11px] text-slate-400",children:[e.tanggal," · ",a.jsx("strong",{children:v(t.skorAkhir)})," (",t.predikatBox,")"]})]},e.id)})}),a.jsxs("div",{className:"flex flex-wrap items-center gap-1.5",children:[a.jsxs(S,{size:"sm",variant:"soft","data-testid":"buat-simulasi-juri",onClick:()=>void Ja(n.skema),children:[a.jsx(fa,{size:14})," Simulasi Baru"]}),a.jsx(S,{size:"sm",variant:"ghost","data-testid":"pratinjau-cetak-juri",onClick:()=>ba(!0),children:"Pratinjau A4"}),a.jsxs(S,{size:"sm",variant:"ghost","data-testid":"cetak-rekap-juri",onClick:Ha,children:[a.jsx(va,{size:14})," Cetak Rekap"]}),a.jsxs(S,{size:"sm",variant:"ghost","data-testid":"unduh-rekap-juri",onClick:Wa,children:[a.jsx(Ya,{size:14})," Unduh HTML"]}),a.jsx(Ce,{label:"Hapus",message:`Hapus simulasi "${n.judul}" beserta rekaman Judge Tape-nya?`,onConfirm:async()=>{await M.judgeTapeAudio.delete(n.id),await M.penilaianLomba.delete(n.id),K(""),p.push("Simulasi penilaian dihapus","info")}})]})]})}),a.jsxs(ta,{"data-testid":"papan-skor-juri",children:[a.jsxs("div",{className:"flex flex-col justify-between gap-4 border-b border-slate-800 pb-4 md:flex-row md:items-center",children:[a.jsxs("div",{children:[a.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[a.jsx("span",{"data-testid":"skor-akhir-juri",className:"text-3xl font-extrabold tabular-nums text-slate-50",children:v(h.skorAkhir)}),a.jsxs("span",{className:"text-sm text-slate-400",children:["/ ",v(h.maksSubtotal)]}),a.jsxs("span",{"data-testid":"lencana-box-juri",className:sa("rounded-full border px-2.5 py-0.5 text-xs font-bold",Se),children:[h.predikatBox," (",v(h.persenAkhir),"%)"]})]}),a.jsxs("p",{className:"mt-1 text-xs text-slate-400",children:[h.ketPredikatBox,h.totalPenalti>0&&a.jsxs("span",{className:"ml-2 font-semibold text-rose-400",children:["· Penalti −",v(h.totalPenalti)," poin (Subtotal ",v(h.subtotal),")"]})]})]}),h.terkuat&&h.terlemah&&a.jsxs("div",{className:"grid grid-cols-2 gap-2 text-xs",children:[a.jsxs("div",{className:"rounded-lg border border-emerald-800/50 bg-emerald-950/30 px-2.5 py-1.5",children:[a.jsx("div",{className:"text-[10px] uppercase tracking-wider text-emerald-400",children:"Caption Terkuat"}),a.jsx("div",{className:"font-semibold text-emerald-200",children:h.terkuat.label}),a.jsxs("div",{className:"text-[11px] text-emerald-300/80",children:[v(h.terkuat.persen),"%"]})]}),a.jsxs("div",{className:"rounded-lg border border-amber-800/50 bg-amber-950/30 px-2.5 py-1.5",children:[a.jsx("div",{className:"text-[10px] uppercase tracking-wider text-amber-400",children:"Fokus Pembenahan"}),a.jsx("div",{className:"font-semibold text-amber-200",children:h.terlemah.label}),a.jsxs("div",{className:"text-[11px] text-amber-300/80",children:[v(h.terlemah.persen),"%"]})]})]})]}),a.jsx("div",{className:"mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-4",children:h.perKelompok.map(e=>a.jsxs("div",{"data-testid":`kartu-kelompok-${e.kelompok}`,className:"rounded-xl border border-slate-800 bg-slate-900/60 p-2.5",children:[a.jsxs("div",{className:"flex items-center gap-1.5 text-[11px] font-semibold text-slate-300",children:[a.jsx("span",{className:"inline-block h-2.5 w-2.5 rounded-full",style:{backgroundColor:ee[e.kelompok]}}),e.label]}),a.jsxs("div",{className:"mt-1 text-lg font-bold tabular-nums text-slate-100",children:[v(e.terbobot)," ",a.jsxs("span",{className:"text-xs font-normal text-slate-500",children:["/ ",v(e.maksTerbobot)]})]}),a.jsxs("div",{className:"text-[11px] text-slate-400",children:[v(e.persen),"% capaian"]})]},e.kelompok))}),a.jsxs("div",{className:"mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",children:[a.jsx(I,{label:"Judul Simulasi / Evaluasi",children:a.jsx(B,{"data-testid":"input-judul-juri",value:n.judul,onChange:e=>void y({...u.current,judul:e.target.value})})}),a.jsx(I,{label:"Tanggal Simulasi",children:a.jsx(B,{type:"date","data-testid":"input-tanggal-juri",value:n.tanggal,onChange:e=>void y({...u.current,tanggal:e.target.value})})}),a.jsx(I,{label:"Skema Mata Lomba",children:a.jsx(X,{"data-testid":"select-skema-juri",value:n.skema,onChange:e=>xe(e.target.value),children:se.map(e=>a.jsx("option",{value:e,children:ma[e]},e))})}),a.jsx(I,{label:"Drill Tertaut (Peta Set)",children:a.jsxs(X,{"data-testid":"select-drill-juri",value:(Fa=n.drillId)!=null?Fa:"",onChange:e=>{const t=e.target.value||void 0,s=(j!=null?j:[]).find(r=>r.id===t);y({...u.current,drillId:t,songId:(s==null?void 0:s.songId)||u.current.songId})},children:[a.jsx("option",{value:"",children:"— Tanpa tautan drill —"}),(j!=null?j:[]).map(e=>a.jsx("option",{value:e.id,children:e.name},e.id))]})}),a.jsx(I,{label:"Lagu Tertaut (Peta Birama)",children:a.jsxs(X,{"data-testid":"select-lagu-juri",value:(Oa=n.songId)!=null?Oa:"",onChange:e=>void y({...u.current,songId:e.target.value||void 0}),children:[a.jsx("option",{value:"",children:"— Tanpa tautan lagu —"}),(f!=null?f:[]).map(e=>a.jsxs("option",{value:e.id,children:[e.title," (",e.bpm," BPM)"]},e.id))]})})]})]}),a.jsxs(ta,{children:[a.jsxs("div",{className:"mb-3 flex flex-wrap items-center justify-between gap-2",children:[a.jsxs("div",{children:[a.jsx("h2",{className:"text-sm font-semibold text-slate-100",children:"Lembar Rekapitulasi Sub-Caption (Komposisi vs Eksekusi)"}),a.jsx("p",{className:"text-xs text-slate-400",children:"Isi skor Repertoar/Komposisi dan Pencapaian/Eksekusi per juri; nilai terbobot dan klasifikasi Box terhitung seketika."})]}),a.jsx(I,{label:"Koordinator / Juri Utama",children:a.jsx(B,{placeholder:"Mis. Bpk. Hendra (Juri Tamu)","data-testid":"input-juri-utama",value:(Ga=n.juriUtama)!=null?Ga:"",onChange:e=>void y({...u.current,juriUtama:e.target.value||void 0})})})]}),a.jsx("div",{className:"overflow-x-auto",children:a.jsxs("table",{className:"w-full text-left text-xs","data-testid":"tabel-subcaption-juri",children:[a.jsx("thead",{children:a.jsxs("tr",{className:"border-b border-slate-800 text-[11px] uppercase tracking-wider text-slate-400",children:[a.jsx("th",{className:"py-2 pr-2",children:"Sub-Caption & Juri"}),a.jsx("th",{className:"px-2 py-2",children:"Komposisi / Rep"}),a.jsx("th",{className:"px-2 py-2",children:"Eksekusi / Achv"}),a.jsx("th",{className:"px-2 py-2 text-right",children:"Bobot"}),a.jsx("th",{className:"px-2 py-2 text-right",children:"Terbobot"}),a.jsx("th",{className:"py-2 pl-2 text-right",children:"Aksi"})]})}),a.jsx("tbody",{className:"divide-y divide-slate-800/70",children:h.baris.map((e,t)=>{var r,g;const s=n.captions[t];return s?a.jsxs("tr",{"data-testid":`baris-subcaption-${e.id}`,children:[a.jsxs("td",{className:"py-2.5 pr-2 align-top",children:[a.jsxs("div",{className:"flex items-center gap-1.5",children:[a.jsx("span",{className:"inline-block h-2 w-2 shrink-0 rounded-full",style:{backgroundColor:ee[e.kelompok]}}),a.jsx("span",{className:"font-semibold text-slate-100",children:e.label})]}),a.jsxs("div",{className:"mt-1.5 grid gap-1.5 sm:grid-cols-2",children:[a.jsx(B,{placeholder:"Nama juri (opsional)",value:(r=s.namaJuri)!=null?r:"",onChange:m=>oa(e.id,{namaJuri:m.target.value||void 0})}),a.jsx(B,{placeholder:"Catatan ringkas caption",value:(g=s.catatan)!=null?g:"",onChange:m=>oa(e.id,{catatan:m.target.value||void 0})})]})]}),a.jsx("td",{className:"px-2 py-2.5 align-top",children:a.jsxs("div",{className:"flex items-center gap-1",children:[a.jsx(B,{type:"number",step:"0.1",min:0,max:e.maksKomposisi,"data-testid":`input-komposisi-${e.id}`,className:"w-20 text-right tabular-nums",value:s.nilaiKomposisi,onChange:m=>oa(e.id,{nilaiKomposisi:Math.max(0,Math.min(e.maksKomposisi,Number(m.target.value)||0))})}),a.jsxs("span",{className:"text-[11px] text-slate-500",children:["/ ",e.maksKomposisi]})]})}),a.jsx("td",{className:"px-2 py-2.5 align-top",children:a.jsxs("div",{className:"flex items-center gap-1",children:[a.jsx(B,{type:"number",step:"0.1",min:0,max:e.maksEksekusi,"data-testid":`input-eksekusi-${e.id}`,className:"w-20 text-right tabular-nums",value:s.nilaiEksekusi,onChange:m=>oa(e.id,{nilaiEksekusi:Math.max(0,Math.min(e.maksEksekusi,Number(m.target.value)||0))})}),a.jsxs("span",{className:"text-[11px] text-slate-500",children:["/ ",e.maksEksekusi]})]})}),a.jsxs("td",{className:"px-2 py-2.5 align-top text-right tabular-nums text-slate-400",children:[e.pengaliBobot,"×"]}),a.jsxs("td",{className:"px-2 py-2.5 align-top text-right tabular-nums",children:[a.jsx("div",{className:"font-bold text-slate-100",children:v(e.terbobot)}),a.jsxs("div",{className:"text-[10px] text-slate-500",children:["/ ",v(e.maksTerbobot)," (",v(e.persen),"%)"]})]}),a.jsx("td",{className:"py-2.5 pl-2 align-top text-right",children:n.captions.length>1&&a.jsx("button",{type:"button",title:"Hapus sub-caption",onClick:()=>ge(e.id),className:"rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-400",children:a.jsx(Za,{size:14})})})]},e.id):null})})]})}),a.jsxs("div",{className:"mt-3 flex flex-wrap items-end gap-2 border-t border-slate-800 pt-3",children:[a.jsx(I,{label:"Tambah Sub-Caption Tambahan / Kustom",children:a.jsx(B,{placeholder:"Mis. Drum Major / Mayoret","data-testid":"input-subcaption-baru",value:Ea,onChange:e=>Ka(e.target.value)})}),a.jsx(I,{label:"Kelompok",children:a.jsx(X,{value:Ua,onChange:e=>ue(e.target.value),children:Object.keys(na).map(e=>a.jsx("option",{value:e,children:na[e]},e))})}),a.jsx(I,{label:"Maks per Komponen",children:a.jsx(B,{type:"number",min:1,max:50,className:"w-24",value:Aa,onChange:e=>ce(e.target.value)})}),a.jsxs(S,{size:"sm",variant:"soft","data-testid":"tambah-subcaption-juri",onClick:he,children:[a.jsx(fa,{size:14})," Tambah Sub-Caption"]})]}),a.jsxs("div",{className:"mt-4 grid gap-4 border-t border-slate-800 pt-4 md:grid-cols-2","data-testid":"bagian-penalti-juri",children:[a.jsxs("div",{children:[a.jsxs("h3",{className:"text-xs font-semibold uppercase tracking-wider text-slate-300",children:["Penalti Waktu & Garis Batas (−",v(h.totalPenalti)," poin)"]}),a.jsxs("div",{className:"mt-2 flex flex-wrap gap-1.5",children:[a.jsx("button",{type:"button","data-testid":"preset-penalti-waktu",onClick:()=>da("Melewati batas durasi (Overtime)",.5),className:"rounded-md border border-slate-700 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-300 hover:border-rose-500/50 hover:text-rose-200",children:"+ Overtime (−0,50)"}),a.jsx("button",{type:"button",onClick:()=>da("Keluar garis batas arena (Boundary)",.1),className:"rounded-md border border-slate-700 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-300 hover:border-rose-500/50 hover:text-rose-200",children:"+ Garis Batas (−0,10)"}),a.jsx("button",{type:"button",onClick:()=>da("Terlambat masuk gerbang start",1),className:"rounded-md border border-slate-700 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-300 hover:border-rose-500/50 hover:text-rose-200",children:"+ Terlambat Start (−1,00)"})]}),a.jsxs("div",{className:"mt-2 flex items-center gap-2",children:[a.jsx(B,{placeholder:"Alasan penalti lain…","data-testid":"input-alasan-penalti",value:Ca,onChange:e=>$a(e.target.value)}),a.jsx(B,{type:"number",step:"0.1",min:"0.05","data-testid":"input-poin-penalti",className:"w-24 text-right tabular-nums",value:Ta,onChange:e=>le(e.target.value)}),a.jsx(S,{size:"sm",variant:"soft","data-testid":"tambah-penalti-juri",onClick:()=>da(),children:"Tambah"})]}),n.penalti.length>0&&a.jsx("ul",{className:"mt-2 space-y-1",children:n.penalti.map(e=>a.jsxs("li",{className:"flex items-center justify-between rounded-lg border border-rose-900/50 bg-rose-950/25 px-2.5 py-1 text-xs text-rose-200",children:[a.jsxs("span",{children:[e.alasan," · ",a.jsxs("strong",{children:["−",v(e.poin)]})]}),a.jsx("button",{type:"button",onClick:()=>be(e.id),className:"text-rose-400 hover:text-rose-200",children:"Hapus"})]},e.id))})]}),a.jsxs("div",{children:[a.jsx("h3",{className:"text-xs font-semibold uppercase tracking-wider text-slate-300",children:"Catatan Umum Evaluasi Run-Through"}),a.jsx("textarea",{rows:4,"data-testid":"input-catatan-umum-juri",placeholder:"Ringkasan evaluasi keseluruhan penampilan untuk rapat staf pelatih…",value:(Va=n.catatanUmum)!=null?Va:"",onChange:e=>void y({...u.current,catatanUmum:e.target.value||void 0}),className:"mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none"})]})]})]}),a.jsxs(ta,{"data-testid":"panel-judgetape",children:[a.jsxs("div",{className:"flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-3",children:[a.jsxs("div",{children:[a.jsx("h2",{className:"text-sm font-semibold text-slate-100",children:"Judge Tape Berpenanda Waktu (Otomatis Tertaut Nomor Set & Birama)"}),a.jsx("p",{className:"text-xs text-slate-400",children:"Rekam komentar suara juri atau jalankan stopwatch saat run-through; setiap cap waktu otomatis dipetakan ke Set formasi & Birama lagu."})]}),a.jsxs("div",{"data-testid":"indikator-posisi-judgetape",className:"rounded-xl border border-emerald-700/40 bg-emerald-950/30 px-3 py-1.5 text-right text-xs text-emerald-200",children:[a.jsx("div",{className:"font-mono text-sm font-bold",children:pa(G.detik)}),a.jsxs("div",{className:"text-[11px] text-emerald-300/90",children:[G.labelSet?`${G.labelSet}${G.hitunganSet?` (Hit. ${G.hitunganSet})`:""}`:"Belum tertaut set",G.birama?` · Birama ${G.birama}`:""]})]})]}),a.jsxs("div",{className:"mt-3 flex flex-wrap items-center gap-2",children:[a.jsxs(S,{size:"sm",variant:ia?"danger":"soft","data-testid":"tombol-stopwatch-judgetape",onClick:()=>ra(e=>!e),children:[a.jsx($e,{size:14})," ",ia?`Jeda Stopwatch (${pa(F)})`:"Mulai Stopwatch Run-Through"]}),a.jsx(S,{size:"sm",variant:"ghost",onClick:()=>{ra(!1),W(0)},children:"Reset 00:00"}),ie?a.jsx(S,{size:"sm",variant:"danger","data-testid":"henti-rekam-judgetape",onClick:ve,children:"■ Hentikan & Simpan Rekaman"}):a.jsx(S,{size:"sm",variant:"soft","data-testid":"rekam-suara-judgetape",onClick:()=>void fe(),children:"● Rekam Suara Juri (Mic)"}),a.jsxs("label",{className:"cursor-pointer rounded-lg border border-slate-700 bg-slate-800/80 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-600",children:["Unggah Audio Judge Tape",a.jsx("input",{type:"file",accept:"audio/*","data-testid":"unggah-audio-judgetape",className:"hidden",onChange:e=>{var s;const t=(s=e.target.files)==null?void 0:s[0];t&&je(t),e.currentTarget.value=""}})]})]}),(c||n.rekamanJudgeTape)&&a.jsxs("div",{"data-testid":"info-rekaman-judgetape",className:"mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-900/70 p-2.5",children:[a.jsxs("div",{className:"flex flex-1 flex-wrap items-center gap-3",children:[c&&a.jsx("audio",{ref:P,controls:!0,src:c,"data-testid":"pemutar-audio-judgetape",onTimeUpdate:e=>W(Math.round(e.currentTarget.currentTime*10)/10),className:"h-9 max-w-full"}),a.jsxs("span",{className:"text-xs text-slate-300",children:[a.jsx("strong",{children:(Qa=(qa=n.rekamanJudgeTape)==null?void 0:qa.namaFile)!=null?Qa:U==null?void 0:U.namaFile}),(Xa=n.rekamanJudgeTape)!=null&&Xa.ukuran?` · ${Math.max(1,Math.round(n.rekamanJudgeTape.ukuran/1024))} KB`:""]})]}),a.jsx(S,{size:"sm",variant:"ghost",onClick:()=>void ye(),children:"Hapus Audio"})]}),a.jsxs("div",{className:"mt-3 grid gap-2 rounded-xl border border-slate-800 bg-slate-900/40 p-3 sm:grid-cols-12",children:[a.jsx("div",{className:"sm:col-span-2",children:a.jsx(I,{label:"Detik (opsional)",children:a.jsx(B,{type:"number",min:0,step:"0.5",placeholder:String(Math.floor(F)),"data-testid":"input-detik-judgetape",value:ga,onChange:e=>Ma(e.target.value)})})}),a.jsx("div",{className:"sm:col-span-2",children:a.jsx(I,{label:"Fokus Caption",children:a.jsxs(X,{"data-testid":"select-fokus-judgetape",value:Ia,onChange:e=>oe(e.target.value),children:[a.jsx("option",{value:"ge",children:"General Effect"}),a.jsx("option",{value:"musik",children:"Music"}),a.jsx("option",{value:"visual",children:"Visual"}),a.jsx("option",{value:"guard",children:"Color Guard"}),a.jsx("option",{value:"umum",children:"Umum"})]})})}),a.jsx("div",{className:"sm:col-span-2",children:a.jsx(I,{label:"Sifat Catatan",children:a.jsxs(X,{"data-testid":"select-tingkat-judgetape",value:Ba,onChange:e=>de(e.target.value),children:[a.jsx("option",{value:"biasa",children:"Catatan"}),a.jsx("option",{value:"penting",children:"Prioritas Perbaikan"}),a.jsx("option",{value:"pujian",children:"Apresiasi / Kuat"})]})})}),a.jsx("div",{className:"sm:col-span-4",children:a.jsx(I,{label:"Komentar Juri pada Momen Ini",children:a.jsx(B,{placeholder:"Ketik catatan lalu tekan Enter (mis. Intonasi trumpet goyah di transisi)…","data-testid":"input-teks-judgetape",value:Ra,onChange:e=>Pa(e.target.value),onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),za())}})})}),a.jsx("div",{className:"flex items-end sm:col-span-2",children:a.jsx(S,{variant:"primary",className:"w-full","data-testid":"tambah-catatan-judgetape",onClick:za,children:"+ Tandai"})})]}),Y.length>0&&a.jsxs("div",{className:"mt-3 flex flex-wrap items-center gap-1.5","data-testid":"filter-set-judgetape",children:[a.jsx("span",{className:"text-[11px] text-slate-400",children:"Saring / Putar per Set:"}),a.jsxs("button",{type:"button",onClick:()=>La("semua"),className:sa("rounded-full px-2.5 py-0.5 text-xs transition",aa==="semua"?"bg-emerald-500/20 font-semibold text-emerald-300 ring-1 ring-emerald-500/40":"bg-slate-800/80 text-slate-400 hover:text-slate-200"),children:["Semua (",n.catatanWaktu.length,")"]}),Y.map(e=>{const t=n.catatanWaktu.filter(r=>r.setId===e.id).length,s=aa===e.id;return a.jsxs("button",{type:"button","data-testid":`filter-set-${e.id}`,onClick:()=>{La(e.id);const r=Ie(e.id,{sets:Y,drill:T,song:O});r!==null&&Da(r)},className:sa("rounded-full px-2.5 py-0.5 text-xs transition",s?"bg-emerald-500/20 font-semibold text-emerald-300 ring-1 ring-emerald-500/40":"bg-slate-800/80 text-slate-400 hover:text-slate-200"),children:[e.name," (",t,")"]},e.id)})]}),_a.length===0?a.jsx("p",{className:"mt-3 text-xs italic text-slate-500",children:"Belum ada komentar Judge Tape pada tampilan ini."}):a.jsx("ul",{className:"mt-3 space-y-1.5","data-testid":"daftar-catatan-judgetape",children:_a.map(e=>a.jsxs("li",{"data-testid":`item-judgetape-${e.id}`,className:"flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-2 text-xs",children:[a.jsxs("div",{className:"flex flex-1 flex-wrap items-center gap-2",children:[a.jsxs("button",{type:"button","data-testid":`putar-catatan-${e.id}`,onClick:()=>Da(e.detik),className:"inline-flex items-center gap-1 rounded-md border border-emerald-700/50 bg-emerald-950/40 px-2 py-0.5 font-mono font-bold text-emerald-300 hover:bg-emerald-900/50",children:["▶ ",pa(e.detik)]}),(e.labelSet||e.birama)&&a.jsxs("span",{"data-testid":`tautan-set-birama-${e.id}`,className:"rounded-md bg-slate-800 px-2 py-0.5 text-[11px] font-medium text-sky-300",children:[e.labelSet?`${e.labelSet}${e.hitunganSet?` · Hit. ${e.hitunganSet}`:""}`:"",e.labelSet&&e.birama?" · ":"",e.birama?`Birama ${e.birama}`:""]}),a.jsx("span",{className:"rounded bg-slate-800/80 px-1.5 py-0.5 text-[10px] uppercase text-slate-300",children:e.fokus==="umum"?"Umum":na[e.fokus]}),e.tingkat==="penting"&&a.jsx("span",{className:"rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300",children:"PRIORITAS"}),e.tingkat==="pujian"&&a.jsx("span",{className:"rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300",children:"KUAT"}),a.jsx("span",{className:"text-slate-100",children:e.teks})]}),a.jsx("button",{type:"button",onClick:()=>ke(e.id),className:"text-slate-500 hover:text-rose-400",title:"Hapus komentar",children:a.jsx(Za,{size:14})})]},e.id))})]}),a.jsxs(ta,{"data-testid":"grafik-tren-juri",children:[a.jsxs("div",{className:"mb-3 flex flex-wrap items-center justify-between gap-2",children:[a.jsxs("div",{children:[a.jsx("h2",{className:"text-sm font-semibold text-slate-100",children:"Grafik Tren Skor Simulasi Tim (Simulasi #1 → H-1 Lomba)"}),a.jsx("p",{className:"text-xs text-slate-400",children:"Pantau progres nilai bersih dan perkembangan tiap caption lintas uji coba penampilan."})]}),V.kenaikanTotal!==null&&a.jsxs("span",{"data-testid":"lencana-kenaikan-tren",className:sa("rounded-full border px-2.5 py-1 text-xs font-bold",V.kenaikanTotal>=0?"border-emerald-500/40 bg-emerald-500/15 text-emerald-300":"border-rose-500/40 bg-rose-500/15 text-rose-300"),children:[V.kenaikanTotal>=0?`+${v(V.kenaikanTotal)}`:v(V.kenaikanTotal)," poin sejak simulasi pertama"]})]}),V.titik.length<2?a.jsx("p",{className:"text-xs text-slate-400",children:"Simpan minimal 2 simulasi run-through pada tanggal berbeda untuk menampilkan kurva pertumbuhan skor menuju hari lomba."}):a.jsx(Pe,{titik:V.titik,aktifId:n.id,onPilih:K})]}),a.jsx(Te,{open:pe,onClose:()=>ba(!1),title:"Pratinjau Caption Recap Sheet A4",wide:!0,testId:"modal-pratinjau-rekap-juri",footer:a.jsxs("div",{className:"flex justify-end gap-2",children:[a.jsx(S,{variant:"ghost",onClick:()=>ba(!1),children:"Tutup"}),a.jsxs(S,{variant:"soft",onClick:Wa,children:[a.jsx(Ya,{size:14})," Unduh HTML"]}),a.jsxs(S,{variant:"primary",onClick:Ha,children:[a.jsx(va,{size:14})," Cetak Sekarang"]})]}),children:a.jsx("div",{className:"overflow-hidden rounded-lg border border-slate-700 bg-white",children:a.jsx("iframe",{title:"Pratinjau Caption Recap Sheet","data-testid":"iframe-pratinjau-rekap-juri",srcDoc:ja(),className:"h-[68vh] w-full border-0"})})})]})}function Pe({titik:d,aktifId:o,onPilih:b}){const C=Math.max(0,Math.floor(Math.min(...d.map(c=>c.skorAkhir))/10)*10-5),n=Math.min(100,Math.ceil(Math.max(...d.map(c=>c.skorAkhir))/10)*10+5),_=Math.max(10,n-C),u=c=>d.length===1?44+608/2:44+c/(d.length-1)*608,H=c=>168-(c-C)/_*144,U=d.map((c,z)=>`${u(z).toFixed(1)},${H(c.skorAkhir).toFixed(1)}`).join(" ");return a.jsx("div",{className:"overflow-x-auto",children:a.jsxs("svg",{viewBox:"0 0 680 210",className:"w-full min-w-[460px]",role:"img","aria-label":"Grafik tren skor simulasi penilaian juri","data-testid":"svg-tren-juri",children:[a.jsx("rect",{x:0,y:0,width:680,height:210,rx:12,fill:"#0f172a",stroke:"#1e293b"}),[0,.5,1].map(c=>{const z=C+c*_,P=H(z);return a.jsxs("g",{children:[a.jsx("line",{x1:44,y1:P,x2:652,y2:P,stroke:"#1e293b",strokeDasharray:"4 4"}),a.jsx("text",{x:36,y:P+4,textAnchor:"end",fontSize:"10",fill:"#94a3b8",children:Math.round(z)})]},c)}),a.jsx("polyline",{fill:"none",stroke:"#10b981",strokeWidth:"3",strokeLinecap:"round",strokeLinejoin:"round",points:U}),d.map((c,z)=>{const P=u(z),F=H(c.skorAkhir),W=c.id===o;return a.jsxs("g",{style:{cursor:"pointer"},onClick:()=>b(c.id),children:[a.jsx("circle",{cx:P,cy:F,r:W?7:5,fill:W?"#34d399":"#0f172a",stroke:"#10b981",strokeWidth:"2.5"}),a.jsx("text",{x:P,y:F-10,textAnchor:"middle",fontSize:"10.5",fontWeight:"700",fill:"#f8fafc",children:v(c.skorAkhir)}),a.jsx("text",{x:P,y:190,textAnchor:"middle",fontSize:"10",fill:"#cbd5e1",children:c.tanggal}),a.jsx("text",{x:P,y:202,textAnchor:"middle",fontSize:"9.5",fill:"#64748b",children:c.predikatBox})]},c.id)})]})})}export{Ue as PanelPenilaianJuri};
