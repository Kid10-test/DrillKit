import{h as W}from"./penilaianJuri-ONkuRXUF.js";function T(a,t,n){return Number.isFinite(a)?Math.max(t,Math.min(n,a)):t}function A(a){return Math.round(a*100)/100}const X={terdaftar:"Terdaftar",dinilai:"Sudah Dinilai",diterima:"Diterima",cadangan:"Daftar Tunggu / Cadangan",ditolak:"Belum Lolos"};function q(a){var d,l,u,g;if(!a)return null;const t=A(T(Number((d=a.ritmik)!=null?d:0),0,100)),n=A(T(Number((l=a.kepekaanNada)!=null?l:0),0,100)),e=A(T(Number((u=a.posturLangkah)!=null?u:0),0,100)),i=A(T(Number((g=a.koordinasiAlat)!=null?g:0),0,100)),o=A((t+n+e+i)/4),s=o>=85?"Sangat Direkomendasikan":o>=72?"Direkomendasikan":o>=60?"Cadangan Potensial":"Perlu Pembinaan Dasar";return{ritmik:t,kepekaanNada:n,posturLangkah:e,koordinasiAlat:i,rataRata:o,predikat:s}}function Z(a,t){var o;const n=(o=t==null?void 0:t.seksi)!=null?o:"all";return(a!=null?a:[]).filter(s=>t!=null&&t.hanyaSudahDinilai&&!s.nilai?!1:n==="all"?!0:s.minatSeksi1===n||s.minatSeksi2===n).map(s=>({calon:s,skor:q(s.nilai),pilihanKe:n==="all"||s.minatSeksi1===n?1:2})).sort((s,d)=>{var g,m,p,c,h,k;const l=(m=(g=s.skor)==null?void 0:g.rataRata)!=null?m:-1,u=(c=(p=d.skor)==null?void 0:p.rataRata)!=null?c:-1;return u!==l?u-l:s.pilihanKe!==d.pilihanKe?s.pilihanKe-d.pilihanKe:((h=s.calon.nama)!=null?h:"").localeCompare((k=d.calon.nama)!=null?k:"","id")}).map((s,d)=>({peringkat:d+1,...s}))}function Q(a,t){const n=a.replace(/[^a-zA-Z0-9]/g,"").slice(0,2).toUpperCase()||"MB",e=new Set(t.map(o=>(o.code||"").trim().toUpperCase()));let i=1;for(;i<9999;){const o=`${n}${String(i).padStart(2,"0")}`;if(!e.has(o))return o;i+=1}return`${n}${Date.now().toString().slice(-3)}`}function oa(a,t,n){var m,p,c,h,k,v;const e=(m=n==null?void 0:n.sekarang)!=null?m:Date.now();if(a.memberIdTertaut){const x=t.find(b=>b.id===a.memberIdTertaut);if(x)return{sudahAda:!0,member:x,calonDiperbarui:{...a,status:"diterima",updatedAt:e}}}const i=(n==null?void 0:n.seksiFinal)||a.seksiDiterima||a.minatSeksi1||"brass",o=(n==null?void 0:n.instrumenFinal)||a.instrumenDiterima||(i===a.minatSeksi2?a.minatInstrumen2:a.minatInstrumen1)||a.minatInstrumen1||"Anggota Baru",s=n!=null&&n.buatId?n.buatId():`m_${e.toString(36)}_${Math.random().toString(36).slice(2,6)}`,d=n!=null&&n.buatToken?n.buatToken():`t_${e.toString(36)}_${Math.random().toString(36).slice(2,8)}`,l=Q(i,t),u={id:s,code:l,name:a.nama.trim(),panggilan:((p=a.panggilan)==null?void 0:p.trim())||void 0,section:i,instrument:o.trim(),role:"member",joinYear:a.tahunAngkatan||new Date(e).getFullYear(),active:1,phone:((c=a.telepon)==null?void 0:c.trim())||void 0,instansiAsal:((h=a.instansiAsal)==null?void 0:h.trim())||void 0,kelasJurusan:((k=a.kelasJurusan)==null?void 0:k.trim())||void 0,nomorInduk:((v=a.nomorInduk)==null?void 0:v.trim())||void 0,notes:a.catatanPenguji?`Hasil Audisi: ${a.catatanPenguji}`:void 0,token:d,createdAt:e},g={...a,status:"diterima",seksiDiterima:i,instrumenDiterima:o.trim(),memberIdTertaut:u.id,updatedAt:e};return{sudahAda:!1,member:u,calonDiperbarui:g}}const aa=["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];function ta(a,t="MB",n){var d;const e=n?new Date(`${n}T00:00:00`):new Date,i=(d=aa[e.getMonth()])!=null?d:"I",o=Number.isFinite(e.getFullYear())?e.getFullYear():new Date().getFullYear(),s=t.replace(/[^a-zA-Z0-9]/g,"").toUpperCase().slice(0,8)||"MB";return`${String(Math.max(1,a)).padStart(3,"0")}/DISP/${s}/${i}/${o}`}function na(a){var e;const t=new Map;for(const i of a!=null?a:[]){const o=((e=i.instansiAsal)!=null?e:"").trim(),s=o||"Instansi Umum / Belum Diisi Asal Sekolah-Fakultas",d=o?o.toLowerCase().replace(/\s+/g," "):"__umum__",l=t.get(d);l?l.peserta.push(i):t.set(d,{namaInstansiTujuan:s,peserta:[i]})}const n=[];for(const[i,o]of t.entries()){const s=[...o.peserta].sort((d,l)=>{var g,m;const u=((g=d.kelasJurusan)!=null?g:"").localeCompare((m=l.kelasJurusan)!=null?m:"","id");return u!==0?u:d.name.localeCompare(l.name,"id")});n.push({kunci:i,namaInstansiTujuan:o.namaInstansiTujuan,peserta:s})}return n.sort((i,o)=>i.kunci==="__umum__"?1:o.kunci==="__umum__"?-1:i.namaInstansiTujuan.localeCompare(o.namaInstansiTujuan,"id"))}function ea(a){var s,d,l,u,g,m;if(!a)return{punyaAlergi:!1,punyaRiwayat:!1,bawaObatPribadi:!1,kontakDaruratLengkap:!1,tingkatSiaga:"belum_lengkap"};const t=!!((s=a.alergiMakanan)!=null&&s.trim()||(d=a.alergiObat)!=null&&d.trim()),n=!!((l=a.riwayatMedis)!=null&&l.trim()),e=!!((u=a.obatPribadi)!=null&&u.trim()),i=!!((g=a.kontakDaruratNama)!=null&&g.trim()&&((m=a.kontakDaruratTelepon)!=null&&m.trim()));return{punyaAlergi:t,punyaRiwayat:n,bawaObatPribadi:e,kontakDaruratLengkap:i,tingkatSiaga:t||n||e?"perhatian_khusus":i?"normal":"belum_lengkap"}}function K(a){let t="";for(let n=0;n<a.length;n++)t+=String.fromCharCode(a[n]);return btoa(t)}function N(a){const t=atob(a),n=new Uint8Array(t.length);for(let e=0;e<t.length;e++)n[e]=t.charCodeAt(e);return n}async function V(a,t){const n=new TextEncoder,e=await crypto.subtle.importKey("raw",n.encode(a),"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t,iterations:1e5,hash:"SHA-256"},e,{name:"AES-GCM",length:256},!1,["encrypt","decrypt"])}async function la(a,t,n="Unit Marching Band"){if(!t||t.trim().length<4)throw new Error("Kata sandi enkripsi medis minimal 4 karakter");const e=crypto.getRandomValues(new Uint8Array(16)),i=crypto.getRandomValues(new Uint8Array(12)),o=await V(t,e),s=JSON.stringify({medisAnggota:a}),d=await crypto.subtle.encrypt({name:"AES-GCM",iv:i},o,new TextEncoder().encode(s)),l={format:"drillkit-medis-terenkripsi",versi:1,dibuat:Date.now(),namaTim:n,jumlahKartu:a.length,garamB64:K(e),ivB64:K(i),cipherB64:K(new Uint8Array(d))};return JSON.stringify(l,null,2)}async function da(a,t){let n;try{n=JSON.parse(a)}catch{throw new Error("Berkas arsip medis tidak valid (bukan JSON)")}if((n==null?void 0:n.format)!=="drillkit-medis-terenkripsi")throw new Error("Bukan berkas arsip medis terenkripsi DrillKit");try{const e=N(n.garamB64),i=N(n.ivB64),o=N(n.cipherB64),s=await V(t,e),d=await crypto.subtle.decrypt({name:"AES-GCM",iv:i},s,o),l=JSON.parse(new TextDecoder().decode(d));return Array.isArray(l.medisAnggota)?l.medisAnggota:[]}catch{throw new Error("Kata sandi salah atau berkas medis telah berubah")}}function $(a){const t=Math.round(Number.isFinite(a)?a:0),n=t<0?"-":"",e=Math.abs(t).toString().replace(/\B(?=(\d{3})+(?!\d))/g,".");return`${n}Rp${e}`}function ua(a,t){return`KWT-${(t||new Date().toISOString().slice(0,10)).replace(/-/g,"")}-${String(Math.max(1,a)).padStart(3,"0")}`}function Y(a){var s,d;let t=0,n=0,e=0;const i=new Map;for(const l of a!=null?a:[]){const u=Math.max(0,Math.round(Number.isFinite(l.nominal)?l.nominal:0));if(l.jenis==="iuran_anggota"){t+=u;const g=(l.kategoriProgram||"Iuran Umum").trim(),m=i.get(g),p=Math.max((s=m==null?void 0:m.targetPerAnggota)!=null?s:0,Math.round((d=l.targetPerAnggota)!=null?d:0));m?(m.terkumpul+=u,m.jumlahTransaksi+=1,m.targetPerAnggota=p):i.set(g,{kategoriProgram:g,targetPerAnggota:p,terkumpul:u,jumlahTransaksi:1})}else l.jenis==="pemasukan_umum"?n+=u:l.jenis==="pengeluaran"&&(e+=u)}const o=t+n;return{totalIuranAnggota:t,totalPemasukanUmum:n,totalPemasukan:o,totalPengeluaran:e,saldoAkhir:o-e,programIuran:[...i.values()].sort((l,u)=>l.kategoriProgram.localeCompare(u.kategoriProgram,"id"))}}function ia(a,t,n,e){const i=(n!=null?n:"").trim().toLowerCase(),o=(t!=null?t:[]).filter(l=>{var u;return l.jenis==="iuran_anggota"&&((u=l.kategoriProgram)!=null?u:"").trim().toLowerCase()===i}),s=o.reduce((l,u)=>{var g;return Math.max(l,Math.round((g=u.targetPerAnggota)!=null?g:0))},0),d=Math.max(0,Math.round(e!=null?e:s));return[...a!=null?a:[]].filter(l=>l.active!==0).sort((l,u)=>l.name.localeCompare(u.name,"id")).map(l=>{const u=o.filter(c=>c.memberId===l.id).sort((c,h)=>h.tanggal.localeCompare(c.tanggal)),g=u.reduce((c,h)=>c+Math.max(0,Math.round(h.nominal||0)),0),m=Math.max(0,d-g),p=d>0?g>=d?"lunas":g>0?"cicilan":"belum_bayar":g>0?"lunas":"belum_bayar";return{member:l,terbayar:g,targetTagihan:d,sisaTunggakan:m,status:p,jumlahCicilan:u.length,transaksiTerakhir:u[0]}})}const ga=["sessions","attendance","drills","sets","songs","setlists","kemajuan","memberNotes","evaluasi","targetSetoran","setoran","logPerubahan","countSheets","logistikLomba","penilaianLomba","judgeTapeAudio","rekamanAudio","partiturBerkas","kasIuran","audisi"];function ma(a){var l,u,g,m,p,c,h,k,v,x,b,I,w,P,y,M,j,B,L,U,R,z,_,C,E,O,F,J,H,G;const t=((l=a.members)!=null?l:[]).filter(f=>f.active!==0),n=((u=a.attendance)!=null?u:[]).filter(f=>f.status==="hadir").length,e=((g=a.attendance)!=null?g:[]).length,i=e>0?A(n/e*100):0,o=Y((m=a.kasIuran)!=null?m:[]),s=((p=a.penilaianLomba)!=null?p:[]).length>0?Math.max(...((c=a.penilaianLomba)!=null?c:[]).map(f=>W(f).skorAkhir)):null,d=a.skorSimulasiPuncak!==void 0?a.skorSimulasiPuncak:s;return{id:a.idArsip,namaMusim:a.namaMusim.trim()||`Musim Kejuaraan ${a.tahunMusim}`,tahunMusim:a.tahunMusim.trim()||String(new Date().getFullYear()),tanggalArsip:a.tanggalArsip,catatanPenutup:((h=a.catatanPenutup)==null?void 0:h.trim())||void 0,ringkasan:{jmlAnggotaAktif:t.length,jmlSesi:((k=a.sessions)!=null?k:[]).length,rataKehadiranPersen:i,jmlLagu:((v=a.songs)!=null?v:[]).length,jmlDrill:((x=a.drills)!=null?x:[]).length,skorPuncakSimulasi:d,saldoAkhirKas:o.saldoAkhir,daftarRepertoar:((b=a.songs)!=null?b:[]).map(f=>f.title),daftarDrill:((I=a.drills)!=null?I:[]).map(f=>f.name)},muatanMusim:{membersSnapshot:(w=a.members)!=null?w:[],sessions:(P=a.sessions)!=null?P:[],attendance:(y=a.attendance)!=null?y:[],drills:(M=a.drills)!=null?M:[],sets:(j=a.sets)!=null?j:[],songs:(B=a.songs)!=null?B:[],setlists:(L=a.setlists)!=null?L:[],kemajuan:(U=a.kemajuan)!=null?U:[],memberNotes:(R=a.memberNotes)!=null?R:[],evaluasi:(z=a.evaluasi)!=null?z:[],targetSetoran:(_=a.targetSetoran)!=null?_:[],setoran:(C=a.setoran)!=null?C:[],logPerubahan:(E=a.logPerubahan)!=null?E:[],countSheets:(O=a.countSheets)!=null?O:[],logistikLomba:(F=a.logistikLomba)!=null?F:[],penilaianLomba:(J=a.penilaianLomba)!=null?J:[],kasIuran:(H=a.kasIuran)!=null?H:[],audisi:(G=a.audisi)!=null?G:[]},createdAt:Date.now()}}function r(a){return String(a!=null?a:"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const ra=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];function S(a){var e;const t=/^(\d{4})-(\d{2})-(\d{2})$/.exec(a||"");if(!t)return a||"—";const n=(e=ra[Number(t[2])-1])!=null?e:t[2];return`${Number(t[3])} ${n} ${t[1]}`}const D=`
  @page { size: A4 portrait; margin: 14mm 15mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #0f172a;
    background: #ffffff;
    font-size: 11px;
    line-height: 1.45;
  }
  table { width: 100%; border-collapse: collapse; font-size: 10.5px; }
  th, td { border: 1px solid #cbd5e1; padding: 5px 7px; vertical-align: top; }
  th { background: #1e293b; color: #ffffff; font-weight: 700; text-align: left; }
  td.angka, th.angka { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
`;function ca(a){const t=Z(a.daftarCalon),n=t.map(e=>`<tr>
        <td style="text-align:center;"><strong>${e.peringkat}</strong></td>
        <td>
          <strong>${r(e.calon.nama)}</strong>
          ${e.calon.instansiAsal?`<div style="font-size:9.5px;color:#475569;">${r(e.calon.instansiAsal)}${e.calon.kelasJurusan?` · ${r(e.calon.kelasJurusan)}`:""}</div>`:""}
        </td>
        <td>${r(e.calon.minatSeksi1)}${e.calon.minatInstrumen1?` (${r(e.calon.minatInstrumen1)})`:""}${e.calon.minatSeksi2?`<div style="font-size:9.5px;color:#64748b;">Minat 2: ${r(e.calon.minatSeksi2)}</div>`:""}</td>
        <td class="angka">${e.skor?e.skor.ritmik:"—"}</td>
        <td class="angka">${e.skor?e.skor.kepekaanNada:"—"}</td>
        <td class="angka">${e.skor?e.skor.posturLangkah:"—"}</td>
        <td class="angka">${e.skor?e.skor.koordinasiAlat:"—"}</td>
        <td class="angka"><strong>${e.skor?e.skor.rataRata.toFixed(1).replace(".",","):"—"}</strong></td>
        <td>${r(X[e.calon.status])}</td>
      </tr>`).join("");return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Rekapitulasi Audisi — ${r(a.namaTim)}</title>
<style>
  ${D}
  .kop { border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 12px; }
  .kop h1 { margin: 0; font-size: 16px; color: #0f172a; }
  .kop .sub { font-size: 10.5px; color: #475569; margin-top: 2px; }
</style>
</head>
<body>
  <div class="kop">
    <h1>REKAPITULASI HASIL SELEKSI &amp; AUDISI ANGGOTA BARU</h1>
    <div class="sub"><strong>${r(a.namaTim)}</strong>${a.labelSeksiFilter?` · Peminatan: ${r(a.labelSeksiFilter)}`:""} · Total Pendaftar: ${t.length} orang</div>
  </div>
  <table>
    <thead>
      <tr>
        <th style="width:36px;text-align:center;">#</th>
        <th>Nama Calon &amp; Asal</th>
        <th>Peminatan Seksi</th>
        <th class="angka">Ritmik</th>
        <th class="angka">Nada</th>
        <th class="angka">Postur</th>
        <th class="angka">Alat</th>
        <th class="angka">Rata-rata</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      ${n||'<tr><td colspan="9" style="text-align:center;color:#64748b;">Belum ada data calon audisi.</td></tr>'}
    </tbody>
  </table>
</body>
</html>`}function pa(a){var m,p,c,h,k,v,x;const t=na(a.peserta),n=((m=a.kota)==null?void 0:m.trim())||"Tempat",e=S(a.tanggalSurat||new Date().toISOString().slice(0,10)),i=a.tanggalMulai===a.tanggalSelesai||!a.tanggalSelesai?S(a.tanggalMulai):`${S(a.tanggalMulai)} s.d. ${S(a.tanggalSelesai)}`,o=Math.max(1,(p=a.nomorUrutAwal)!=null?p:1),s=(c=a.kop)!=null?c:{},d=((h=s.namaPembina)==null?void 0:h.trim())||"",l=((k=s.jabatanPembina)==null?void 0:k.trim())||"Pembina / Penanggung Jawab",u=((v=s.namaKetuaUnit)==null?void 0:v.trim())||((x=a.namaPelatih)==null?void 0:x.trim())||"Pelatih / Ketua Unit",g=t.map((b,I)=>{const w=ta(o+I,a.namaTim,a.tanggalSurat||a.tanggalMulai),P=b.peserta.map((y,M)=>`<tr>
            <td style="text-align:center;">${M+1}</td>
            <td><strong>${r(y.name)}</strong></td>
            <td>${r(y.nomorInduk||"—")}</td>
            <td>${r(y.kelasJurusan||"—")}</td>
            <td>${r(y.instrument||y.section)}</td>
          </tr>`).join("");return`<section class="lembar-surat${I<t.length-1?" pisah-halaman":""}">
        <div class="kop-resmi">
          ${a.logoDataUrl?`<img src="${r(a.logoDataUrl)}" alt="Logo Unit" class="logo-kop" />`:""}
          <div class="teks-kop">
            ${s.namaInstansiInduk?`<div class="induk">${r(s.namaInstansiInduk)}</div>`:""}
            <div class="unit">${r(a.namaTim)}</div>
            ${s.alamatSekretariat?`<div class="alamat">${r(s.alamatSekretariat)}</div>`:""}
            ${s.kontakResmi?`<div class="alamat">${r(s.kontakResmi)}</div>`:""}
          </div>
        </div>

        <div class="baris-meta">
          <div>
            <div>Nomor : <strong>${r(w)}</strong></div>
            <div>Lampiran : ${b.peserta.length>5?"1 (satu) daftar nama":"—"}</div>
            <div>Perihal : <strong>${r(a.perihal||"Permohonan Izin / Dispensasi Kegiatan")}</strong></div>
          </div>
          <div style="text-align:right;">${r(n)}, ${r(e)}</div>
        </div>

        <div class="tujuan">
          Kepada Yth.<br />
          <strong>Pimpinan / Kepala / Dekan ${r(b.namaInstansiTujuan)}</strong><br />
          di Tempat
        </div>

        <p>Dengan hormat,</p>
        <p>
          Sehubungan dengan pelaksanaan kegiatan <strong>${r(a.namaKegiatan)}</strong> oleh unit
          <strong>${r(a.namaTim)}</strong>, bersama surat ini kami memohon kesediaan Bapak/Ibu untuk
          memberikan izin / dispensasi kepada anggota kami yang berasal dari
          <strong>${r(b.namaInstansiTujuan)}</strong> pada:
        </p>

        <table class="tabel-agenda">
          <tbody>
            <tr><td style="width:130px;">Hari / Tanggal</td><td>: <strong>${r(i)}</strong></td></tr>
            ${a.waktuKegiatan?`<tr><td>Waktu</td><td>: ${r(a.waktuKegiatan)}</td></tr>`:""}
            <tr><td>Tempat / Lokasi</td><td>: ${r(a.lokasiKegiatan||"Lapangan Latihan / Arena Kejuaraan")}</td></tr>
          </tbody>
        </table>

        <p style="margin-bottom:6px;">Adapun daftar nama peserta yang dimohonkan dispensasi adalah sebagai berikut:</p>
        <table class="tabel-peserta">
          <thead>
            <tr>
              <th style="width:34px;text-align:center;">No</th>
              <th>Nama Lengkap</th>
              <th style="width:115px;">NIS / NIM / ID</th>
              <th style="width:135px;">Kelas / Jurusan</th>
              <th style="width:120px;">Seksi / Instrumen</th>
            </tr>
          </thead>
          <tbody>
            ${P}
          </tbody>
        </table>

        <p>
          Demikian surat permohonan dispensasi ini kami sampaikan. Atas perhatian, dukungan, dan kerja sama
          Bapak/Ibu, kami ucapkan terima kasih.
        </p>

        <div class="ttd-blok">
          ${d?`<div class="ttd-kolom">
                  <div>Mengetahui,</div>
                  <div>${r(l)}</div>
                  <div class="ruang-ttd"></div>
                  <div><strong><u>${r(d)}</u></strong></div>
                  ${s.nipPembina?`<div style="font-size:10px;color:#334155;">NIP/NIDN: ${r(s.nipPembina)}</div>`:""}
                </div>`:"<div></div>"}
          <div class="ttd-kolom">
            <div>Hormat kami,</div>
            <div>Pengurus / Pelatih ${r(a.namaTim)}</div>
            <div class="ruang-ttd"></div>
            <div><strong><u>${r(u)}</u></strong></div>
          </div>
        </div>
      </section>`}).join(`
`);return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Surat Dispensasi — ${r(a.namaKegiatan)}</title>
<style>
  @page { size: A4 portrait; margin: 16mm 18mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: "Times New Roman", Georgia, Cambria, serif;
    color: #0f172a;
    background: #ffffff;
    font-size: 11.5pt;
    line-height: 1.5;
  }
  .pisah-halaman { page-break-after: always; break-after: page; }
  .kop-resmi {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 14px;
    border-bottom: 3px double #0f172a;
    padding-bottom: 8px;
    margin-bottom: 14px;
    text-align: center;
  }
  .logo-kop { height: 58px; width: auto; }
  .teks-kop .induk { font-size: 11pt; font-weight: 700; text-transform: uppercase; color: #1e293b; }
  .teks-kop .unit { font-size: 14.5pt; font-weight: 800; text-transform: uppercase; color: #0f172a; letter-spacing: 0.02em; }
  .teks-kop .alamat { font-size: 9.5pt; color: #334155; }
  .baris-meta {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 14px;
    font-size: 11pt;
  }
  .tujuan { margin-bottom: 12px; }
  p { margin: 8px 0; text-align: justify; }
  .tabel-agenda { border-collapse: collapse; margin: 6px 0 10px 14px; font-size: 11pt; }
  .tabel-agenda td { border: 0; padding: 2px 6px; vertical-align: top; }
  .tabel-peserta { width: 100%; border-collapse: collapse; font-size: 10pt; font-family: ui-sans-serif, -apple-system, sans-serif; margin: 6px 0 12px; }
  .tabel-peserta th, .tabel-peserta td { border: 1px solid #334155; padding: 5px 7px; }
  .tabel-peserta th { background: #e2e8f0; color: #0f172a; font-weight: 700; text-align: left; }
  .ttd-blok {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
    margin-top: 24px;
    text-align: center;
    font-size: 11pt;
  }
  .ruang-ttd { height: 58px; }
</style>
</head>
<body>
  ${g||"<p>Belum ada peserta yang dipilih untuk surat dispensasi.</p>"}
</body>
</html>`}function ha(a){const n=a.anggota.filter(e=>e.active!==0).map(e=>{const i=a.petaMedis.get(e.id),o=ea(i);return{m:e,k:i,siaga:o}}).filter(e=>a.hanyaPerhatianKhusus?e.siaga.tingkatSiaga==="perhatian_khusus":!0).map(({m:e,k:i,siaga:o})=>`<tr style="background:${o.tingkatSiaga==="perhatian_khusus"?"#fef2f2":"#ffffff"};">
        <td>
          <strong>${r(e.name)}</strong>
          <div style="font-size:9.5px;color:#475569;">${r(e.code)} · ${r(e.instrument||e.section)}</div>
        </td>
        <td style="text-align:center;"><strong>${r((i==null?void 0:i.golonganDarah)||"-")}</strong></td>
        <td>
          ${i!=null&&i.alergiObat?`<div><strong>Alergi Obat:</strong> ${r(i.alergiObat)}</div>`:""}
          ${i!=null&&i.alergiMakanan?`<div><strong>Alergi Makanan:</strong> ${r(i.alergiMakanan)}</div>`:""}
          ${i!=null&&i.riwayatMedis?`<div><strong>Riwayat:</strong> ${r(i.riwayatMedis)}</div>`:""}
          ${!(i!=null&&i.alergiObat)&&!(i!=null&&i.alergiMakanan)&&!(i!=null&&i.riwayatMedis)?'<span style="color:#64748b;">Tidak ada catatan khusus</span>':""}
        </td>
        <td>${r((i==null?void 0:i.obatPribadi)||"—")}</td>
        <td>
          ${i!=null&&i.kontakDaruratNama?`<strong>${r(i.kontakDaruratNama)}</strong>${i.kontakDaruratHubungan?` (${r(i.kontakDaruratHubungan)})`:""}<br /><strong>${r(i.kontakDaruratTelepon)}</strong>`:'<span style="color:#dc2626;font-weight:700;">Belum diisi</span>'}
        </td>
      </tr>`).join("");return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Lembar Siaga Medis Darurat — ${r(a.namaTim)}</title>
<style>
  ${D}
  .rahasia {
    background: #7f1d1d;
    color: #ffffff;
    padding: 6px 10px;
    border-radius: 6px;
    font-weight: 700;
    font-size: 10.5px;
    margin-bottom: 10px;
    letter-spacing: 0.03em;
  }
  h1 { margin: 0 0 8px; font-size: 15px; color: #0f172a; }
</style>
</head>
<body>
  <div class="rahasia">DOKUMEN RAHASIA TIM MEDIS &amp; PELATIH KEPALA — DILARANG DISEBARKAN KE PUBLIK / GRUP UMUM</div>
  <h1>DAFTAR SIAGA MEDIS &amp; KONTAK DARURAT LAPANGAN — ${r(a.namaTim)}</h1>
  <table>
    <thead>
      <tr>
        <th style="width:140px;">Anggota</th>
        <th style="width:48px;text-align:center;">Gol.</th>
        <th>Alergi &amp; Riwayat Kesehatan</th>
        <th style="width:145px;">Obat Pribadi / Penanganan</th>
        <th style="width:155px;">Kontak Darurat Wali</th>
      </tr>
    </thead>
    <tbody>
      ${n||'<tr><td colspan="5" style="text-align:center;color:#64748b;">Tidak ada data medis yang sesuai filter.</td></tr>'}
    </tbody>
  </table>
</body>
</html>`}function ka(a){const{transaksi:t}=a;return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Kwitansi ${r(t.nomorKwitansi)}</title>
<style>
  @page { size: A5 landscape; margin: 10mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    color: #0f172a;
    background: #ffffff;
    padding: 8px;
  }
  .kartu {
    border: 2px solid #0f172a;
    border-radius: 10px;
    padding: 14px 18px;
    max-width: 680px;
  }
  .kepala {
    display: flex;
    justify-content: space-between;
    border-bottom: 2px solid #cbd5e1;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }
  .judul { font-size: 15px; font-weight: 800; color: #0f172a; }
  .no { font-size: 11px; font-weight: 700; color: #047857; }
  .baris { display: flex; margin: 5px 0; font-size: 12px; }
  .lbl { width: 150px; color: #475569; }
  .nominal {
    margin-top: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #ecfdf5;
    border: 1px solid #10b981;
    border-radius: 8px;
    padding: 8px 12px;
  }
  .nominal .angka-besar { font-size: 18px; font-weight: 800; color: #065f46; }
</style>
</head>
<body>
  <div class="kartu">
    <div class="kepala">
      <div>
        <div class="judul">BUKTI PEMBAYARAN KAS / IURAN TC</div>
        <div style="font-size:11px;color:#475569;">${r(a.namaTim)}</div>
      </div>
      <div style="text-align:right;">
        <div class="no">${r(t.nomorKwitansi)}</div>
        <div style="font-size:11px;color:#475569;">Tanggal: ${r(S(t.tanggal))}</div>
      </div>
    </div>
    <div class="baris"><div class="lbl">Telah diterima dari</div><div>: <strong>${r(a.namaAnggota||"Pemasukan Umum Unit")}</strong>${a.kodeAnggota?` (${r(a.kodeAnggota)})`:""}</div></div>
    <div class="baris"><div class="lbl">Program / Keperluan</div><div>: <strong>${r(t.kategoriProgram)}</strong></div></div>
    <div class="baris"><div class="lbl">Metode Pembayaran</div><div>: ${t.metode==="transfer"?"Transfer":"Tunai"}</div></div>
    ${t.keterangan?`<div class="baris"><div class="lbl">Catatan</div><div>: ${r(t.keterangan)}</div></div>`:""}
    ${typeof a.sisaTunggakan=="number"?`<div class="baris"><div class="lbl">Sisa Tagihan Program</div><div>: <strong>${a.sisaTunggakan===0?"LUNAS":$(a.sisaTunggakan)}</strong></div></div>`:""}
    <div class="nominal">
      <div>
        <div style="font-size:10px;color:#065f46;text-transform:uppercase;">Nominal Diterima</div>
        <div class="angka-besar">${r($(t.nominal))}</div>
      </div>
      <div style="text-align:right;font-size:11px;color:#334155;">
        Bendahara / Penerima,<br /><br />
        <strong>${r(t.penerimaOleh||"Bendahara Unit")}</strong>
      </div>
    </div>
  </div>
</body>
</html>`}function ba(a){var o;const t=Y(a.transaksi),n=a.kategoriProgramFokus||((o=t.programIuran[0])==null?void 0:o.kategoriProgram)||"Iuran TC",i=ia(a.anggotaAktif,a.transaksi,n).map((s,d)=>`<tr>
        <td style="text-align:center;">${d+1}</td>
        <td><strong>${r(s.member.name)}</strong> <span style="color:#64748b;">(${r(s.member.code)})</span></td>
        <td class="angka">${r($(s.terbayar))}</td>
        <td class="angka">${r($(s.sisaTunggakan))}</td>
        <td style="text-align:center;"><strong>${s.status==="lunas"?"LUNAS":s.status==="cicilan"?"CICILAN":"BELUM"}</strong></td>
      </tr>`).join("");return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Rekap Buku Kas &amp; Iuran — ${r(a.namaTim)}</title>
<style>
  ${D}
  .ringkasan { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 10px 0 14px; }
  .kotak { border: 1px solid #cbd5e1; border-radius: 6px; padding: 7px 10px; background: #f8fafc; }
  .kotak .lbl { font-size: 9.5px; color: #475569; text-transform: uppercase; }
  .kotak .val { font-size: 14px; font-weight: 800; color: #0f172a; margin-top: 2px; }
</style>
</head>
<body>
  <h1 style="margin:0;font-size:16px;">REKAPITULASI BUKU KAS &amp; IURAN KEGIATAN — ${r(a.namaTim)}</h1>
  <div class="ringkasan">
    <div class="kotak"><div class="lbl">Total Pemasukan</div><div class="val">${r($(t.totalPemasukan))}</div></div>
    <div class="kotak"><div class="lbl">Total Pengeluaran</div><div class="val">${r($(t.totalPengeluaran))}</div></div>
    <div class="kotak"><div class="lbl">Saldo Akhir Kas</div><div class="val">${r($(t.saldoAkhir))}</div></div>
  </div>
  <h2 style="font-size:12px;margin:12px 0 6px;">Status Pembayaran Program: ${r(n)}</h2>
  <table>
    <thead>
      <tr>
        <th style="width:34px;text-align:center;">No</th>
        <th>Anggota</th>
        <th class="angka">Terbayar</th>
        <th class="angka">Sisa Tunggakan</th>
        <th style="width:90px;text-align:center;">Status</th>
      </tr>
    </thead>
    <tbody>
      ${i||'<tr><td colspan="5" style="text-align:center;color:#64748b;">Belum ada anggota aktif.</td></tr>'}
    </tbody>
  </table>
</body>
</html>`}function fa(a,t){const n=t.ringkasan;return`<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<title>Arsip Musim — ${r(t.namaMusim)}</title>
<style>
  ${D}
  .bingkai { border: 2px solid #0f172a; border-radius: 10px; padding: 18px; }
  .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 12px 0; }
  .kartu { border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 10px; background: #f8fafc; }
  .kartu .lbl { font-size: 9.5px; color: #475569; text-transform: uppercase; }
  .kartu .val { font-size: 15px; font-weight: 800; color: #0f172a; margin-top: 2px; }
</style>
</head>
<body>
  <div class="bingkai">
    <h1 style="margin:0;font-size:17px;">LAPORAN ARSIP LINTAS-MUSIM — ${r(a)}</h1>
    <p style="margin:4px 0 10px;color:#475569;"><strong>${r(t.namaMusim)}</strong> · Tahun ${r(t.tahunMusim)} · Dibekukan pada ${r(S(t.tanggalArsip))}</p>
    <div class="grid">
      <div class="kartu"><div class="lbl">Anggota Aktif</div><div class="val">${n.jmlAnggotaAktif} orang</div></div>
      <div class="kartu"><div class="lbl">Sesi Latihan &amp; Lomba</div><div class="val">${n.jmlSesi} sesi (${n.rataKehadiranPersen}% hadir)</div></div>
      <div class="kartu"><div class="lbl">Skor Puncak Simulasi</div><div class="val">${n.skorPuncakSimulasi!==null?n.skorPuncakSimulasi.toFixed(2).replace(".",","):"—"}</div></div>
      <div class="kartu"><div class="lbl">Repertoar Lagu</div><div class="val">${n.jmlLagu} karya</div></div>
      <div class="kartu"><div class="lbl">Paket Drill / Show</div><div class="val">${n.jmlDrill} drill</div></div>
      <div class="kartu"><div class="lbl">Saldo Akhir Kas Musim</div><div class="val">${r($(n.saldoAkhirKas))}</div></div>
    </div>
    ${t.catatanPenutup?`<p><strong>Catatan Penutup Musim:</strong> ${r(t.catatanPenutup)}</p>`:""}
  </div>
</body>
</html>`}export{X as L,ga as T,pa as a,ca as b,la as c,da as d,ea as e,ha as f,Y as g,q as h,ia as i,$ as j,na as k,oa as l,ua as m,ka as n,ba as o,fa as p,ma as q,Z as s};
