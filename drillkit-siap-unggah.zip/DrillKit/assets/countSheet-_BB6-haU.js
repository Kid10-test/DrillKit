import{a as Y}from"./analitik-CXKdI_a0.js";import{d as J,s as q,H as V}from"./tempoTimeline-C4caWYQh.js";import{l as Z,s as aa,n as ta}from"./bukaBerkas-DDm--XDW.js";import{r as na}from"./gerak-BKaWXUpL.js";import{x as w,Y as z}from"./index-BsJ-AR0G.js";import{e as g,a as ea}from"./print-dO7JsCGC.js";import{p as oa}from"./segmenDrill-D1anFPod.js";function ia(a,t,n){const e=((t-a)%360+540)%360-180;return a+e*n}function E(a,t,n){var p,s,d,i;const e={x:a.x,y:a.y,x2:a.x2,y2:a.y2,rotasi:(p=a.rotasi)!=null?p:0};if(!a.perSet||!t.length||n<0)return e;const o=Math.min(n,t.length-1);for(let l=o;l>=0;l--){const u=a.perSet[t[l].id];if(u)return{x:u.x,y:u.y,x2:(s=u.x2)!=null?s:e.x2,y2:(d=u.y2)!=null?d:e.y2,rotasi:(i=u.rotasi)!=null?i:e.rotasi}}return e}function xa(a,t,n,e=0){if(!(a!=null&&a.length))return[];const o=Math.min(1,Math.max(0,e)),p=n>=0&&n+1<t.length;return a.map(s=>{const d=E(s,t,n);if(o<=0||!p||!s.perSet)return{...s,x:d.x,y:d.y,x2:d.x2,y2:d.y2,rotasi:d.rotasi};const i=E(s,t,n+1),l=(u,h)=>u+(h-u)*o;return{...s,x:l(d.x,i.x),y:l(d.y,i.y),x2:d.x2!=null&&i.x2!=null?l(d.x2,i.x2):d.x2,y2:d.y2!=null&&i.y2!=null?l(d.y2,i.y2):d.y2,rotasi:ia(d.rotasi,i.rotasi,o)}})}function $a(a){return!!(a.perSet&&Object.keys(a.perSet).length>0)}function sa(a,t){return!(a!=null&&a.length)||!t?[]:a.filter(n=>{var e;return(e=n.kruIds)==null?void 0:e.includes(t)})}function Ca(a,t){var n;return(n=a.kruIds)!=null&&n.length?a.kruIds.map(e=>{const o=t.get(e);return o?o.code||o.name:e}).join(", "):""}const Sa=["flag","rifle","sabre","swing_flag","air_blade","dance","prop"],ra={flag:"Flag (Bendera)",rifle:"Rifle (Senapan)",sabre:"Sabre (Pedang)",swing_flag:"Swing Flag",air_blade:"Air Blade",dance:"Dance / Body",prop:"Prop / Panggung"},O={flag:"Flag",rifle:"Rifle",sabre:"Sabre",swing_flag:"Swing",air_blade:"Blade",dance:"Dance",prop:"Prop"},L={flag:{latarCetak:"#fce7f3",tepiCetak:"#db2777",teksCetak:"#9d174d",titikGelap:"#f472b6"},rifle:{latarCetak:"#dbeafe",tepiCetak:"#2563eb",teksCetak:"#1e40af",titikGelap:"#60a5fa"},sabre:{latarCetak:"#ede9fe",tepiCetak:"#7c3aed",teksCetak:"#5b21b6",titikGelap:"#a78bfa"},swing_flag:{latarCetak:"#ffedd5",tepiCetak:"#ea580c",teksCetak:"#9a3412",titikGelap:"#fb923c"},air_blade:{latarCetak:"#ccfbf1",tepiCetak:"#0d9488",teksCetak:"#115e59",titikGelap:"#2dd4bf"},dance:{latarCetak:"#fef3c7",tepiCetak:"#d97706",teksCetak:"#92400e",titikGelap:"#fbbf24"},prop:{latarCetak:"#f1f5f9",tepiCetak:"#475569",teksCetak:"#1e293b",titikGelap:"#94a3b8"}},va=["depan","belakang","sisi_1","sisi_2","serong_depan_1","serong_depan_2","bebas"],da={depan:"Hadap Penonton (Depan)",belakang:"Hadap Belakang",sisi_1:"Hadap Sisi 1 (Kiri)",sisi_2:"Hadap Sisi 2 (Kanan)",serong_depan_1:"Serong Depan S1 (45°)",serong_depan_2:"Serong Depan S2 (45°)",bebas:"Bebas / Mengikuti Gerak"},Aa={flag:["Drop Spin","Peggy Spin","Butterfly","Carve","Thumb Flip","Extension","Toss 45","Toss Parallel","J-Toss","Flourish","Slam / Present","Cradle / Hold"],rifle:["Spins","Flourish","Single","Double","Triple","Quad","Five","Backhand","Port / Present","Exchange (Tukar Alat)","Hold / Diam"],sabre:["Spins","Blade Toss","Hilt Toss","Single","Double","Triple","Quad","Flourish","En Garde / Present","Exchange (Tukar Alat)","Hold / Diam"],swing_flag:["Figure 8","Double Carve","Windmill","Cross Toss","Turn & Release","Open Frame","Hold / Diam"],air_blade:["Spin Flow","Single Toss","Double Toss","Triple Toss","45 Release","Pass-Through","Exchange (Tukar Alat)"],dance:["Chassé","Jazz Run","Chainé Turn","Lunge / Pose","Leap / Grand Jeté","Floor Roll","Ripple Body","Ganti Alat (Equipment Change)"],prop:["Dorong Prop","Putar Prop 90°","Putar Prop 180°","Kunci Roda / Parkir","Ambil Alat dari Prop","Simpan Alat ke Prop"]};function I(a){return[...a!=null?a:[]].sort((t,n)=>t.urutan-n.urutan).map((t,n)=>({...t,urutan:n,counts:Math.max(1,Math.round(t.counts||8)),aksenCount:D(t.aksenCount,t.counts||8),tangkapCount:D(t.tangkapCount,t.counts||8)}))}function D(a,t){if(!(a!=null&&a.length))return;const n=Math.max(1,Math.round(t||8)),e=Array.from(new Set(a.map(o=>Math.round(Number(o))).filter(o=>Number.isFinite(o)&&o>=1&&o<=n))).sort((o,p)=>o-p);return e.length?e:void 0}function Da(a,t,n){var o;const e=new Set((o=D(a,n))!=null?o:[]);return e.has(t)?e.delete(t):e.add(t),D(Array.from(e),n)}function ya(a,t){const n=(a!=null?a:"").trim(),e=t.trim();return e?n?n.endsWith(",")||n.endsWith(";")||n.endsWith("·")?`${n} ${e}`:`${n}, ${e}`:e:n}function Ba(a){var l,u,h,r,k,x,c,$,A;const t=(l=a.mode)!=null?l:"per-8",n=(u=a.alatUtama)!=null?u:"flag",e=[...(h=a.sets)!=null?h:[]].sort((b,m)=>b.order-m.order),o=Math.max(.25,a.drill.beatsPerCount||1),p=new Map;for(const b of(r=a.blokSebelumnya)!=null?r:[])b.setId&&p.set(`${b.setId}__${(k=b.offsetDalamSet)!=null?k:0}`,b);const s=[];for(let b=0;b<e.length;b+=1){const m=e[b],C=Math.max(1,Math.round(m.counts||8)),y=((x=m.name)==null?void 0:x.trim())||`Set ${b+1}`;if(t==="per-8"&&C>8){let S=0;for(;S<C;){const f=Math.min(8,C-S);s.push({setId:m.id,offset:S,len:f,label:`${y} (${S+1}–${S+f})`}),S+=f}}else s.push({setId:m.id,offset:0,len:C,label:y})}const d=a.song?{bpm:Math.max(20,a.song.bpm||a.drill.tempo||120),tandaBirama:(c=a.song.tandaBirama)!=null?c:J(a.song.beats||4),tempoMap:($=a.song.tempoMap)!=null?$:[],latih:(A=a.song.latih)!=null?A:null}:{bpm:Math.max(20,a.drill.tempo||120),tandaBirama:V(),tempoMap:[],latih:null},i=s.length>0?oa(s.map(b=>({counts:b.len,name:b.label})),d,{beatsPerCount:o}):null;return s.map((b,m)=>{var B,M,T,P;const C=i==null?void 0:i.set[m],y=C?Math.max(1,Math.floor(C.mulaiBirama+1e-9)):1,S=C?Math.max(y,Math.ceil(C.akhirBirama-1e-9)-1):y,f=p.get(`${b.setId}__${b.offset}`);return{id:(B=f==null?void 0:f.id)!=null?B:w("bcs_"),urutan:m,setId:b.setId,offsetDalamSet:b.offset,labelBagian:b.label,counts:b.len,biramaDari:y,biramaSampai:S,alat:(M=f==null?void 0:f.alat)!=null?M:n,teknik:(T=f==null?void 0:f.teknik)!=null?T:"",aksenCount:D(f==null?void 0:f.aksenCount,b.len),tangkapCount:D(f==null?void 0:f.tangkapCount,b.len),detailPerCount:f!=null&&f.detailPerCount?{...f.detailPerCount}:void 0,arahHadap:(P=f==null?void 0:f.arahHadap)!=null?P:"depan",posisiTangan:f==null?void 0:f.posisiTangan,catatan:f==null?void 0:f.catatan}})}function Ma(a,t="flag",n=2){var h;const e=Math.max(1,Math.round(n||2)),o=a.tandaBirama?q(a.tandaBirama):J(a.beats||4),p=Math.max(1,o.kelompok.length||o.pembilang||4),s=((h=a.tempoMap)!=null?h:[]).reduce((r,k)=>Math.max(r,(k.measure||1)+7),0),d=Math.max(e,a.panjangBirama||s||16),i=[];let l=1,u=1;for(;l<=d;){const r=Math.min(d,l+e-1),x=(r-l+1)*p;i.push({id:w("bcs_"),urutan:i.length,labelBagian:`Frasa ${u} (Bar ${l}–${r})`,counts:x,biramaDari:l,biramaSampai:r,alat:t,teknik:"",arahHadap:"depan"}),l=r+1,u+=1}return i}function Ta(a,t,n){var s,d;if(!a)return!1;if((n!=null?n:[]).some(i=>{var l;return((l=i.memberIds)!=null?l:[]).includes(a.id)}))return!0;const e=((s=a.section)!=null?s:"").toLowerCase();if(e==="guard"||e.includes("guard")||e.includes("flag")||e.includes("bendera"))return!0;const o=(t!=null?t:[]).find(i=>i.id===a.section),p=((d=o==null?void 0:o.label)!=null?d:"").toLowerCase();return p.includes("guard")||p.includes("bendera")||p.includes("visual")}function la(a,t,n){return(a!=null?a:[]).filter(o=>n!=null&&n.drillId&&o.drillId&&o.drillId!==n.drillId||n!=null&&n.drillId&&!o.drillId||n!=null&&n.songId&&o.songId&&o.songId!==n.songId||n!=null&&n.songId&&!o.songId?!1:t?o.memberIds&&o.memberIds.length>0?o.memberIds.includes(t.id):o.seksi===t.section:!0).sort((o,p)=>o.judul.localeCompare(p.judul))}function Pa(a,t){var u,h;if(!a||!((u=a.blok)!=null&&u.length))return null;const n=I(a.blok);if(t.mode==="set"){const r=Math.max(1,Math.round(t.countsSet||8)),k=Math.max(0,Math.min(.999999,Number.isFinite(t.progresSet)?t.progresSet:0)),x=Math.min(r,Math.floor(k*r)+1);for(let c=0;c<n.length;c+=1){const $=n[c];if($.setId!==t.setIdAktif)continue;const A=Math.max(0,(h=$.offsetDalamSet)!=null?h:0);if(x>A&&x<=A+$.counts){const b=x-A;return j(c,$,b)}}return null}if(t.sedangHitungMundur||t.biramaAktif<1)return null;const e=Math.max(1,Math.round(t.ketukPerBirama||4)),o=Math.max(.25,t.beatsPerCount||1),p=Math.max(1,Math.min(e,Math.round(t.ketukDalamBirama||1))),s=n.map((r,k)=>({bl:r,idx:k})).filter(({bl:r})=>{var k;return typeof r.biramaDari=="number"&&t.biramaAktif>=r.biramaDari&&t.biramaAktif<=((k=r.biramaSampai)!=null?k:r.biramaDari)});if(s.length>0){const r=s[0].bl.biramaDari,k=(t.biramaAktif-r)*e+(p-1),x=Math.floor(k/o)+1;let c=0;for(const{bl:A,idx:b}of s){if(x>c&&x<=c+A.counts)return j(b,A,x-c);c+=A.counts}const $=s[s.length-1];return j($.idx,$.bl,Math.max(1,Math.min($.bl.counts,x-(c-$.bl.counts))))}const d=(t.biramaAktif-1)*e+(p-1),i=Math.floor(d/o)+1;let l=0;for(let r=0;r<n.length;r+=1){const k=n[r];if(i>l&&i<=l+k.counts)return j(r,k,i-l);l+=k.counts}return null}function j(a,t,n){var d,i,l,u;const e=Math.max(1,Math.min(t.counts,Math.round(n))),o=((d=t.aksenCount)!=null?d:[]).includes(e),p=((i=t.tangkapCount)!=null?i:[]).includes(e),s=((u=(l=t.detailPerCount)==null?void 0:l[e])==null?void 0:u.trim())||void 0;return{blokIndex:a,blok:t,countAktif:e,adalahAksen:o,adalahTangkap:p,teksDetail:s}}function _a(a,t,n){var p,s,d,i,l;const e=la(a,n),o=[];for(const u of e){const h=I(u.blok).filter(r=>r.setId===t);for(const r of h){const k=(p=O[r.alat])!=null?p:r.alat,x=typeof r.offsetDalamSet=="number"&&(r.offsetDalamSet>0||h.length>1)?` [${r.offsetDalamSet+1}–${r.offsetDalamSet+r.counts}]`:"",c=(s=r.aksenCount)!=null&&s.length?` · ▲${r.aksenCount.join(",")}`:"",$=(d=r.tangkapCount)!=null&&d.length?` · ★Catch ${r.tangkapCount.join(",")}`:"",A=(i=r.posisiTangan)!=null&&i.trim()?` (${r.posisiTangan.trim()})`:"",b=((l=r.teknik)==null?void 0:l.trim())||"Kerja alat";o.push(`${k}${x}: ${b}${c}${$}${A}`)}}return o}function Ia(a,t){let n=!1;const e=a.blok.map(o=>{if(o.setId!==t)return o;n=!0;const{setId:p,offsetDalamSet:s,...d}=o;return d});return n?{...a,blok:e,updatedAt:Date.now()}:a}function wa(a,t,n,e){var d,i,l;const o=Math.max(1,n.counts);let p=!1;const s=[];for(const u of I(a.blok)){if(u.setId!==t){s.push(u);continue}p=!0;const h=Math.max(0,(d=u.offsetDalamSet)!=null?d:0),r=h+u.counts;if(r<=o)s.push({...u,setId:n.id,offsetDalamSet:h});else if(h>=o)s.push({...u,setId:e.id,offsetDalamSet:h-o});else{const k=o-h,x=r-o;s.push({...u,setId:n.id,offsetDalamSet:h,counts:k,labelBagian:`${n.name} (${h+1}–${o})`,aksenCount:D(u.aksenCount,k),tangkapCount:D(u.tangkapCount,k)}),s.push({...u,id:w("bcs_"),setId:e.id,offsetDalamSet:0,counts:x,labelBagian:`${e.name} (1–${x})`,aksenCount:D(((i=u.aksenCount)!=null?i:[]).filter(c=>c>k).map(c=>c-k),x),tangkapCount:D(((l=u.tangkapCount)!=null?l:[]).filter(c=>c>k).map(c=>c-k),x)})}}return p?{...a,blok:I(s),updatedAt:Date.now()}:a}function ja(a,t,n,e){const o=Date.now();return(a!=null?a:[]).map(p=>{var s;return{...p,id:w("cs_"),drillId:t,memberIds:(s=p.memberIds)!=null&&s.length?Array.from(new Set(p.memberIds.map(d=>d))):void 0,blok:I(p.blok).map(d=>{var i;return{...d,id:w("bcs_"),setId:d.setId?(i=n[d.setId])!=null?i:d.setId:void 0}}),createdAt:o,updatedAt:o}})}const ua=`
  @page { size: A4 portrait; margin: 10mm; }
  * { box-sizing: border-box; }
  body { background: #ffffff; color: #0f172a; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .halaman-guard { padding: 4mm 2mm; page-break-after: always; }
  .halaman-guard:last-child { page-break-after: auto; }
  .kepala-guard { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; border-bottom: 2px solid #0f172a; padding-bottom: 6px; margin-bottom: 8px; }
  .judul-guard { font-size: 16px; font-weight: 800; color: #0f172a; margin: 0; }
  .sub-guard { font-size: 11px; color: #475569; margin: 2px 0 0; }
  .kotak-pemain { text-align: right; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; }
  .kode-pemain { font-size: 15px; font-weight: 800; color: #0f172a; }
  .nama-pemain { font-size: 10px; color: #334155; }
  .catatan-umum { background: #fffbeb; border: 1px solid #f59e0b; color: #78350f; border-radius: 6px; padding: 5px 8px; font-size: 10.5px; margin-bottom: 8px; }
  table.tabel-cs { width: 100%; border-collapse: collapse; font-size: 10.5px; }
  table.tabel-cs th { background: #f1f5f9; color: #1e293b; border: 1px solid #94a3b8; padding: 5px 6px; text-align: left; font-weight: 700; }
  table.tabel-cs td { border: 1px solid #cbd5e1; padding: 5px 6px; vertical-align: top; color: #0f172a; }
  table.tabel-cs tr:nth-child(even) td { background: #f8fafc; }
  .pil-alat { display: inline-block; padding: 1px 6px; border-radius: 999px; font-size: 9.5px; font-weight: 700; border: 1px solid #64748b; }
  .baris-count { display: flex; flex-wrap: wrap; gap: 3px; margin-top: 4px; }
  .kotak-c { display: inline-flex; align-items: center; justify-content: center; min-width: 17px; height: 17px; padding: 0 3px; border-radius: 3px; border: 1px solid #cbd5e1; background: #ffffff; color: #475569; font-size: 9px; font-weight: 700; }
  .kotak-c.aksen { background: #fef3c7; border-color: #d97706; color: #92400e; }
  .kotak-c.tangkap { background: #d1fae5; border-color: #059669; color: #065f46; }
  .kotak-c.keduanya { background: #fde68a; border-color: #059669; color: #065f46; }
  .meta-kecil { font-size: 9.5px; color: #475569; margin-top: 2px; }
  .detail-c { font-size: 9.5px; color: #334155; margin-top: 3px; }
  .legenda-guard { margin-top: 7px; font-size: 9.5px; color: #475569; display: flex; justify-content: space-between; gap: 8px; }
  /* Buku Saku A5 / Lipat 2 Kartu per Halaman A4 */
  .grid-saku { display: grid; grid-template-columns: 1fr 1fr; gap: 6mm; }
  .kartu-saku-guard { border: 1.5px dashed #64748b; border-radius: 6px; padding: 4mm; background: #ffffff; break-inside: avoid; page-break-inside: avoid; }
  .kepala-saku { display: flex; justify-content: space-between; align-items: baseline; border-bottom: 1.5px solid #0f172a; padding-bottom: 3px; margin-bottom: 5px; }
  .judul-saku { font-size: 11.5px; font-weight: 800; color: #0f172a; }
  .sub-saku { font-size: 9px; color: #475569; }
  .item-saku { border-bottom: 1px solid #e2e8f0; padding: 3.5px 0; font-size: 9.2px; }
  .item-saku:last-child { border-bottom: none; }
  .baris-atas-saku { display: flex; justify-content: space-between; align-items: center; gap: 4px; font-weight: 700; color: #0f172a; }
  .koord-saku { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 8.8px; color: #1e40af; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 3px; padding: 0.5px 4px; }
`;function ca(a){var p,s,d;const t=Math.min(32,Math.max(1,a.counts)),n=[];for(let i=1;i<=t;i+=1){const l=((p=a.aksenCount)!=null?p:[]).includes(i),u=((s=a.tangkapCount)!=null?s:[]).includes(i),h=l&&u?"keduanya":u?"tangkap":l?"aksen":"",r=u?`${i}★`:l?`${i}▲`:`${i}`;n.push(`<span class="kotak-c ${h}">${r}</span>`)}const e=Object.entries((d=a.detailPerCount)!=null?d:{}).map(([i,l])=>({c:Number(i),teks:(l!=null?l:"").trim()})).filter(i=>Number.isFinite(i.c)&&i.c>=1&&i.c<=a.counts&&i.teks).sort((i,l)=>i.c-l.c),o=e.length?`<div class="detail-c">${e.map(i=>`<b>[${i.c}]</b> ${g(i.teks)}`).join(" &middot; ")}</div>`:"";return`<div class="baris-count">${n.join("")}</div>${o}`}function N(a){var e,o;const t=(e=L[a])!=null?e:L.flag,n=(o=O[a])!=null?o:a;return`<span class="pil-alat" style="background:${t.latarCetak};border-color:${t.tepiCetak};color:${t.teksCetak}">${g(n)}</span>`}function W(a,t,n,e){var r,k;if(!a||!n||!e)return null;const o=t.findIndex(x=>x.id===n);if(o<0)return null;const p=t[o],s=(r=p.points)==null?void 0:r[e.id];if(!s)return{koord:"Istirahat / Prop",langkah:"-",koreoSet:""};const d=Z(s.x,s.y,a.field),i=o<t.length-1?t[o+1]:void 0,l=(k=i==null?void 0:i.points)==null?void 0:k[e.id];let u=i?"Diam":"Akhir";if(i&&l){const c=Y(p,i,[e],aa(a.field),a.tempo,a.beatsPerCount,void 0,a.setelanLangkah,void 0,a.setelanJarak).daftar[0],$=ta(l.x-s.x,l.y-s.y);c&&(u=`${Math.round(c.jarakLangkah*10)/10} lk ${$!=null?$:""}`.trim())}const h=na(p,{memberId:e.id,sectionId:e.section,padat:!0});return{koord:d,langkah:u,koreoSet:h.join(" · ")}}function Ha(a){var h,r,k,x;const{sheet:t,format:n,drill:e,song:o}=a,p=((h=a.namaTim)==null?void 0:h.trim())||"DrillKit",s=[...(r=a.sets)!=null?r:[]].sort((c,$)=>c.order-$.order),d=new Map(s.map((c,$)=>[c.id,{set:c,nomor:$+1}])),i=I(t.blok),l=a.daftarAnggota&&a.daftarAnggota.length>0?a.daftarAnggota:[null],u=[];for(const c of l){const $=c&&((k=e==null?void 0:e.markers)!=null&&k.length)?sa(e.markers,c.id):[],A=!!e&&!!c;if(n==="a4"){const b=i.map(m=>{var M,T,P,v,_;const C=m.setId?d.get(m.setId):void 0,y=m.biramaDari?m.biramaSampai&&m.biramaSampai!==m.biramaDari?`Bar ${m.biramaDari}–${m.biramaSampai}`:`Bar ${m.biramaDari}`:"-",S=c?W(e,s,m.setId,c):null,f=m.arahHadap?da[m.arahHadap]:"",B=[f?`Hadap: ${g(f)}`:"",(M=m.posisiTangan)!=null&&M.trim()?`Tangan: <b>${g(m.posisiTangan.trim())}</b>`:"",(T=m.catatan)!=null&&T.trim()?`Catatan: ${g(m.catatan.trim())}`:""].filter(Boolean).join(" &middot; ");return`<tr>
            <td>
              <b>${g(m.labelBagian)}</b>
              ${C?`<div class="meta-kecil">${g(C.set.name||`Set ${C.nomor}`)}</div>`:""}
            </td>
            <td style="white-space:nowrap">
              <b>${m.counts} cnt</b>
              <div class="meta-kecil">${g(y)}</div>
            </td>
            ${A?`<td>
                    <div style="font-family:ui-monospace,monospace;font-weight:700">${g((P=S==null?void 0:S.koord)!=null?P:"-")}</div>
                    <div class="meta-kecil">${g((v=S==null?void 0:S.langkah)!=null?v:"")}${S!=null&&S.koreoSet?` &middot; ${g(S.koreoSet)}`:""}</div>
                  </td>`:""}
            <td>${N(m.alat)}</td>
            <td>
              <div><b>${g(((_=m.teknik)==null?void 0:_.trim())||"—")}</b></div>
              ${ca(m)}
              ${B?`<div class="meta-kecil">${B}</div>`:""}
            </td>
          </tr>`}).join("");u.push(`<div class="halaman-guard">
        <div class="kepala-guard">
          <div>
            <h1 class="judul-guard">${g(t.judul)}</h1>
            <p class="sub-guard">
              ${g(p)}
              ${e?` &middot; Formasi: <b>${g(e.name)}</b> (${e.tempo} BPM)`:""}
              ${o?` &middot; Lagu: <b>${g(o.title)}</b>`:""}
              &middot; Alat Utama: <b>${g(ra[t.alatUtama])}</b>
            </p>
          </div>
          ${c?`<div class="kotak-pemain">
                  <div class="kode-pemain">${g(c.code)}</div>
                  <div class="nama-pemain">${g(z(c))}</div>
                </div>`:`<div class="kotak-pemain">
                  <div class="kode-pemain">COUNT SHEET</div>
                  <div class="nama-pemain">Seksi ${g(t.seksi.toUpperCase())}</div>
                </div>`}
        </div>
        ${(x=t.catatanUmum)!=null&&x.trim()?`<div class="catatan-umum"><b>Catatan Persiapan Alat:</b> ${g(t.catatanUmum.trim())}</div>`:""}
        ${$.length?`<div class="catatan-umum"><b>Tugas Kru Properti:</b> ${g($.map(m=>m.label).join(", "))}</div>`:""}
        <table class="tabel-cs">
          <thead>
            <tr>
              <th style="width:16%">Bagian / Set</th>
              <th style="width:11%">Count &amp; Bar</th>
              ${A?'<th style="width:20%">Koordinat Titik</th>':""}
              <th style="width:11%">Alat</th>
              <th>Teknik Kerja, Hitungan (▲ Aksen / ★ Catch), &amp; Tangan</th>
            </tr>
          </thead>
          <tbody>${b||`<tr><td colspan="${A?5:4}">Belum ada blok hitungan.</td></tr>`}</tbody>
        </table>
        <div class="legenda-guard">
          <span>Legenda Hitungan: <b>▲</b> = Aksen / Release &nbsp;&middot;&nbsp; <b>★</b> = Catch (Tangkapan)</span>
          <span>Dicetak luring dari DrillKit</span>
        </div>
      </div>`)}else{const m=[];for(let C=0;C<i.length;C+=6)m.push(i.slice(C,C+6));m.length===0&&m.push([]);for(let C=0;C<m.length;C+=2){const S=m.slice(C,C+2).map((f,B)=>{const M=C+B+1,T=m.length,P=f.map(v=>{var U,G,K,F;const _=c?W(e,s,v.setId,c):null,H=v.biramaDari?v.biramaSampai&&v.biramaSampai!==v.biramaDari?`B.${v.biramaDari}–${v.biramaSampai}`:`B.${v.biramaDari}`:"",Q=(U=v.aksenCount)!=null&&U.length?`▲${v.aksenCount.join(",")}`:"",X=(G=v.tangkapCount)!=null&&G.length?`★Catch ${v.tangkapCount.join(",")}`:"",R=[Q,X,(K=v.posisiTangan)==null?void 0:K.trim()].filter(Boolean).join(" · ");return`<div class="item-saku">
                  <div class="baris-atas-saku">
                    <span>${g(v.labelBagian)} (${v.counts}c${H?` · ${g(H)}`:""})</span>
                    ${N(v.alat)}
                  </div>
                  ${_?`<div style="margin-top:2px"><span class="koord-saku">${g(_.koord)}</span> <span class="sub-saku">${g(_.langkah)}</span></div>`:""}
                  <div style="margin-top:2px;color:#0f172a"><b>${g(((F=v.teknik)==null?void 0:F.trim())||"—")}</b></div>
                  ${R?`<div class="meta-kecil">${g(R)}</div>`:""}
                </div>`}).join("");return`<div class="kartu-saku-guard">
              <div class="kepala-saku">
                <div>
                  <div class="judul-saku">${c?`${g(c.code)} · ${g(z(c))}`:g(t.judul)}</div>
                  <div class="sub-saku">${g(t.judul)}${e?` · ${g(e.name)}`:""}</div>
                </div>
                <div class="sub-saku">Kartu ${M}/${T}</div>
              </div>
              ${P||'<div class="sub-saku">Belum ada blok hitungan.</div>'}
            </div>`}).join("");u.push(`<div class="halaman-guard">
          <div class="sub-guard" style="margin-bottom:6px">
            ✂ Buku Saku Visual Color Guard — gunting mengikuti garis putus-putus (${g(p)})
          </div>
          <div class="grid-saku">${S}</div>
        </div>`)}}}return ea(`${t.judul} — Count Sheet Color Guard`,u.join(`
`),ua)}export{Sa as D,O as L,Aa as T,L as W,$a as a,Ia as b,ja as c,la as d,Ca as e,da as f,Ha as g,Pa as h,Ta as i,ra as j,va as k,ya as l,Da as m,Ba as n,Ma as o,xa as p,_a as r,wa as s,sa as t,I as u};
