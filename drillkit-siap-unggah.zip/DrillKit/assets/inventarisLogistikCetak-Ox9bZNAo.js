import{bJ as v,bM as u,bN as f,bV as x,bb as A,bS as S,bT as y,bW as T,ba as I}from"./index-BK1rijHg.js";import{e as a,a as b}from"./print-DIYZna4t.js";const h=`
  @page { size: A4 portrait; margin: 12mm; }
  body { padding: 0; margin: 0; font-family: system-ui, -apple-system, Segoe UI, sans-serif; color: #0f172a; background: #ffffff; font-size: 11px; }
  .halaman { page-break-after: always; padding: 4px 0; }
  .halaman:last-child { page-break-after: auto; }
  .kop { border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-end; gap: 12px; }
  .kop h1 { margin: 0; font-size: 16px; color: #0f172a; letter-spacing: -0.01em; }
  .kop .sub { margin: 3px 0 0; font-size: 11px; color: #475569; }
  .kop .kanan { text-align: right; font-size: 10px; color: #475569; }
  .kotak-info { background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 10px; margin-bottom: 10px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 16px; }
  table { width: 100%; border-collapse: collapse; margin-top: 6px; }
  th, td { border: 1px solid #cbd5e1; padding: 5px 6px; text-align: left; vertical-align: top; }
  th { background: #f1f5f9; color: #1e293b; font-size: 9.5px; text-transform: uppercase; letter-spacing: 0.04em; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 10px; }
  .angka { text-align: center; font-variant-numeric: tabular-nums; }
  .lencana { display: inline-block; padding: 1px 6px; border-radius: 999px; font-size: 9.5px; font-weight: 600; border: 1px solid #cbd5e1; }
  .klausul { margin-top: 12px; font-size: 10.5px; line-height: 1.5; color: #334155; }
  .klausul ol { margin: 4px 0 0 18px; padding: 0; }
  .ttd-grid { margin-top: 22px; display: grid; grid-template-columns: 1fr 1fr; gap: 24px; text-align: center; page-break-inside: avoid; }
  .ttd-kotak { padding-top: 4px; }
  .ttd-garis { margin: 48px auto 4px; width: 78%; border-bottom: 1px solid #0f172a; font-weight: 600; padding-bottom: 2px; }
  .merah-baris td { background: #fef2f2; color: #7f1d1d; }
  .peringatan-merah { margin-top: 10px; border: 1.5px solid #ef4444; background: #fef2f2; color: #991b1b; padding: 8px 10px; border-radius: 6px; font-size: 10.5px; }
  .aman-hijau { margin-top: 10px; border: 1px solid #6ee7b7; background: #ecfdf5; color: #065f46; padding: 8px 10px; border-radius: 6px; font-size: 10.5px; }
`;function $(n){const l=T[n];return`<span class="lencana" style="background:${l.latar};border-color:${l.garis};color:${l.teks};">${a(I[n])}</span>`}function N(n){const l=n.tanggalCetak||new Date().toISOString().slice(0,10),m=new Map(n.members.map(e=>[e.id,e])),i=n.anggotaTarget?[n.anggotaTarget]:Array.from(new Set(n.inventaris.map(e=>e.pemegangId).filter(e=>!!(e&&m.has(e))))).map(e=>m.get(e)).sort((e,o)=>e.code.localeCompare(o.code));if(i.length===0){const e=`
      <div class="halaman">
        <div class="kop">
          <div>
            <h1>BERITA ACARA PEMINJAMAN ALAT &amp; PERLENGKAPAN</h1>
            <p class="sub">${a(n.namaTim)}</p>
          </div>
          <div class="kanan">Tanggal: ${a(l)}</div>
        </div>
        <p>Belum ada instrumen atau perlengkapan yang sedang tercatat dipinjam anggota.</p>
      </div>
    `;return b(`Berita Acara Peminjaman - ${n.namaTim}`,e,h)}const c=i.map(e=>{const o=n.inventaris.filter(d=>d.pemegangId===e.id).sort((d,p)=>d.kodeAset.localeCompare(p.kodeAset)),r=n.labelSeksi?n.labelSeksi(e.section):e.section,t=e.ukuranSeragam,g=o.map((d,p)=>`
          <tr>
            <td class="angka">${p+1}</td>
            <td class="mono"><b>${a(d.kodeAset)}</b>${d.nomorSeri?`<br><span style="color:#475569;">SN: ${a(d.nomorSeri)}</span>`:""}</td>
            <td><b>${a(d.nama)}</b>${d.merekTipe?`<br><span style="color:#475569;">${a(d.merekTipe)}</span>`:""}</td>
            <td>${$(d.kondisi)}</td>
            <td>${a(d.kelengkapanPinjam||"Standar unit")}</td>
            <td class="mono">${a(d.tanggalPinjam||l)}${d.targetKembali?`<br>s.d. ${a(d.targetKembali)}`:""}</td>
          </tr>`).join(""),s=t!=null&&t.nomorSeriSeragam||(t==null?void 0:t.statusPinjam)==="dipinjam"?`
          <tr>
            <td class="angka">${o.length+1}</td>
            <td class="mono"><b>${a(t.nomorSeriSeragam||"SERAGAM")}</b>${t.nomorShako?`<br><span style="color:#475569;">Shako: ${a(t.nomorShako)}</span>`:""}</td>
            <td><b>Stel Seragam Penampilan Unit</b><br><span style="color:#475569;">Jaket ${a(t.jaketTunic||"-")} · Bibber ${a(t.bibber||"-")} · Sepatu ${a(t.sepatu||"-")}</span></td>
            <td><span class="lencana" style="background:#ecfdf5;border-color:#6ee7b7;color:#065f46;">Lengkap</span></td>
            <td>Garment bag, shako, sarung tangan</td>
            <td class="mono">${a(t.tanggalAmbil||l)}</td>
          </tr>`:"";return`
        <div class="halaman">
          <div class="kop">
            <div>
              <h1>BERITA ACARA PEMINJAMAN INVENTARIS UNIT</h1>
              <p class="sub">${a(n.namaTim)}${n.kota?` · ${a(n.kota)}`:""}</p>
            </div>
            <div class="kanan">
              <div>Dokumen Inventaris Resmi</div>
              <div>Tanggal: <b>${a(l)}</b></div>
            </div>
          </div>

          <div class="kotak-info">
            <div class="grid-2">
              <div><b>Nama Peminjam (Pihak Kedua):</b> ${a(e.name)} (${a(e.code)})</div>
              <div><b>Seksi / Instrumen:</b> ${a(r)} · ${a(e.instrument||"-")}</div>
              <div><b>Pengurus / Pelatih (Pihak Pertama):</b> ${a(n.namaPelatih||"Pengurus Inventaris Unit")}</div>
              <div><b>Tahun Angkatan:</b> ${a(String(e.joinYear||"-"))}</div>
            </div>
          </div>

          <p style="margin:0 0 6px;">Pada tanggal tersebut di atas, Pihak Pertama menyerahkan hak pakai sementara atas inventaris milik <b>${a(n.namaTim)}</b> kepada Pihak Kedua dengan rincian sebagai berikut:</p>

          <table>
            <thead>
              <tr>
                <th style="width:28px;" class="angka">No</th>
                <th style="width:115px;">Kode Aset / Seri</th>
                <th>Nama Instrumen / Perlengkapan</th>
                <th style="width:88px;">Kondisi Awal</th>
                <th style="width:140px;">Kelengkapan</th>
                <th style="width:92px;">Masa Pinjam</th>
              </tr>
            </thead>
            <tbody>
              ${g}${s}
              ${!g&&!s?'<tr><td colspan="6">Belum ada item pinjaman tercatat pada anggota ini.</td></tr>':""}
            </tbody>
          </table>

          <div class="klausul">
            <b>Ketentuan Tanggung Jawab Peminjam:</b>
            <ol>
              <li>Pihak Kedua wajib merawat kebersihan dan keamanan alat beserta kelengkapannya setiap selesai latihan maupun penampilan.</li>
              <li>Alat dilarang dipindahtangankan kepada pihak lain tanpa sepengetahuan Pengurus Inventaris / Pelatih.</li>
              <li>Apabila terjadi kerusakan atau gejala kendala teknis, Pihak Kedua wajib segera melapor agar dicatat di Buku Perawatan (dilarang membongkar paksa).</li>
              <li>Seluruh alat dan seragam wajib dikembalikan ke gudang unit sesuai jadwal pengembalian atau saat masa kepengurusan/keanggotaan berakhir.</li>
            </ol>
          </div>

          <div class="ttd-grid">
            <div class="ttd-kotak">
              <div>Yang Menyerahkan (Pihak Pertama),</div>
              <div style="color:#475569;font-size:10px;">Pengurus Inventaris / Pelatih</div>
              <div class="ttd-garis">${a(n.namaPelatih||"........................................")}</div>
            </div>
            <div class="ttd-kotak">
              <div>Yang Menerima (Pihak Kedua),</div>
              <div style="color:#475569;font-size:10px;">Anggota Peminjam (${a(e.code)})</div>
              <div class="ttd-garis">${a(e.name)}</div>
            </div>
          </div>
        </div>
      `}).join("");return b(`Berita Acara Peminjaman - ${n.namaTim}`,c,h)}function K(n){const l=n.tanggalCetak||new Date().toISOString().slice(0,10),m=new Map(n.members.map(r=>[r.id,r])),i=v(n.inventaris),e=[...n.inventaris].sort((r,t)=>r.kategori.localeCompare(t.kategori)||r.kodeAset.localeCompare(t.kodeAset)).map((r,t)=>{var d;const g=r.pemegangId?m.get(r.pemegangId):void 0,s=[...(d=r.riwayatServis)!=null?d:[]].sort((p,k)=>k.tanggal.localeCompare(p.tanggal))[0];return`
        <tr class="${r.kondisi==="rusak"?"merah-baris":""}">
          <td class="angka">${t+1}</td>
          <td class="mono"><b>${a(r.kodeAset)}</b>${r.nomorSeri?`<br><span style="color:#475569;">${a(r.nomorSeri)}</span>`:""}</td>
          <td><b>${a(r.nama)}</b>${r.merekTipe?`<br><span style="color:#475569;">${a(r.merekTipe)}</span>`:""}</td>
          <td>${a(u[r.kategori])}</td>
          <td>${$(r.kondisi)}</td>
          <td>${g?`<b>${a(g.code)}</b> · ${a(g.name)}`:`<span style="color:#475569;">Gudang${r.lokasiSimpan?` (${a(r.lokasiSimpan)})`:""}</span>`}</td>
          <td>${s?`${a(s.tanggal)}: ${a(s.jenis)}`:'<span style="color:#64748b;">—</span>'}</td>
        </tr>`}).join(""),o=`
    <div class="halaman">
      <div class="kop">
        <div>
          <h1>BUKU INDUK INVENTARIS INSTRUMEN &amp; PERLENGKAPAN</h1>
          <p class="sub">${a(n.namaTim)} · Total ${i.total} aset (${i.siapPakai} siap pakai, ${i.perluServis} perlu servis, ${i.rusak} rusak)</p>
        </div>
        <div class="kanan">Dicetak: ${a(l)}</div>
      </div>
      <table>
        <thead>
          <tr>
            <th style="width:26px;" class="angka">No</th>
            <th style="width:105px;">Kode / No. Seri</th>
            <th>Nama &amp; Merek/Tipe</th>
            <th style="width:74px;">Kategori</th>
            <th style="width:86px;">Kondisi</th>
            <th style="width:135px;">Pemegang / Lokasi</th>
            <th style="width:140px;">Perawatan Terakhir</th>
          </tr>
        </thead>
        <tbody>
          ${e||'<tr><td colspan="7">Belum ada data inventaris tercatat.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;return b(`Buku Induk Inventaris - ${n.namaTim}`,o,h)}function j(n){const l=n.tanggalCetak||new Date().toISOString().slice(0,10),m=[...n.members].filter(o=>o.active===1).sort((o,r)=>o.section.localeCompare(r.section)||o.code.localeCompare(r.code)),i=f(m),c=m.map((o,r)=>{var p;const t=o.ukuranSeragam,g=(p=t==null?void 0:t.statusPinjam)!=null?p:"belum",s=x[g],d=n.labelSeksi?n.labelSeksi(o.section):o.section;return`
        <tr>
          <td class="angka">${r+1}</td>
          <td><b>${a(o.code)}</b> · ${a(o.name)}<br><span style="color:#475569;">${a(d)} (${a(o.instrument||"-")})</span></td>
          <td class="angka">${a((t==null?void 0:t.sepatu)||"—")}</td>
          <td class="angka">${a((t==null?void 0:t.jaketTunic)||"—")}${t!=null&&t.lingkarDadaCm?`<br><span style="color:#64748b;">${t.lingkarDadaCm}cm</span>`:""}</td>
          <td class="angka">${a((t==null?void 0:t.bibber)||"—")}${t!=null&&t.panjangCelanaCm?`<br><span style="color:#64748b;">${t.panjangCelanaCm}cm</span>`:""}</td>
          <td class="angka">${a((t==null?void 0:t.shakoTopi)||"—")}</td>
          <td class="angka">${a((t==null?void 0:t.sarungTangan)||"—")}${t!=null&&t.kostumGuard?`<br><span style="color:#475569;">CG: ${a(t.kostumGuard)}</span>`:""}</td>
          <td class="mono">${a((t==null?void 0:t.nomorSeriSeragam)||"—")}${t!=null&&t.nomorShako?`<br>Shk: ${a(t.nomorShako)}`:""}</td>
          <td><span class="lencana" style="background:${s.latar};border-color:${s.garis};color:${s.teks};">${a(A[g])}</span></td>
        </tr>`}).join(""),e=`
    <div class="halaman">
      <div class="kop">
        <div>
          <h1>DAFTAR UKURAN FITTING &amp; DISTRIBUSI SERAGAM</h1>
          <p class="sub">${a(n.namaTim)} · ${i.sudahFitting}/${i.totalAnggotaAktif} sudah fitting · ${i.sedangDipinjam} sedang dipinjam · ${i.sudahDicuci} kembali &amp; dicuci</p>
        </div>
        <div class="kanan">Dicetak: ${a(l)}</div>
      </div>
      <table>
        <thead>
          <tr>
            <th style="width:24px;" class="angka">No</th>
            <th>Anggota &amp; Seksi</th>
            <th style="width:42px;" class="angka">Sepatu</th>
            <th style="width:52px;" class="angka">Jaket</th>
            <th style="width:52px;" class="angka">Bibber</th>
            <th style="width:48px;" class="angka">Shako</th>
            <th style="width:58px;" class="angka">Glove/CG</th>
            <th style="width:82px;">No. Seri</th>
            <th style="width:118px;">Status Kembali/Cuci</th>
          </tr>
        </thead>
        <tbody>
          ${c||'<tr><td colspan="9">Belum ada anggota aktif.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;return b(`Distribusi Seragam - ${n.namaTim}`,e,h)}function M(n){var g;const{manifes:l}=n,m=new Map(n.members.map(s=>[s.id,s])),i=S(l),c=i.sudahKembaliGudang>0,e=s=>s===1?"☑":"☐",o=((g=l.butir)!=null?g:[]).map((s,d)=>{const p=y(s,l.tahapAktif,c),k=s.penanggungJawabId?m.get(s.penanggungJawabId):void 0;return`
        <tr class="${p==="belum_kembali_merah"?"merah-baris":""}">
          <td class="angka">${d+1}</td>
          <td>
            <b>${a(s.nama)}</b>${s.kodeAset?` <span class="mono" style="color:#475569;">[${a(s.kodeAset)}]</span>`:""}
            ${p==="belum_kembali_merah"?'<br><b style="color:#b91c1c;">⚠ BELUM KEMBALI KE GUDANG!</b>':""}
            ${s.catatan?`<br><span style="color:#475569;">${a(s.catatan)}</span>`:""}
          </td>
          <td>${a(u[s.kategori])}</td>
          <td class="angka">${s.jumlah} ${a(s.satuan||"unit")}</td>
          <td>${k?`${a(k.code)} · ${a(k.name)}`:"—"}</td>
          <td class="angka" style="font-size:13px;">${e(s.muatBerangkat)}</td>
          <td class="angka" style="font-size:13px;">${e(s.cekLokasi)}</td>
          <td class="angka" style="font-size:13px;">${e(s.kembaliGudang)}</td>
        </tr>`}).join(""),r=i.belumKembaliMerah.length>0?`<div class="peringatan-merah"><b>PERHATIAN — ${i.belumKembaliMerah.length} BARANG BELUM MASUK KEMBALI KE GUDANG:</b><br>${i.belumKembaliMerah.map(s=>a(s.nama)).join(", ")}</div>`:i.totalButir>0&&i.sudahKembaliGudang===i.totalButir?'<div class="aman-hijau"><b>LENGKAP 100%:</b> Seluruh perlengkapan telah kembali ke gudang markas.</div>':"",t=`
    <div class="halaman">
      <div class="kop">
        <div>
          <h1>MANIFES LOGISTIK &amp; LOADING TRUK HARI LOMBA (3-TAHAP)</h1>
          <p class="sub">${a(n.namaTim)} · <b>${a(l.judul)}</b> · Tanggal ${a(l.tanggal)}</p>
        </div>
        <div class="kanan">
          <div>Armada: <b>${a(l.kendaraan||"—")}</b></div>
          <div>Koordinator: <b>${a(l.koordinator||"—")}</b></div>
        </div>
      </div>

      <div class="kotak-info">
        <div class="grid-2">
          <div><b>Total Muatan:</b> ${i.totalButir} jenis barang (${i.totalUnit} unit/koli)</div>
          <div><b>1. Muat Berangkat:</b> ${i.sudahBerangkat}/${i.totalButir} (${i.persenBerangkat}%)</div>
          <div><b>2. Cek di Lokasi Lomba:</b> ${i.sudahCekLokasi}/${i.totalButir} (${i.persenLokasi}%)</div>
          <div><b>3. Masuk Kembali ke Gudang:</b> ${i.sudahKembaliGudang}/${i.totalButir} (${i.persenKembali}%)</div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width:24px;" class="angka">No</th>
            <th>Nama Perlengkapan / Instrumen</th>
            <th style="width:70px;">Kategori</th>
            <th style="width:58px;" class="angka">Jumlah</th>
            <th style="width:110px;">PJ / Pemegang</th>
            <th style="width:58px;" class="angka">1. Muat<br>Markas</th>
            <th style="width:58px;" class="angka">2. Cek<br>Lokasi</th>
            <th style="width:58px;" class="angka">3. Masuk<br>Gudang</th>
          </tr>
        </thead>
        <tbody>
          ${o||'<tr><td colspan="8">Belum ada daftar barang pada manifes ini.</td></tr>'}
        </tbody>
      </table>

      ${r}
    </div>
  `;return b(`Manifes Logistik - ${l.tanggal}`,t,h)}export{N as a,K as b,j as c,M as d};
