import{W as x,o as f,Y as J,Z as z,a1 as v,z as A,R as I,y as R}from"./index-gQYVFvJp.js";import{p as U,d as _,a as K,e as r}from"./print-DRye-mwp.js";const b=["hadir","izin","sakit","alpha"],D={hadir:"Hadir",izin:"Izin",sakit:"Sakit",alpha:"Tanpa keterangan"},j={hadir:"H",izin:"I",sakit:"S",alpha:"A"},E={hadir:"#10b981",izin:"#38bdf8",sakit:"#f59e0b",alpha:"#f43f5e"},F=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],w={baik:85,cukup:70};function P(t){const e=(l,d)=>{const u=typeof l=="number"?l:Number.NaN;return Number.isFinite(u)?Math.min(100,Math.max(0,Math.round(u))):d},n=e(t==null?void 0:t.baik,w.baik),o=e(t==null?void 0:t.cukup,w.cukup);return n>=o?{baik:n,cukup:o}:{baik:o,cukup:n}}function H(t,e){if(t.terisi===0)return"Belum ada catatan";const n=P(e);return t.rate>=n.baik?"Baik":t.rate>=n.cukup?"Cukup":"Perlu perhatian"}function Y(t){const e=P(t),n=[`Baik ≥ ${e.baik}%`];return e.cukup<e.baik&&n.push(e.baik-1===e.cukup?`Cukup ${e.cukup}%`:`Cukup ${e.cukup}–${e.baik-1}%`),e.cukup>0&&n.push(`Perlu perhatian < ${e.cukup}%`),n.join(" · ")}function y(t){const e=new Map(t.sesi.map(l=>[l.id,l.title])),n=new Map(t.sesi.map(l=>[l.id,l.date])),o=new Set(t.sesi.map(l=>l.id));return t.anggota.map(l=>{var k,c,p;const d={hadir:0,izin:0,sakit:0,alpha:0},u=new Map,g=[];for(const a of t.catatan)a.memberId!==l.id||!o.has(a.sessionId)||(d[a.status]++,u.set(a.sessionId,a.status),(k=a.note)!=null&&k.trim()&&g.push({tanggal:(c=n.get(a.sessionId))!=null?c:"",judul:(p=e.get(a.sessionId))!=null?p:"",teks:a.note.trim()}));const m=b.reduce((a,i)=>a+d[i],0);return{member:l,counts:d,terisi:m,rate:x(d.hadir,m),status:u,keterangan:g}})}function G(t,e){const n={hadir:0,izin:0,sakit:0,alpha:0};for(const i of e)for(const s of b)n[s]+=i.counts[s];const o=b.reduce((i,s)=>i+n[s],0),l=x(n.hadir,o),d=new Map;for(const i of e){const s=i.member.section;let h=d.get(s);h||(h={id:s,label:f(s),anggota:0,counts:{hadir:0,izin:0,sakit:0,alpha:0},terisi:0,rate:0},d.set(s,h)),h.anggota++;for(const $ of b)h.counts[$]+=i.counts[$]}const u=[...d.values()].map(i=>(i.terisi=b.reduce((s,h)=>s+i.counts[h],0),i.rate=x(i.counts.hadir,i.terisi),i)).sort((i,s)=>s.rate-i.rate||i.label.localeCompare(s.label)),g=new Map(t.sesi.map(i=>[i.id,i.type])),m=new Map;for(const i of t.catatan){const s=g.get(i.sessionId);if(!s)continue;let h=m.get(s);h||(h={sesi:new Set,h:0,f:0},m.set(s,h)),h.sesi.add(i.sessionId),h.f++,i.status==="hadir"&&h.h++}const k=J.map(i=>{const s=m.get(i);return s?{jenis:i,label:z(i).label,sesi:s.sesi.size,h:s.h,f:s.f,rate:x(s.h,s.f)}:null}).filter(i=>i!==null),c=e.filter(i=>i.terisi>0&&i.rate===100),p=e.filter(i=>i.terisi>0&&i.rate<t.batas).sort((i,s)=>i.rate-s.rate);let a=`Kehadiran ${t.periode}: ${l}% (${n.hadir} dari ${o} catatan) pada ${t.sesi.length} sesi yang diikuti ${t.anggota.length} anggota.`;if(t.banding){const i=l-t.banding.rate,s=i>=3?"naik":i<=-3?"turun":"stabil";a+=` Angka ini ${s} ${Math.abs(i)} poin dibanding ${t.banding.label} (${t.banding.rate}%).`}if(p.length){const i=p.slice(0,3).map(s=>`${s.member.name} ${s.rate}%`).join(", ");a+=` ${p.length} anggota perlu perhatian (di bawah ${t.batas}%): ${i}${p.length>3?", dan lainnya":""}.`}else a+=` Tidak ada anggota di bawah ambang ${t.batas}%.`;return c.length&&(a+=` ${c.length} anggota hadir penuh di semua sesi yang tercatat.`),{sesi:t.sesi.length,anggota:t.anggota.length,counts:n,terisi:o,rate:l,hadirPenuh:c,perhatian:p,perSection:u,perJenis:k,kalimat:a}}function T(){return`
    @page { size: A4 portrait; margin: 14mm; }
    body { font-size: 11px; color:#000; }
    .kop { display:flex; align-items:center; gap:10px; border-bottom:2px solid #111; padding-bottom:8px; margin-bottom:10px; }
    .kop img { height:40px; width:auto; }
    .kop .nama { font-size:14px; font-weight:700; line-height:1.15; }
    .kop .sub { font-size:10px; color:#555; }
    h1.judul { font-size:15px; margin:0 0 2px; }
    .sub { font-size:10.5px; color:#555; margin:0 0 8px; }
    h2 { font-size:12px; margin:12px 0 5px; border-left:3px solid #111; padding-left:5px; }
    .tiles { display:flex; gap:6px; margin:8px 0 10px; }
    .tile { flex:1; border:1px solid #999; padding:5px 7px; }
    .tile span { display:block; font-size:9px; text-transform:uppercase; color:#555; }
    .tile b { font-size:14px; }
    table { width:100%; border-collapse:collapse; margin:4px 0 10px; }
    th, td { border:1px solid #999; padding:3px 5px; text-align:left; vertical-align:top; }
    th { background:#eef2f7; font-size:10px; text-transform:uppercase; }
    td.r, th.r { text-align:right; }
    td.c, th.c { text-align:center; }
    .ringkas { border:1px solid #bbb; background:#fafafa; padding:7px 9px; margin:6px 0 10px; line-height:1.45; }
    .ttd { display:flex; gap:20px; margin-top:22px; }
    .ttd > div { flex:1; text-align:center; font-size:10.5px; }
    .ttd .garis { margin-top:46px; border-top:1px solid #333; padding-top:3px; }
    .ttd .nama-orang { font-weight:700; }
    .kartu { border:1px solid #666; padding:8px 10px; margin-bottom:7mm; page-break-inside:avoid; }
    .kartu .kepala { display:flex; justify-content:space-between; align-items:baseline; border-bottom:1px solid #999; padding-bottom:5px; margin-bottom:6px; }
    .kartu .kepala b { font-size:12px; }
    .identitas { display:flex; flex-wrap:wrap; gap:2px 14px; margin-bottom:6px; }
    .identitas div { font-size:10.5px; }
    .identitas i { color:#666; font-style:normal; }
    .kecil { font-size:9.5px; color:#555; }
    .ambang-predikat { margin:-6px 0 6px; }
    .pagebreak { page-break-before: always; }
  `}function M(t,e,n){return`
    <div class="kop">
      ${t.logo?`<img src="${r(t.logo)}" alt="logo" />`:""}
      <div>
        <div class="nama">${r(t.namaTim||"Marching Band")}</div>
        <div class="sub">${r(e)} · ${r(n)}</div>
      </div>
    </div>`}function S(){const t=new Date;return`${t.getDate()} ${F[t.getMonth()]} ${t.getFullYear()}`}function C(t){return t?`${r(t)}, ${S()}`:S()}function N(t){var c,p;const e=y(t),n=G(t,e),o=(p=(c=t.kota)==null?void 0:c.trim())!=null?p:"",l=[["Kehadiran",`${n.rate}%`],["Sesi",String(n.sesi)],["Anggota",String(n.anggota)],["Hadir",String(n.counts.hadir)],["Izin",String(n.counts.izin)],["Sakit",String(n.counts.sakit)],["Tanpa keterangan",String(n.counts.alpha)]].map(([a,i])=>`<div class="tile"><span>${r(a)}</span><b>${r(i)}</b></div>`).join(""),d=n.perSection.length?`<h2>Rekap per section</h2>
      <table>
        <thead><tr><th>Section</th><th class="r">Anggota</th><th class="r">Hadir</th><th class="r">Izin</th><th class="r">Sakit</th><th class="r">Tanpa keterangan</th><th class="r">% Hadir</th></tr></thead>
        <tbody>
          ${n.perSection.map(a=>`<tr><td>${r(a.label)}</td><td class="r">${a.anggota}</td><td class="r">${a.counts.hadir}</td>
              <td class="r">${a.counts.izin}</td><td class="r">${a.counts.sakit}</td><td class="r">${a.counts.alpha}</td>
              <td class="r">${a.rate}%</td></tr>`).join("")}
        </tbody>
      </table>`:"",u=n.perJenis.length?`<h2>Kehadiran per jenis kegiatan</h2>
      <table>
        <thead><tr><th>Jenis kegiatan</th><th class="r">Sesi</th><th class="r">Hadir</th><th class="r">Terisi</th><th class="r">% Hadir</th></tr></thead>
        <tbody>
          ${n.perJenis.map(a=>`<tr><td>${r(a.label)}</td><td class="r">${a.sesi}</td><td class="r">${a.h}</td><td class="r">${a.f}</td><td class="r">${a.rate}%</td></tr>`).join("")}
        </tbody>
      </table>`:"",g=`<h2>Rincian per sesi</h2>
      <table>
        <thead><tr><th>Tanggal</th><th>Kegiatan</th><th>Jenis</th><th class="r">Hadir</th><th class="r">Izin</th><th class="r">Sakit</th><th class="r">Tanpa keterangan</th><th class="r">% Hadir</th></tr></thead>
        <tbody>
          ${[...t.sesi].sort((a,i)=>a.date.localeCompare(i.date)).map(a=>{const i=t.catatan.filter($=>$.sessionId===a.id),s={hadir:0,izin:0,sakit:0,alpha:0};for(const $ of i)s[$.status]++;const h=b.reduce(($,B)=>$+s[B],0);return`<tr><td>${r(v(a.date))}</td><td>${r(a.title)}</td><td>${r(z(a.type).label)}</td>
                <td class="r">${s.hadir}</td><td class="r">${s.izin}</td><td class="r">${s.sakit}</td><td class="r">${s.alpha}</td>
                <td class="r">${x(s.hadir,h)}%</td></tr>`}).join("")}
        </tbody>
      </table>`,m=`<h2>Rekap per anggota</h2>
      <table>
        <thead><tr><th>Kode</th><th>Nama</th><th>Section</th><th class="r">Hadir</th><th class="r">Izin</th><th class="r">Sakit</th><th class="r">Tanpa keterangan</th><th class="r">Sesi</th><th class="r">% Hadir</th></tr></thead>
        <tbody>
          ${[...e].sort((a,i)=>i.rate-a.rate||a.member.name.localeCompare(i.member.name)).map(a=>`<tr><td>${r(a.member.code)}</td><td>${r(a.member.name)}</td><td>${r(f(a.member.section))}</td>
              <td class="r">${a.counts.hadir}</td><td class="r">${a.counts.izin}</td><td class="r">${a.counts.sakit}</td>
              <td class="r">${a.counts.alpha}</td><td class="r">${a.terisi}</td><td class="r">${a.rate}%</td></tr>`).join("")}
        </tbody>
      </table>`,k=n.perhatian.length?`<h2>Perlu perhatian (di bawah ${t.batas}%)</h2>
      <table>
        <thead><tr><th>Kode</th><th>Nama</th><th>Section</th><th class="r">% Hadir</th><th>Hadir / sesi</th></tr></thead>
        <tbody>
          ${n.perhatian.map(a=>`<tr><td>${r(a.member.code)}</td><td>${r(a.member.name)}</td><td>${r(f(a.member.section))}</td>
              <td class="r">${a.rate}%</td><td>${a.counts.hadir} dari ${a.terisi}</td></tr>`).join("")}
        </tbody>
      </table>`:"";return`
    ${M(t,"Laporan Kehadiran",t.periode)}
    <h1 class="judul">Laporan Kehadiran</h1>
    <p class="sub">Periode ${r(t.periode)} · dicetak ${C(t.kota)}</p>

    <div class="tiles">${l}</div>
    <div class="ringkas">${r(n.kalimat)}</div>
    ${d}
    ${u}
    ${g}
    ${k}
    ${m}

    <div class="ttd">
      <div>Mengetahui,<br/><span class="kecil">Pembina / Ketua Tim</span>
        <div class="garis">( ........................................ )</div>
      </div>
      <div>${r(o?o+", ":"")}${S()}<br/><span class="kecil">Pelatih</span>
        <div class="garis"><span class="nama-orang">${r(t.pelatih||"........................................")}</span></div>
      </div>
    </div>`}function Z(t){return K(`Laporan Kehadiran ${t.periode}`,N(t),T())}function O(t,e){var g,m,k;const n=[...t.sesi].sort((c,p)=>c.date.localeCompare(p.date)),o=(g=I[e.member.role])!=null?g:e.member.role,l=(k=(m=t.kota)==null?void 0:m.trim())!=null?k:"",d=n.length?`<table>
        <thead><tr><th>Tanggal</th><th>Kegiatan</th><th>Jenis</th><th class="c">Status</th><th>Keterangan</th></tr></thead>
        <tbody>
          ${n.map(c=>{var i,s;const p=e.status.get(c.id),a=(i=t.catatan.find(h=>h.sessionId===c.id&&h.memberId===e.member.id))==null?void 0:i.note;return`<tr><td>${r(v(c.date))}</td><td>${r(c.title)}</td><td>${r(z(c.type).singkat)}</td>
                <td class="c" style="color:${p?E[p]:"#999"}">
                  <b>${p?j[p]:"–"}</b>${p?` <span class="kecil">${D[p]}</span>`:""}
                </td>
                <td>${r((s=a==null?void 0:a.trim())!=null?s:"")}</td></tr>`}).join("")}
        </tbody>
      </table>`:'<p class="kecil">Belum ada sesi pada periode ini.</p>',u=H(e,t.predikat);return`
    <div class="kartu">
      <div class="kepala">
        <b>Kartu Kehadiran</b>
        <span class="kecil">${r(t.namaTim||"Marching Band")} · ${r(t.periode)}</span>
      </div>
      <div class="identitas">
        <div><i>Nama</i> &nbsp;<b>${r(e.member.name)}</b></div>
        <div><i>Kode</i> &nbsp;${r(e.member.code)}</div>
        <div><i>Section</i> &nbsp;${r(f(e.member.section))}</div>
        <div><i>Instrumen</i> &nbsp;${r(e.member.instrument||"-")}</div>
        <div><i>Peran</i> &nbsp;${r(o)}</div>
        <div><i>Gabung</i> &nbsp;${e.member.joinYear||"-"}</div>
      </div>
      <table>
        <thead><tr><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Tanpa keterangan</th><th>Sesi tercatat</th><th>% Kehadiran</th><th>Predikat</th></tr></thead>
        <tbody>
          <tr>
            <td>${e.counts.hadir}</td><td>${e.counts.izin}</td><td>${e.counts.sakit}</td><td>${e.counts.alpha}</td>
            <td>${e.terisi}</td><td><b>${e.rate}%</b></td><td>${r(u)}</td>
          </tr>
        </tbody>
      </table>
      <p class="kecil ambang-predikat">Predikat: ${r(Y(t.predikat))}</p>
      ${d}
      ${e.keterangan.length?`<p class="kecil"><b>Catatan pelatih:</b> ${e.keterangan.map(c=>r(`${v(c.tanggal)} — ${c.teks}`)).join("; ")}</p>`:""}
      <div class="ttd">
        <div><span class="kecil">Paraf anggota</span><div class="garis">( ........................ )</div></div>
        <div><span class="kecil">${r(l?l+", ":"")}${S()}<br/>Pelatih</span>
          <div class="garis"><span class="nama-orang">${r(t.pelatih||"........................")}</span></div>
        </div>
      </div>
    </div>`}function L(t,e){const n=y(t).filter(o=>e?o.member.id===e:!0).sort((o,l)=>o.member.name.localeCompare(l.member.name));return n.length?`
    ${M(t,"Kartu Kehadiran Anggota",t.periode)}
    <h1 class="judul">Kartu Kehadiran Anggota</h1>
    <p class="sub">Periode ${r(t.periode)} · ${n.length} kartu · dicetak ${C(t.kota)}</p>
    ${n.map(o=>O(t,o)).join("")}`:"<p>Belum ada anggota pada periode ini.</p>"}function q(t,e){return K(`Kartu Kehadiran ${t.periode}`,L(t,e),T())}function Q(t){const e=`${N(t)}<div class="pagebreak"></div>${L(t)}`;return K(`Paket Laporan ${t.periode}`,e,T())}function X(t){const e=y(t),n=[...t.sesi].sort((d,u)=>d.date.localeCompare(u.date)),l=[["Kode","Nama","Section",...n.map(d=>`${v(d.date)} · ${z(d.type).singkat}`),"Hadir","Izin","Sakit","Tanpa keterangan","Total sesi","% Kehadiran"],...[...e].sort((d,u)=>d.member.name.localeCompare(u.member.name)).map(d=>[d.member.code,d.member.name,f(d.member.section),...n.map(u=>d.status.has(u.id)?j[d.status.get(u.id)]:""),d.counts.hadir,d.counts.izin,d.counts.sakit,d.counts.alpha,d.terisi,`${d.rate}%`])];return A(l)}function tt(t){const e=y(t),n=[["Kode","Nama","Section","Instrumen","Peran","Hadir","Izin","Sakit","Tanpa keterangan","Total sesi","% Kehadiran","Predikat"],...[...e].sort((o,l)=>o.member.name.localeCompare(l.member.name)).map(o=>{var l;return[o.member.code,o.member.name,f(o.member.section),o.member.instrument||"",(l=I[o.member.role])!=null?l:o.member.role,o.counts.hadir,o.counts.izin,o.counts.sakit,o.counts.alpha,o.terisi,`${o.rate}%`,H(o,t.predikat)]})];return A(n)}function at(t,e,n){return`${t}-kehadiran-${e||"semua"}.${n}`}function et(t,e){return U(t)?!0:(_(t,e),!1)}function it(t,e){R(e,t,"text/csv")}export{w as P,y as a,q as b,Q as c,X as d,tt as e,et as f,Z as h,at as n,P as r,G as s,Y as t,it as u};
