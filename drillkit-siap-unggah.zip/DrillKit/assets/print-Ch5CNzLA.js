import{y as o}from"./index-DEjWzY_D.js";function a(e){try{const t=window.open("","_blank","width=900,height=1000");return t?(t.document.write(e),t.document.close(),t.focus(),t.setTimeout(()=>{try{t.print()}catch{}},600),!0):!1}catch{return!1}}function l(e,t){o(t,e,"text/html")}function r(e){return e.replace(/[&<>"']/g,t=>{var n;return(n={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[t])!=null?n:t})}function s(e,t,n=""){return`<!doctype html><html><head><meta charset="utf-8"><title>${r(e)}</title>
    <style>
      @media print { .no-print { display:none !important } }
      body { font-family: system-ui, -apple-system, "Segoe UI", sans-serif; color:#000; margin:0; }
      ${n}
    </style></head><body>${t}</body></html>`}export{s as a,l as d,r as e,a as p};
