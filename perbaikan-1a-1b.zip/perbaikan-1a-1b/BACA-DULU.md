# BACA DULU — paket serah terima 1a + 1b (DrillKit)

Untuk: agen sesi coding baru di repo `Kid10-test/DrillKit`.
Dari: sesi lama (`arena/01a0cd00-drillkit`) yang akses GitHub-nya dicabut
tepat setelah PR #1 di-merge. Dua commit di bawah ini **tidak pernah sampai
ke GitHub** — zip ini dibawa tangan oleh user, maka isinya tidak ada di
`main`. Repo juga privat, jadi jangan cari di tempat lain.

Commit yang harus masuk (berurutan, di atas `df5d7ec` yang sudah ada di `main`
lewat PR #1):

- `4123583` — **1a — Riwayat formasi: undo yang tidak hilang** (riwayat
  formasi: snapshot, undo, pulihkan drill terhapus)
- `52d3418` — **1b — Simpan otomatis ke berkas** (backup otomatis via
  File System Access API, Chromium desktop)

Total 16 berkas, +1.422 / −4 baris. Semua tambahan/modifikasi, tanpa penghapusan.

## Isi paket

| Berkas | Kegunaan |
|---|---|
| `untuk-git.bundle` | Kedua commit asli utuh (pesan + identitas). **Metode utama.** |
| `perubahan-1a-1b.patch` | Diff `df5d7ec..52d3418`. Metode cadangan #2. |
| `berkas/` | 16 berkas di jalur aslinya. Metode cadangan #3. |

## Metode utama: bundle (teruji)

Jalankan di branch sesimu sendiri (`git branch --show-current` harus branch
arena-mu, bukan `main`), dari akar repo:

```bash
# 1. ambil commit dari bundle (ganti <paket> dengan lokasi zip terekstrak)
git fetch <paket>/untuk-git.bundle refs/heads/arena/01a0cd00-drillkit

# 2. ambil kedua commit (urutan penting)
git cherry-pick 4123583 52d3418
```

Alur ini sudah diuji di atas dasar `df5d7ec`: hasilnya identik byte-per-byte
dengan commit asli (diff kosong). Kalau cherry-pick BENTROK, berarti `main`
sudah berubah sejak PR #1 — **jangan paksa** (`--abort`), laporkan ke user,
dan periksa daerah bentrok lewat `perubahan-1a-1b.patch`.

## Verifikasi sebelum push

```bash
PUPPETEER_SKIP_DOWNLOAD=1 npm install     # sesudah cherry-pick (package.json +1 devDep: fake-indexeddb)
npx tsc --noEmit                          # harus 0 error
npm run build                             # harus sukses
bash qa/bangun-logika.sh
node qa/uji-riwayat.mjs                   # 27 lulus, 0 gagal
node qa/uji-simpan-otomatis.mjs           # 23 lulus, 0 gagal
```

Lalu push branch sesimu dan buka PR ke `main`. **User yang merge.**
Setelah merge, Vercel (`drill-kit.vercel.app`, tersambung lewat import Git)
otomatis deploy dalam ±1 menit. Cek pasca-deploy: Pengaturan → muncul kartu
**"Simpan otomatis ke berkas"**; editor Drill → ada panel **Riwayat**.

## Cadangan #2: patch

```bash
git apply --check <paket>/perubahan-1a-1b.patch   # kering tanpa error = aman
git apply <paket>/perubahan-1a-1b.patch
```

## Cadangan #3: salin berkas

Salin isi `berkas/` menimpa akar repo (struktur foldernya sudah benar),
lalu commit. Perhatian: `tsconfig.tsbuildinfo` ikut berubah — wajar, memang
terlacak di repo ini.

## Uji peramban (opsional — jaringan sandbox memblokir unduhan Chrome)

`npx puppeteer browsers install chrome` dan `apt-get install chromium` GAGAL
di sandbox. Yang terbukti jalan:

```bash
npm install --no-save --no-audit --no-fund @sparticuz/chromium
node -e "import('@sparticuz/chromium').then(m=>m.default.executablePath())"
# -> /tmp/chromium
node -e "require('zlib');const fs=require('fs');fs.writeFileSync('/tmp/al2023.tar',require('zlib').brotliDecompressSync(fs.readFileSync('node_modules/@sparticuz/chromium/bin/al2023.tar.br')));require('child_process').execSync('mkdir -p /tmp/al2023 && tar -xf /tmp/al2023.tar -C /tmp/al2023')"
# lalu jalankan suite dengan:
PUPPETEER_EXECUTABLE_PATH=/tmp/chromium LD_LIBRARY_PATH=/tmp/al2023/lib node qa/<suite>.mjs
```

Catatan: banyak suite lama (`dd8`, `dd8b`, `dd9-kompas`, `dd10b-*`) mati di
klik pertama karena ditulis sebelum layar sambutan `PilihMode` ada. Jembatan:
klik `Saya pelatih` → `Masuk` → `Muat data contoh` → `location.hash='#/drill'`.
Escape menutup modal bertingkat sekaligus — periksa label centang, bukan
tombol toolbar.

## Setelah ini (kesepakatan dengan user: satu per satu)

Item #2 **buku saku** — perbaikannya (kompas, panah, tanda ′, −/+ benar)
SUDAH tayang di `main` & di `drill-kit.vercel.app` (diverifikasi 29 asersi).
Sisa #2: hidupkan 6 suite mati di atas + daftarkan ke `qa/regresi-penuh.sh`
("2a"), kartu lipat (menunggu keputusan user), pemolesan cetak (opsional).
Lalu #3 sisi anggota → #4 CI → #5 pecah Drill.tsx + bundle.

## Sidik jari (untuk cek integritas ekstraksi)

```
sha256sum untuk-git.bundle perubahan-1a-1b.patch   # bandingkan dengan di bawah
```
ee00d8a874948b0c3c0b278a3d17777eb1fc761965d6514fbeeea4cbeefbd590  untuk-git.bundle
2a2df521da4019d3012982de339316a264bf4346fd164e723727f8bf29719427  perubahan-1a-1b.patch
